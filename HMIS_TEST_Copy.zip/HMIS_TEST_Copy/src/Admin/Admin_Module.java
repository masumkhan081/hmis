/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import javax.swing.border.Border;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pddrgj3q
 */
public class Admin_Module extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form Admin
     */
    static int pX, pY;
    static String pass = "";
    static String running_ProfileType;
    static int running_ProfileID;
    static int id, test_ID, bed_id, ser_ID, evt_ID, nurse_ID, member_ID, doc_ID, consult_fee, app_fee, module_user_ID, case_id;
    static String name, email, contact, nid, dob, doj, p_add, c_add, gender, desg, age, module_user_name, module_use_pass, start, schedule, type, tbl_title, dept, end;
    static java.util.Date date;
    static JFrame jfr;
    static Bed_Detail bed_detail;
    static Test_Detail test_detail;
    static InputStream is;
    static DateFormat df;
    static DateFormat date_Format;
    static JOptionPane jOptionPane;
    static java.awt.event.ActionEvent evt;
    static Doc_Panel new_doc;
    static Nurse_Panel nurse;
    static System_Member_Panel member_form;
    static View_Doc_Schedule view_sch;
    static Med_Test_Panel med_test;
    static Admin_Module admin;
    static Suggestion_List suggestion;
    static New_Surgery surgery;
    static Bed_Panel bed;
    static Department_Panel new_dept;
    static DefaultComboBoxModel cmb_model;
    static Connection con = null;
    static Statement st = null;
    static ResultSet temp_rs;
    static Statement temp_st = null;
    static String temp_query;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String db_userName = "root";
    static String db_password = "";
    static boolean sign, module_right;
    static SimpleDateFormat simpleDateFormat;
    static FileInputStream fin;
    static File imgFile;
    static ArrayList<String> sugg;
    static ImageIcon pic;
    static ArrayList<String> Listed_sugg;
    static ArrayList<Integer> ids;
    static DefaultListModel model;
    static ArrayList<String[]> arr_show;
    static ArrayList<String> test_types;
    static DefaultListModel jlist_model;

    static JButton btn_x, btn_sch, btn_editProfile;
    public JLabel lbl_name, lbl_email, lbl_con, lbl_nid, lbl_p_add, lbl_c_add, lbl_dept, lbl_desg, lbl_type, lbl_office, lbl_module, lbl_gender, lbl_dob, lbl_doj, lbl_salery, lbl_id, lbl_app_fee, lbl_con_fee, lbl_sch;

    public Admin_Module() {
        initComponents();
        setSize(1356, 782);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        btn_new_doc.addActionListener(this);
        btn_new_bed.addActionListener(this);
        btn_new_department.addActionListener(this);
        btn_new_doc.addActionListener(this);
        btn_new_nurse.addActionListener(this);
        btn_new_service.addActionListener(this);
        btn_new_test.addActionListener(this);
        btn_search.addActionListener(this);
        // dateTimePicker1.setPattern("HH:MM::SS");
        ButtonGroup btn_g = new ButtonGroup();
        buttonGroup1.add(rbtn_edit);
        buttonGroup1.add(rbtn_new);
        buttonGroup1.add(rbtn_view);
        rbtn_view.setSelected(true);
        rbtn_viewActionPerformed(evt);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
        refresh();

        // make_Usable(false);
    }

    public void refresh() {

        set_SurgeryType();
        set_Department_Names();
        set_med_TestTypes();
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btn_x) {
            jpnl_grand.removeAll();
            jpnl_grand.setVisible(false);
            jpnl_grand.setVisible(true);
        }
        if (ae.getSource() == btn_sch) {
            System.out.println("got it ############# 2");
            new View_Doc_Schedule(running_ProfileID);
        }
        if (ae.getSource() == btn_editProfile) {
            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            import_editableForm();
        }
    }

    public void set_SurgeryType() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT type from surgeries ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_sur_by_type.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_sur_by_type.setSelectedIndex(-1);
    }

    public void set_med_TestTypes() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT type from med_tests ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_test_bu_type.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_test_bu_type.setSelectedIndex(-1);
    }

    public void set_Department_Names() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT name from departments ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_doc_by_dept.setModel(cmb_model);
            cmb_nurse_by_dept.setModel(cmb_model);
            cmb_surBy_dept.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_doc_by_dept.setSelectedIndex(-1);
    }

    static void get_dept_Names() {
        Listed_sugg = new ArrayList<String>();
        String name;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM departments";
            rs = st.executeQuery(query);
            while (rs.next()) {
                name = rs.getString("name");
                name.toLowerCase();
                Listed_sugg.add(name);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        for (int i = 0; i < Listed_sugg.size(); i++) {
            System.out.println(Listed_sugg.get(i));
        }
    }

    public void clear_GrandPanel() {
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    public void remove_surgery() {
        jpnl_sup_grand.remove(surgery);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    public void remove_dept() {
        jpnl_sup_grand.remove(new_dept);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    public void remove_Nurse() {
        nurse.setVisible(false);
        jpnl_sup_grand.remove(nurse);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    public void remove_med_test() {
        jpnl_sup_grand.remove(med_test);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    public void remove_member_form() {
        jpnl_sup_grand.remove(member_form);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    static String get_auto_generated_pass() {

        int randomInt = ThreadLocalRandom.current().nextInt(5000, 9000);
        System.out.println("Random number generated is : " + randomInt);
        randomInt *= ThreadLocalRandom.current().nextInt(3, 9);
        pass = String.valueOf(randomInt);
        return pass;
    }

    public void remove_bed() {
        jpnl_sup_grand.remove(bed);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cmb_search_By = new javax.swing.JComboBox<>();
        txt_search_content2 = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jpnl_login = new javax.swing.JPanel();
        txt_u_name = new javax.swing.JTextField();
        txt_pass = new javax.swing.JTextField();
        btn_login_out = new javax.swing.JButton();
        txt_conf_pass = new javax.swing.JTextField();
        btn_update = new javax.swing.JButton();
        lbl_missmtch1 = new javax.swing.JLabel();
        jpnl_sup_grand = new javax.swing.JPanel();
        lbl_tbl_title = new javax.swing.JLabel();
        lbl_msg = new javax.swing.JLabel();
        jpnl_grand = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        jpnl_functions = new javax.swing.JPanel();
        btn_go_details = new javax.swing.JButton();
        btn_remove = new javax.swing.JButton();
        btn_update_profile = new javax.swing.JButton();
        rbtn_new = new javax.swing.JRadioButton();
        rbtn_view = new javax.swing.JRadioButton();
        rbtn_edit = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jpnl_scrollwith = new javax.swing.JPanel();
        btn_new_doc = new javax.swing.JButton();
        btn_new_nurse = new javax.swing.JButton();
        btn_new_sys_e = new javax.swing.JButton();
        btn_new_service = new javax.swing.JButton();
        btn_new_department = new javax.swing.JButton();
        btn_new_test = new javax.swing.JButton();
        btn_new_bed = new javax.swing.JButton();
        cmb_doc_by_dept = new javax.swing.JComboBox<>();
        cmb_nurse_by_dept = new javax.swing.JComboBox<>();
        btn_account = new javax.swing.JButton();
        cmb_surBy_dept = new javax.swing.JComboBox<>();
        cmb_test_bu_type = new javax.swing.JComboBox<>();
        cmb_bed_by_type = new javax.swing.JComboBox<>();
        btn_surgery = new javax.swing.JButton();
        btn_surgery_cases = new javax.swing.JButton();
        cmb_sur_by_type = new javax.swing.JComboBox<>();
        btn_run_in_pat = new javax.swing.JButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(1348, 836));
        jPanel1.setMinimumSize(new java.awt.Dimension(1348, 836));
        jPanel1.setPreferredSize(new java.awt.Dimension(1348, 836));

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)));
        jPanel2.setMaximumSize(new java.awt.Dimension(1181, 63));
        jPanel2.setMinimumSize(new java.awt.Dimension(1181, 63));
        jPanel2.setPreferredSize(new java.awt.Dimension(1181, 63));

        cmb_search_By.setBackground(new java.awt.Color(204, 204, 255));
        cmb_search_By.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        cmb_search_By.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Patient Name", "Contact No", "Receipt Code", "appointment code", "bed/ward no" }));
        cmb_search_By.setOpaque(false);

        txt_search_content2.setBackground(new java.awt.Color(1, 34, 34));
        txt_search_content2.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_search_content2.setForeground(new java.awt.Color(255, 204, 102));
        txt_search_content2.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 102, 102)));
        txt_search_content2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_content2ActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(1, 34, 34));
        btn_search.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton4.setBackground(new java.awt.Color(51, 0, 0));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 153));
        jButton4.setText("Forward");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton5.setBackground(new java.awt.Color(51, 0, 0));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 153));
        jButton5.setText("Back");
        jButton5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jpnl_login.setBackground(new java.awt.Color(204, 255, 204));

        txt_u_name.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });
        txt_u_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_u_nameActionPerformed(evt);
            }
        });

        txt_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_pass.setText("pass..");
        txt_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passFocusLost(evt);
            }
        });

        btn_login_out.setBackground(new java.awt.Color(204, 255, 204));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_login_out.setText("In");
        btn_login_out.setActionCommand("Log  Out");
        btn_login_out.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        txt_conf_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_conf_pass.setText("confirm pass");
        txt_conf_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_conf_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusLost(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(204, 255, 204));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_update.setText("Edit");
        btn_update.setActionCommand("Log  Out");
        btn_update.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        lbl_missmtch1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_missmtch1.setForeground(new java.awt.Color(102, 51, 0));
        lbl_missmtch1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jpnl_loginLayout = new javax.swing.GroupLayout(jpnl_login);
        jpnl_login.setLayout(jpnl_loginLayout);
        jpnl_loginLayout.setHorizontalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_loginLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnl_loginLayout.createSequentialGroup()
                        .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnl_loginLayout.createSequentialGroup()
                        .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_missmtch1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );
        jpnl_loginLayout.setVerticalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_loginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lbl_missmtch1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jpnl_login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_search_content2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 548, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jpnl_login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmb_search_By, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_search_content2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_search, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        jpnl_sup_grand.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_sup_grand.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 0, 0, new java.awt.Color(0, 0, 0)));
        jpnl_sup_grand.setMaximumSize(new java.awt.Dimension(1130, 510));
        jpnl_sup_grand.setMinimumSize(new java.awt.Dimension(1130, 510));
        jpnl_sup_grand.setPreferredSize(new java.awt.Dimension(1130, 510));

        lbl_tbl_title.setBackground(new java.awt.Color(204, 204, 255));
        lbl_tbl_title.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        lbl_tbl_title.setText("some title");
        lbl_tbl_title.setMaximumSize(new java.awt.Dimension(850, 16));
        lbl_tbl_title.setMinimumSize(new java.awt.Dimension(850, 16));
        lbl_tbl_title.setPreferredSize(new java.awt.Dimension(850, 16));

        lbl_msg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jpnl_grand.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_grand.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 102, 153), new java.awt.Color(0, 51, 51), new java.awt.Color(204, 102, 0), new java.awt.Color(0, 153, 153)));
        jpnl_grand.setMaximumSize(new java.awt.Dimension(380, 590));
        jpnl_grand.setMinimumSize(new java.awt.Dimension(380, 590));

        javax.swing.GroupLayout jpnl_grandLayout = new javax.swing.GroupLayout(jpnl_grand);
        jpnl_grand.setLayout(jpnl_grandLayout);
        jpnl_grandLayout.setHorizontalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 374, Short.MAX_VALUE)
        );
        jpnl_grandLayout.setVerticalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        tbl_Result_Exhibition.setBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(255, 255, 153));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 51, 51));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setRowHeight(25);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(204, 255, 153));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(153, 51, 0));
        jScrollPane1.setViewportView(tbl_Result_Exhibition);

        javax.swing.GroupLayout jpnl_sup_grandLayout = new javax.swing.GroupLayout(jpnl_sup_grand);
        jpnl_sup_grand.setLayout(jpnl_sup_grandLayout);
        jpnl_sup_grandLayout.setHorizontalGroup(
            jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(179, 179, 179)
                        .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnl_grand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jpnl_sup_grandLayout.setVerticalGroup(
            jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jpnl_grand, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 590, Short.MAX_VALUE))
                .addGap(14, 14, 14))
        );

        jpnl_functions.setBackground(new java.awt.Color(204, 255, 204));

        btn_go_details.setBackground(new java.awt.Color(0, 0, 0));
        btn_go_details.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_go_details.setForeground(new java.awt.Color(204, 204, 255));
        btn_go_details.setText("View Profile/Detail");
        btn_go_details.setBorder(null);
        btn_go_details.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_go_detailsActionPerformed(evt);
            }
        });

        btn_remove.setBackground(new java.awt.Color(0, 0, 0));
        btn_remove.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_remove.setForeground(new java.awt.Color(204, 204, 255));
        btn_remove.setText("Remove");
        btn_remove.setBorder(null);
        btn_remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_removeActionPerformed(evt);
            }
        });

        btn_update_profile.setBackground(new java.awt.Color(0, 0, 0));
        btn_update_profile.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_update_profile.setForeground(new java.awt.Color(204, 204, 255));
        btn_update_profile.setText("Edit Profile");
        btn_update_profile.setBorder(null);
        btn_update_profile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_update_profileActionPerformed(evt);
            }
        });

        rbtn_new.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_new.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        rbtn_new.setText("New To System");
        rbtn_new.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_newActionPerformed(evt);
            }
        });

        rbtn_view.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_view.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        rbtn_view.setText("Normal View");
        rbtn_view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_viewActionPerformed(evt);
            }
        });

        rbtn_edit.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_edit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        rbtn_edit.setText("Edit & Update");
        rbtn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_editActionPerformed(evt);
            }
        });

        jScrollPane2.setBorder(null);

        jpnl_scrollwith.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_scrollwith.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));

        btn_new_doc.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_doc.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_doc.setText("Doctor ");
        btn_new_doc.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_doc.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_doc.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_doc.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_doc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_docActionPerformed(evt);
            }
        });

        btn_new_nurse.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_nurse.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_nurse.setText("Nurse ");
        btn_new_nurse.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_nurse.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_nurse.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_nurse.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_nurse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_nurseActionPerformed(evt);
            }
        });

        btn_new_sys_e.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_sys_e.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_sys_e.setText("System executive");
        btn_new_sys_e.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_sys_e.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_sys_e.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_sys_e.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_sys_e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_sys_eActionPerformed(evt);
            }
        });

        btn_new_service.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_service.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_service.setText("Service");
        btn_new_service.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_service.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_service.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_service.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_service.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_serviceActionPerformed(evt);
            }
        });

        btn_new_department.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_department.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_department.setText("Department");
        btn_new_department.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_department.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_department.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_department.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_department.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_departmentActionPerformed(evt);
            }
        });

        btn_new_test.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_test.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_test.setText("Medical Test");
        btn_new_test.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        btn_new_test.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_test.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_test.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_test.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_testActionPerformed(evt);
            }
        });

        btn_new_bed.setBackground(new java.awt.Color(204, 255, 204));
        btn_new_bed.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_new_bed.setText("Edit This Bed Info");
        btn_new_bed.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        btn_new_bed.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_new_bed.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_new_bed.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_new_bed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_bedActionPerformed(evt);
            }
        });

        cmb_doc_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_doc_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_doc_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_doc_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_doc_by_dept.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_doc_by_dept.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_doc_by_dept.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_doc_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_doc_by_deptActionPerformed(evt);
            }
        });

        cmb_nurse_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_nurse_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_nurse_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_nurse_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_nurse_by_dept.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_nurse_by_dept.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_nurse_by_dept.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_nurse_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_nurse_by_deptActionPerformed(evt);
            }
        });

        btn_account.setBackground(new java.awt.Color(204, 255, 204));
        btn_account.setFont(new java.awt.Font("Carlito", 1, 13)); // NOI18N
        btn_account.setText("Accounts");
        btn_account.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        btn_account.setMaximumSize(new java.awt.Dimension(150, 24));
        btn_account.setMinimumSize(new java.awt.Dimension(150, 24));
        btn_account.setPreferredSize(new java.awt.Dimension(150, 24));
        btn_account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_accountActionPerformed(evt);
            }
        });

        cmb_surBy_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_surBy_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_surBy_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_surBy_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_surBy_dept.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_surBy_dept.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_surBy_dept.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_surBy_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_surBy_deptActionPerformed(evt);
            }
        });

        cmb_test_bu_type.setBackground(new java.awt.Color(2, 25, 25));
        cmb_test_bu_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_test_bu_type.setForeground(new java.awt.Color(204, 255, 204));
        cmb_test_bu_type.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_test_bu_type.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_test_bu_type.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_test_bu_type.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_test_bu_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_test_bu_typeActionPerformed(evt);
            }
        });

        cmb_bed_by_type.setBackground(new java.awt.Color(2, 25, 25));
        cmb_bed_by_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_bed_by_type.setForeground(new java.awt.Color(204, 255, 204));
        cmb_bed_by_type.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_bed_by_type.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_type.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_type.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_bed_by_typeActionPerformed(evt);
            }
        });

        btn_surgery.setBackground(new java.awt.Color(0, 0, 0));
        btn_surgery.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_surgery.setForeground(new java.awt.Color(204, 204, 255));
        btn_surgery.setText("New Surgery");
        btn_surgery.setBorder(null);
        btn_surgery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_surgeryActionPerformed(evt);
            }
        });

        btn_surgery_cases.setBackground(new java.awt.Color(204, 255, 204));
        btn_surgery_cases.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_surgery_cases.setText("Surgery Cases:");
        btn_surgery_cases.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_surgery_cases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_surgery_casesActionPerformed(evt);
            }
        });

        cmb_sur_by_type.setBackground(new java.awt.Color(2, 25, 25));
        cmb_sur_by_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_sur_by_type.setForeground(new java.awt.Color(204, 255, 204));
        cmb_sur_by_type.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_sur_by_type.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_sur_by_type.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_sur_by_type.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_sur_by_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_sur_by_typeActionPerformed(evt);
            }
        });

        btn_run_in_pat.setBackground(new java.awt.Color(204, 255, 204));
        btn_run_in_pat.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_run_in_pat.setText("Running In Patients");
        btn_run_in_pat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_run_in_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_run_in_patActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpnl_scrollwithLayout = new javax.swing.GroupLayout(jpnl_scrollwith);
        jpnl_scrollwith.setLayout(jpnl_scrollwithLayout);
        jpnl_scrollwithLayout.setHorizontalGroup(
            jpnl_scrollwithLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_scrollwithLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jpnl_scrollwithLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_surgery_cases, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_bed_by_type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_test_bu_type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_surBy_dept, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_account, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_doc_by_dept, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_bed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_nurse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_nurse_by_dept, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_sys_e, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_service, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_department, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_test, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_new_doc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_surgery, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmb_sur_by_type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_run_in_pat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jpnl_scrollwithLayout.setVerticalGroup(
            jpnl_scrollwithLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_scrollwithLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(btn_surgery_cases, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_run_in_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(btn_new_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_doc_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btn_new_nurse, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_nurse_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btn_new_sys_e, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_service, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_department, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_test, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_test_bu_type, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_bed, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_bed_by_type, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_account, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_surgery, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_surBy_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_sur_by_type, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 120, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jpnl_scrollwith);

        javax.swing.GroupLayout jpnl_functionsLayout = new javax.swing.GroupLayout(jpnl_functions);
        jpnl_functions.setLayout(jpnl_functionsLayout);
        jpnl_functionsLayout.setHorizontalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_go_details, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_remove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(rbtn_new, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rbtn_view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rbtn_edit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btn_update_profile, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jpnl_functionsLayout.setVerticalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_functionsLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(btn_go_details, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_remove, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(rbtn_new, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rbtn_view, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(rbtn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_update_profile, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jpnl_functions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jpnl_sup_grand, javax.swing.GroupLayout.DEFAULT_SIZE, 1183, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1358, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jpnl_functions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnl_sup_grand, javax.swing.GroupLayout.DEFAULT_SIZE, 623, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1358, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 764, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_search_content2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_content2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_content2ActionPerformed
    public void view_Nurses(String q) {
        query = q;

        String[] data = new String[5];
        ids = new ArrayList();
        arr_show = new ArrayList<String[]>();
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "Name";
        data[1] = "Contact";
        data[2] = "current address";
        data[3] = "Dept.";
        data[4] = "tpye/desg.";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("nurse_id"));
                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("cur_add");
                data[3] = rs.getString("dept");
                data[4] = rs.getString("type");
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }
    }
    private void btn_new_nurseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_nurseActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            System.out.println("gone in the right track");
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((nurse = new Nurse_Panel(0)));
            nurse.setLocation(250, 20);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Nurses";
            System.out.println(tbl_title);
            view_Nurses("SELECT * FROM nurses");
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_nurseActionPerformed
    public void view_Tests(String q) {
        query = q;

        ids = new ArrayList();
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();

        data[0] = "Name";
        data[1] = "Type";
        data[2] = "Charge";
        data[3] = "Testing Method";
        arr_show.add(data);
        DefaultTableModel dtm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dtm);
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        tbl_title = "System Executives";
        lbl_tbl_title.setText(tbl_title);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        dtm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("test_id"));
                data[0] = rs.getString("name");
                data[1] = rs.getString("type");
                data[2] = rs.getString("charge");
                data[3] = rs.getString("testing_method");
                arr_show.add(data);
                dtm.addRow(arr_show.get(0));
            }
            tbl_title = "Pathology Tests";
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }

    }
    private void btn_new_testActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_testActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);

            jpnl_sup_grand.add((med_test = new Med_Test_Panel(0)));
            med_test.setLocation(100, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Pathology Tests";
            view_Tests("SELECT * FROM med_tests");
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_testActionPerformed
    public void view_Dept(String q) {
        query = q;
        btn_update_profile.setVisible(true);
        btn_go_details.setVisible(true);
        btn_remove.setVisible(true);
        ResultSet temp_rs;
        int doc_count;

        String[] data = new String[3];
        arr_show = new ArrayList<String[]>();
        String temp = "";
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "Dept_ID";
        data[1] = "Name";
        data[2] = "Available Doctors";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("dept_id");
                data[1] = rs.getString("name");
                doc_count = 0;
                query = "SELECT * FROM doctors WHERE dept = '" + data[1] + "'";
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    doc_count++;
                }
                data[2] = String.valueOf(doc_count);
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            lbl_tbl_title.setText(tbl_title);
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(80);
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(80);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
            System.out.println(ex);
        }
    }
    private void btn_new_departmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_departmentActionPerformed
        // TODO add your handling code here:
        if (rbtn_view.isSelected()) {
            tbl_title = "Departments & Info";
            view_Dept("SELECT * FROM departments");
        }
        if (rbtn_new.isSelected()) {
            System.out.println("gone in the right track");
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((new_dept = new Department_Panel(0)));
            new_dept.setLocation(380, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_departmentActionPerformed
    public void view_Executives(String q) {
        query = q;

        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();
        ids = new ArrayList<>();
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setText(tbl_title);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "Name";
        data[1] = "Contact";
        data[2] = "Designation";
        data[3] = "Email";
        data[4] = "Module";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(id = rs.getInt("member_id"));
                System.out.println("id: " + id);
                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("degrees");
                data[3] = rs.getString("email");
                temp_query = "SELECT * FROM accounts where user_id =" + id;
                temp_rs = temp_st.executeQuery(temp_query);
                data[4] = "";
                while (temp_rs.next()) {
                    data[4] = temp_rs.getString("module");
                }
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            System.out.println(ex);
            acknowledgement_Or_Warning("something went wrong", 1900);
        }
    }
    private void btn_new_sys_eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_sys_eActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            System.out.println("gone in the right track");
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((member_form = new System_Member_Panel(0)));
            member_form.setLocation(260, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Executive Members";
            view_Executives("SELECT * FROM system_executives");
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_sys_eActionPerformed

    private void btn_new_docActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_docActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((new_doc = new Doc_Panel(0)));
            new_doc.setLocation(06, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Doctors";
            view_Doctors("SELECT * FROM doctors");
        }
        if (rbtn_edit.isSelected()) {
            sign = false;
            if (tbl_Result_Exhibition.getSelectedRow() < 0 || tbl_Result_Exhibition.getSelectedRows().length > 1) {
                acknowledgement_Or_Warning("Select A row to see profile ", 1600);
                sign = true;
            }
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((new_doc = new Doc_Panel(1)));
            new_doc.setLocation(06, 0);
            jpnl_sup_grand.setVisible(true);

        }
    }//GEN-LAST:event_btn_new_docActionPerformed
    public void view_Doctors(String q) {

        query = q;
        ids = new ArrayList<>();
        String[] data = new String[7];
        arr_show = new ArrayList<String[]>();
        data[0] = "Name";
        data[1] = "Contact";
        data[2] = "Dept.";
        data[3] = "Office";
        data[4] = "Consultation";
        data[5] = "Appointment";
        data[6] = "Cur. Add";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setText("Doctors");
        lbl_tbl_title.setSize(300, 20);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(id = rs.getInt("doc_id"));
                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("dept");
                data[3] = rs.getString("office");
                data[4] = rs.getString("consultation_fee");
                data[5] = rs.getString("appointment_fee");
                data[6] = rs.getString("cur_add");
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }

    }

    public void view_Services(String q) {
        query = q;

        ids = new ArrayList();
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "Name";
        data[1] = "Sub Service";
        data[2] = "Type";
        data[3] = "Charge";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("service_id"));
                data[0] = rs.getString("sub_name");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("bill");
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            tbl_title = "Services & Charges";
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }
    }
    private void btn_new_serviceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_serviceActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            System.out.println("gone in the right track");
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((new_dept = new Department_Panel(1)));
            new_dept.setLocation(350, 60);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Services";
            view_Services("SELECT * FROM services");
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_serviceActionPerformed
    public void view_Beds(String q) {
        query = q;
        btn_update_profile.setVisible(true);
        btn_go_details.setVisible(true);
        btn_remove.setVisible(true);

        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        tbl_title = "Beds & status";
        lbl_tbl_title.setText(tbl_title);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "ID";
        data[1] = "Receptivity";
        data[2] = "Type";
        data[3] = "Current Vacancy";
        data[4] = "Charge";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("bed_id");
                data[1] = rs.getString("receptivity");
                data[2] = rs.getString("type");
                data[3] = rs.getString("vacancy");
                data[4] = rs.getString("charge");
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
                lbl_tbl_title.setText(tbl_title);
                tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
                tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
            }
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }
    }
    private void btn_new_bedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_bedActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            System.out.println("gone in the right track");
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((bed = new Bed_Panel(0)));
            bed.setLocation(260, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Beds & Status";
            view_Beds("SELECT * FROM beds");
        }
        if (rbtn_edit.isSelected()) {

        }
    }//GEN-LAST:event_btn_new_bedActionPerformed

    private void btn_go_detailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_go_detailsActionPerformed
        // TODO add your handling code here:
        sign = false;
        try {
            System.out.println(">>>%%%&&& " + tbl_Result_Exhibition.getSelectedRow());
            if (tbl_Result_Exhibition.getSelectedRow() < 1 || tbl_Result_Exhibition.getSelectedRows().length > 1) {
                lbl_msg.setForeground(Color.WHITE);
                lbl_tbl_title.setForeground(Color.WHITE);
                acknowledgement_Or_Warning("Select An person or object", 1600);
                System.out.println("pokath @");
                sign = true;
            }
            if (sign == false && tbl_title.contains("Cases")) {

            }
            if (sign == false && tbl_title.contains("Nurses")) {
                nurse_ID = tbl_Result_Exhibition.getSelectedRow();
                running_ProfileID = ids.get(nurse_ID - 1);
                System.out.println("jar 1 : " + nurse_ID + "+" + running_ProfileID);
                running_ProfileType = "Nurse";
                jpnl_grand.removeAll();
                label_Maker();
                nurse_Profiler();
            }
            if (sign == false && tbl_title.contains("Doctors")) {
                doc_ID = tbl_Result_Exhibition.getSelectedRow();
                System.out.println(" doc_ID  " + doc_ID);
                running_ProfileID = ids.get(doc_ID - 1);
                running_ProfileType = "Doctor";
                jpnl_grand.removeAll();
                label_Maker();
                doc_Profiler();
            }
            if (sign == false && tbl_title.contains("Executive Members")) {
                member_ID = tbl_Result_Exhibition.getSelectedRow();
                running_ProfileID = ids.get(member_ID - 1);
                running_ProfileType = "Executive Member";
                jpnl_grand.removeAll();
                label_Maker();
                executive_memberProfiler();
            }
            if (sign == false && tbl_title.contains("Tests")) {
                test_ID = tbl_Result_Exhibition.getSelectedRow();
                test_ID = ids.get(test_ID - 1);
                (test_detail = new Test_Detail(test_ID)).setVisible(true);
            }
            if (sign == false && tbl_title.contains("Beds")) {
                bed_id = tbl_Result_Exhibition.getSelectedRow();
                bed_id = ids.get(bed_id - 1);
                (bed_detail = new Bed_Detail(bed_id)).setVisible(true);
            }
            if (sign == false && tbl_title.contains("Services")) {
                ser_ID = tbl_Result_Exhibition.getSelectedRow();
                running_ProfileID = ids.get(ser_ID - 1);
                jpnl_grand.removeAll();
                running_ProfileType = "Service";
                label_Maker();
                service_Profiler();
            }
        } catch (Exception exp) {
            System.out.println(exp);

        }
    }//GEN-LAST:event_btn_go_detailsActionPerformed

    private void btn_update_profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_update_profileActionPerformed
        // TODO add your handling code here:
        sign = false;
//        jpnl_grand.setVisible(false);
//        jpnl_grand.setVisible(true);
        if (tbl_Result_Exhibition.getSelectedRow() < 0 || tbl_Result_Exhibition.getSelectedRows().length > 1) {
            acknowledgement_Or_Warning("Select A row to see profile ", 1600);
            sign = true;
        }

        if (sign == false && lbl_tbl_title.getText().equals("Doctors")) {
            doc_ID = tbl_Result_Exhibition.getSelectedRow();
            doc_ID = Integer.parseInt(tbl_Result_Exhibition.getValueAt(doc_ID, 0).toString());
            //  Doc_Form obj = new Doc_Form(2);
        }
        if (sign == false && lbl_tbl_title.getText().equals("Nurses")) {
            System.out.println("got it ????");
            nurse_ID = tbl_Result_Exhibition.getSelectedRow();
            nurse_ID = Integer.parseInt(tbl_Result_Exhibition.getValueAt(nurse_ID, 0).toString());

            JFrame frame = new JFrame();
            frame.add((nurse = new Nurse_Panel(2)));

            frame.setVisible(true);
            frame.setLocation(300, 180);
            frame.setSize(730, 488);
        }
    }//GEN-LAST:event_btn_update_profileActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void txt_u_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_u_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_u_nameActionPerformed

    private void txt_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusGained
        // TODO add your handling code here:
        if (txt_pass.getText().equals("pass..")) {
            txt_pass.setText("");
        }
    }//GEN-LAST:event_txt_passFocusGained

    private void txt_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusLost
        // TODO add your handling code here:
        if (txt_pass.getText().equals("")) {
            txt_pass.setText("pass..");
        }
    }//GEN-LAST:event_txt_passFocusLost
    public void make_Usable(boolean bool) {
        Component[] com;
        com = jpnl_functions.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        com = jpnl_scrollwith.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }

        if (bool == false) {
            txt_conf_pass.setVisible(bool);

            btn_login_out.setText("In");
        }
        if (bool == true) {
            txt_pass.setVisible(!bool);
            txt_u_name.setVisible(!bool);
            btn_login_out.setText("Out");
            set_Department_Names();
        }
    }
    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:
        if (btn_login_out.getText().equals("In")) {
            module_user_name = txt_u_name.getText();
            module_use_pass = txt_pass.getText();
            System.out.println(module_user_name + "  ?  " + module_use_pass);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "SELECT * FROM accounts WHERE user_name = '" + module_user_name + "' AND pass = '" + module_use_pass + "'";
                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (rs.getString("module").equals("Admin")) {
                        sign = true;
                        module_user_ID = rs.getInt("user_id");
                        make_Usable(sign);
                    }
                }
                if (sign == false) {
                    acknowledgement_Or_Warning("Missmatch !", 1650);
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_login_outActionPerformed

    private void txt_conf_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusGained
        // TODO add your handling code here:
        btn_update.setText("Update");

        if (txt_conf_pass.getText().equals("confirm pass")) {
            txt_conf_pass.setText("");
        }
    }//GEN-LAST:event_txt_conf_passFocusGained

    private void txt_conf_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusLost
        if (txt_conf_pass.getText().equals("")) {
            txt_conf_pass.setText("confirm pass");
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txt_conf_passFocusLost

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
        acknowledgement_Or_Warning("Left Coding !", 1650);
    }//GEN-LAST:event_btn_updateActionPerformed

    private void rbtn_newActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_newActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            btn_account.setVisible(false);
            btn_new_bed.setText("Add Bed");
            btn_new_department.setText("Add Department");
            btn_new_doc.setText("Add Doctor");
            btn_new_nurse.setText("Add Nurse");
            btn_new_service.setText("Add Service");
            btn_new_test.setText("Add Medical Test");
            btn_new_sys_e.setText("Add Executive");
            btn_surgery.setText("New Surgery in System");
            btn_surgery_cases.setVisible(false);
            cmb_doc_by_dept.setVisible(false);
            cmb_bed_by_type.setVisible(false);
            cmb_nurse_by_dept.setVisible(false);
            cmb_surBy_dept.setVisible(false);
            cmb_sur_by_type.setVisible(false);
            cmb_test_bu_type.setVisible(false);
            btn_run_in_pat.setVisible(false);
        }
    }//GEN-LAST:event_rbtn_newActionPerformed

    private void rbtn_viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_viewActionPerformed
        // TODO add your handling code here:
        if (rbtn_view.isSelected()) {
            btn_account.setVisible(true);
            btn_new_bed.setText("View Beds");
            btn_new_department.setText("All Departments");
            btn_new_doc.setText("Doctors & Info");
            btn_new_nurse.setText("All Nurses");
            btn_new_service.setText("Running Services");
            btn_new_test.setText("Medical Tests");
            btn_new_sys_e.setText("Executive Members");
            cmb_doc_by_dept.setVisible(true);
            cmb_bed_by_type.setVisible(true);
            cmb_nurse_by_dept.setVisible(true);
            cmb_surBy_dept.setVisible(true);
            cmb_sur_by_type.setVisible(true);
            cmb_test_bu_type.setVisible(true);
            btn_surgery.setText("Listed Surgeries");
            btn_surgery_cases.setText("Surgery Cases");
            btn_run_in_pat.setVisible(true);
            jpnl_sup_grand.setBackground(new Color(204, 204, 255));
        }
    }//GEN-LAST:event_rbtn_viewActionPerformed

    private void rbtn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_editActionPerformed
        // TODO add your handling code here:
        if (rbtn_edit.isSelected()) {
            btn_account.setVisible(true);
            btn_new_bed.setText("Edit This Bed Info");
            btn_new_department.setText("Change dept. Info");
            btn_new_doc.setText("UpdateThis Doc.");
            btn_new_nurse.setText("Update The Nurse");
            btn_new_service.setText("Service Update");
            btn_new_test.setText("Medical Test Update");
            btn_new_sys_e.setText("Upd. Member Info");
            btn_surgery.setText("Upd. This Surgery Info");
            cmb_doc_by_dept.setVisible(false);
            cmb_bed_by_type.setVisible(false);
            cmb_nurse_by_dept.setVisible(false);
            cmb_surBy_dept.setVisible(false);
            cmb_sur_by_type.setVisible(false);
            cmb_test_bu_type.setVisible(false);

        }
    }//GEN-LAST:event_rbtn_editActionPerformed

    private void cmb_doc_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_doc_by_deptActionPerformed
        // TODO add your handling code here:
        if (cmb_doc_by_dept.getSelectedIndex() > -1) {
            dept = cmb_doc_by_dept.getSelectedItem().toString();
            view_Doctors("SELECT * FROM doctors where dept = '" + dept + "'");
        }
    }//GEN-LAST:event_cmb_doc_by_deptActionPerformed

    private void cmb_nurse_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_nurse_by_deptActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_nurse_by_deptActionPerformed
    public void view_Accounts() {

        String[] data = new String[6];
        arr_show = new ArrayList<String[]>();
        ids = new ArrayList<>();
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        tbl_title = "System Executives";
        lbl_tbl_title.setText(tbl_title);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        data[0] = "Name";
        data[1] = "Contact";
        data[2] = "Email";
        data[3] = "Desg.";
        data[4] = "Status";
        data[5] = "Module";
        DefaultTableModel dm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dm);
        arr_show.add(data);
        dm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM accounts";
            rs = st.executeQuery(query);
            while (rs.next()) {
                id = rs.getInt("user_id");
                ids.add(id);
                data[5] = rs.getString("module");
                data[4] = rs.getString("status");
                data[2] = rs.getString("email");
                type = rs.getString("type");
                if (type.equals("Doctor")) {
                    temp_query = "SELECT * FROM doctors WHERE doc_id = " + id;
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        data[0] = temp_rs.getString("name");
                        data[1] = temp_rs.getString("contact");
                        data[3] = temp_rs.getString("degrees") + "/ " + temp_rs.getString("dept");
                    }
                }
                if (type.equals("Nurse")) {
                    temp_query = "SELECT * FROM nurses WHERE nurse_id = " + id;
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        data[0] = temp_rs.getString("name");
                        data[1] = temp_rs.getString("contact");
                        data[3] = temp_rs.getString("type");
                    }
                } else {
                    temp_query = "SELECT * FROM system_executives WHERE member_id = " + id;
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        data[0] = temp_rs.getString("name");
                        data[1] = temp_rs.getString("contact");
                        data[3] = temp_rs.getString("degrees");
                    }
                }
                lbl_tbl_title.setText(tbl_title);
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }
    }
    private void btn_accountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_accountActionPerformed
        // TODO add your handling code here:

        if (rbtn_edit.isSelected()) {
            edit_This_Account();
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Active Accounts";
            view_Accounts();
        }
    }//GEN-LAST:event_btn_accountActionPerformed

    private void cmb_test_bu_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_test_bu_typeActionPerformed
        // TODO add your handling code here:
        if (cmb_test_bu_type.getSelectedIndex() >= 0) {
            type = cmb_test_bu_type.getSelectedItem().toString();
            view_Tests("SELECT * FROM med_tests WHERE type ='" + type + "'");
        }

    }//GEN-LAST:event_cmb_test_bu_typeActionPerformed

    private void cmb_bed_by_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_bed_by_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_bed_by_typeActionPerformed

    private void btn_surgeryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_surgeryActionPerformed
        // TODO add your handling code here:
        if (rbtn_new.isSelected()) {
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((surgery = new New_Surgery()));
            surgery.setLocation(200, 0);
            jpnl_sup_grand.setVisible(true);
        }
        if (rbtn_view.isSelected()) {
            tbl_title = "Surgeries (All)";
            view_PathologyTests("SELECT * FROM surgeries;");
        }

    }//GEN-LAST:event_btn_surgeryActionPerformed
    public void view_PathologyTests(String q) {
        query = q;

        ids = new ArrayList();
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();
        data[0] = "Title";
        data[1] = "Type";
        data[2] = "Method";
        data[3] = "Department";
        data[4] = "Official charge";
        arr_show.add(data);
        DefaultTableModel dtm = new DefaultTableModel(data, 0);
        tbl_Result_Exhibition.setModel(dtm);
        jpnl_sup_grand.removeAll();
        jpnl_sup_grand.add(lbl_tbl_title);
        jpnl_sup_grand.add(tbl_Result_Exhibition);
        jpnl_sup_grand.add(jpnl_grand);
        jpnl_sup_grand.add(lbl_msg);
        lbl_msg.setLocation(550, 0);
        tbl_Result_Exhibition.setLocation(5, 25);
        jpnl_sup_grand.setVisible(true);
        lbl_tbl_title.setText(tbl_title);
        lbl_tbl_title.setLocation(0, 0);
        jpnl_sup_grand.setVisible(false);
        jpnl_sup_grand.setVisible(true);
        dtm.addRow(arr_show.get(0));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("surgery_id"));
                data[0] = rs.getString("title");
                data[1] = rs.getString("type");
                data[2] = rs.getString("method");
                data[3] = rs.getString("dept");
                data[4] = rs.getString("charge");
                arr_show.add(data);
                dtm.addRow(arr_show.get(0));
            }
            lbl_tbl_title.setText(tbl_title);
        } catch (Exception ex) {
            acknowledgement_Or_Warning("something went wrong", 1900);
        }

    }
    private void btn_surgery_casesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_surgery_casesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_surgery_casesActionPerformed

    private void cmb_sur_by_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_sur_by_typeActionPerformed
        // TODO add your handling code here:
        if (cmb_doc_by_dept.getSelectedIndex() > -1) {
            type = cmb_doc_by_dept.getSelectedItem().toString();
            tbl_title = "Surgeries  of (" + type + ").";
            view_PathologyTests("SELECT * FROM surgeries WHERE type = '" + type + "'");
        }
    }//GEN-LAST:event_cmb_sur_by_typeActionPerformed

    private void cmb_surBy_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_surBy_deptActionPerformed
        // TODO add your handling code here:
        if (cmb_doc_by_dept.getSelectedIndex() > -1) {
            dept = cmb_doc_by_dept.getSelectedItem().toString();
            tbl_title = "Surgeries  of  (" + dept + ").";
            view_PathologyTests("SELECT * FROM surgeries WHERE dept = '" + dept + "'");
        }
    }//GEN-LAST:event_cmb_surBy_deptActionPerformed

    private void btn_run_in_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_run_in_patActionPerformed
        // TODO add your handling code here:
        ResultSet temp_rs;
        ids = new ArrayList();
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "Pat Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Adm. Date";
        coloumn[3] = "Room num";
        coloumn[4] = "Floor";
        coloumn[5] = "Type";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT * FROM in_pat_cases WHERE status = '" + "running" + "' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                case_id = Integer.parseInt(rs.getString("case_id"));
                id = rs.getInt("pat_id");
                ids.add(id);
                query = "SELECT * FROM patients WHERE pat_id = " + id + " ";
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    data[0] = temp_rs.getString("name");
                    data[1] = temp_rs.getString("contact");
                }
                query = "SELECT * FROM bed_booking WHERE case_id = " + case_id;
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    bed_id = Integer.parseInt(temp_rs.getString("bed_id"));
                    data[2] = temp_rs.getString("booking_date");
                }
                query = "SELECT * FROM beds WHERE bed_id = " + bed_id + " ";
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString("room_num");
                    data[4] = temp_rs.getString("floor");
                    data[5] = temp_rs.getString("type");
                }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("from running pat:   " + ex);
        }
        tbl_title = "Running In Ptient Cases";
        lbl_tbl_title.setText(tbl_title);

    }//GEN-LAST:event_btn_run_in_patActionPerformed

    private void btn_removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_removeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_removeActionPerformed
    public void edit_This_Account() {

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        //  UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (admin = new Admin_Module()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_account;
    private javax.swing.JButton btn_go_details;
    private javax.swing.JButton btn_login_out;
    private javax.swing.JButton btn_new_bed;
    private javax.swing.JButton btn_new_department;
    private javax.swing.JButton btn_new_doc;
    private javax.swing.JButton btn_new_nurse;
    private javax.swing.JButton btn_new_service;
    private javax.swing.JButton btn_new_sys_e;
    private javax.swing.JButton btn_new_test;
    private javax.swing.JButton btn_remove;
    private javax.swing.JButton btn_run_in_pat;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_surgery;
    private javax.swing.JButton btn_surgery_cases;
    private javax.swing.JButton btn_update;
    private javax.swing.JButton btn_update_profile;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmb_bed_by_type;
    private javax.swing.JComboBox<String> cmb_doc_by_dept;
    private javax.swing.JComboBox<String> cmb_nurse_by_dept;
    private javax.swing.JComboBox<String> cmb_search_By;
    private javax.swing.JComboBox<String> cmb_surBy_dept;
    private javax.swing.JComboBox<String> cmb_sur_by_type;
    private javax.swing.JComboBox<String> cmb_test_bu_type;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel jpnl_functions;
    private javax.swing.JPanel jpnl_grand;
    private javax.swing.JPanel jpnl_login;
    private javax.swing.JPanel jpnl_scrollwith;
    private javax.swing.JPanel jpnl_sup_grand;
    private javax.swing.JLabel lbl_missmtch1;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JLabel lbl_tbl_title;
    private javax.swing.JRadioButton rbtn_edit;
    private javax.swing.JRadioButton rbtn_new;
    private javax.swing.JRadioButton rbtn_view;
    private javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_conf_pass;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextField txt_search_content2;
    private javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables

    public void acknowledgement_Or_Warning(String warning_Msg, int time) {
        //  jOptionPane = new JOptionPane(warning_Msg, JOptionPane.INFORMATION_MESSAGE);
        //  final JDialog dialog = jOptionPane.createDialog("pokath!");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (time == 1650) {
                    lbl_missmtch1.setText("");
                } else {
                    lbl_msg.setText("");
                }
            }
        }).start();
        if (time == 1650) {
            lbl_missmtch1.setText(warning_Msg);
        } else {
            lbl_msg.setText(warning_Msg);
        }
    }

    public void doc_Profiler() {
        try {
            btn_x = new JButton("Close");
            jpnl_grand.add(btn_x);
            btn_x.setLocation(330, 0);
            btn_x.setSize(50, 20);
            btn_x.setBackground(new Color(0, 0, 0));
            btn_x.setBorder(new LineBorder(Color.BLACK, 1));
            btn_x.setForeground(new Color(255, 255, 153));
            btn_x.addActionListener(this);
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM doctors WHERE doc_id = " + running_ProfileID + "";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("got here ");
                lbl_name.setText("Name:   " + rs.getString("name") + "  ID: " + rs.getString("doc_id"));
                System.out.println("got here " + rs.getString("name"));
                lbl_email.setText("Email:   " + rs.getString("email"));
                lbl_con.setText("Contact:   " + rs.getString("contact"));
                lbl_c_add.setText("Cur Add:   " + rs.getString("cur_add"));
                lbl_p_add.setText("Per Add:   " + rs.getString("per_add"));
                lbl_dept.setText("Dept:   " + rs.getString("dept"));
                lbl_desg.setText("Desg/Type:   " + rs.getString("degrees"));
                lbl_dob.setText("DOB:   " + rs.getString("dob"));
                lbl_doj.setText("DOJ:   " + rs.getString("doj"));
                lbl_con_fee.setText("Consultation Fee: " + rs.getInt("consultation_fee"));
                lbl_app_fee.setText("Appointment Fee: " + rs.getInt("appointment_fee"));
                lbl_nid.setText("NID:   " + rs.getString("nid"));
                lbl_salery.setText("Chamber: " + rs.getString("office"));
            }
            query = "Select * FROM accounts where user_id = " + running_ProfileID;
            rs = st.executeQuery(query);
            lbl_module.setText("Module Account:   None .");
            while (rs.next()) {
                lbl_module.setText("Module Account:   " + rs.getString("module"));
            }
            btn_sch = new JButton("Doc Schedule");
            jpnl_grand.add(btn_sch);
            btn_sch.setLocation(140, 0);
            btn_sch.setSize(125, 25);
            btn_sch.setFont(new Font("Tahoma", Font.BOLD, 17));
            btn_sch.setBackground(new Color(0, 0, 0));
            btn_sch.setBorder(new LineBorder(Color.BLACK, 1));
            btn_sch.setForeground(new Color(255, 255, 153));
            btn_sch.addActionListener(this);
            jpnl_grand.setVisible(false);
            jpnl_grand.setVisible(true);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void nurse_Profiler() {
        try {
            btn_x = new JButton("Close");
            jpnl_grand.add(btn_x);
            btn_x.setLocation(330, 0);
            btn_x.setSize(50, 20);
            btn_x.setBackground(new Color(0, 0, 0));
            btn_x.setBorder(new LineBorder(Color.BLACK, 1));
            btn_x.setForeground(new Color(255, 255, 153));
            btn_x.addActionListener(this);
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM nurses WHERE nurse_id = '" + running_ProfileID + "'";
            rs = st.executeQuery(query);
            while (rs.next()) {
                lbl_name.setText("Name:   " + rs.getString("name") + "  ID: " + rs.getString("nurse_id"));
                lbl_email.setText("Email:   " + rs.getString("email"));
                lbl_con.setText("Contact:   " + rs.getString("contact"));
                lbl_c_add.setText("Cur Add:   " + rs.getString("cur_add"));
                lbl_p_add.setText("Per Add:   " + rs.getString("per_add"));
                lbl_dept.setText("Dept:   " + rs.getString("dept"));
                lbl_desg.setText("Desg/Type:   " + rs.getString("type"));
                lbl_gender.setText("Gender:   " + rs.getString("gender"));
                lbl_dob.setText("DOB:   " + rs.getString("dob"));
                lbl_doj.setText("DOJ:   " + rs.getString("doj"));
                lbl_salery.setText("Salery:   " + rs.getString("salery"));
                lbl_nid.setText("NID:   " + rs.getString("nid"));
            }
            query = "Select * FROM accounts where user_id = " + running_ProfileID;
            rs = st.executeQuery(query);
            lbl_module.setText("Module Account:   None .");
            while (rs.next()) {
                lbl_module.setText("Module Account:   " + rs.getString("module"));
            }
            jpnl_grand.setVisible(false);
            jpnl_grand.setVisible(true);

        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    public void executive_memberProfiler() {
        try {
            btn_x = new JButton("Close");
            jpnl_grand.add(btn_x);
            btn_x.setLocation(330, 0);
            btn_x.setSize(50, 20);
            btn_x.setBackground(new Color(0, 0, 0));
            btn_x.setBorder(new LineBorder(Color.BLACK, 1));
            btn_x.setForeground(new Color(255, 255, 153));
            btn_x.addActionListener(this);
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM system_executives WHERE member_id = '" + running_ProfileID + "'";
            rs = st.executeQuery(query);
            while (rs.next()) {
                lbl_name.setText("Name:   " + rs.getString("name") + "  ID: " + rs.getString("member_id"));
                lbl_email.setText("Email:   " + rs.getString("email"));
                lbl_con.setText("Contact:   " + rs.getString("contact"));
                lbl_c_add.setText("Cur Add:   " + rs.getString("cur_add"));
                lbl_p_add.setText("Per Add:   " + rs.getString("per_add"));
                lbl_desg.setText("Desg/Type:   " + rs.getString("degrees"));
                lbl_nid.setText("NID:   " + rs.getString("nid"));
            }
            query = "Select * FROM accounts where user_id = " + running_ProfileID;
            rs = st.executeQuery(query);
            lbl_module.setText("Module Account:   None .");
            while (rs.next()) {
                lbl_module.setText("Module Account:   " + rs.getString("module"));
            }
            jpnl_grand.setVisible(false);
            jpnl_grand.setVisible(true);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void service_Profiler() {

    }

    public void label_Maker() {
        lbl_name = new JLabel();
        lbl_name.setSize(360, 18);
        lbl_email = new JLabel();
        lbl_email.setSize(360, 18);
        lbl_con = new JLabel();
        lbl_con.setSize(360, 17);
        lbl_nid = new JLabel();
        lbl_nid.setSize(360, 17);
        lbl_p_add = new JLabel();
        lbl_p_add.setSize(360, 17);
        lbl_c_add = new JLabel();
        lbl_c_add.setSize(360, 17);
        lbl_dept = new JLabel();
        lbl_dept.setSize(360, 17);
        lbl_desg = new JLabel();
        lbl_desg.setSize(360, 17);
        lbl_gender = new JLabel();
        lbl_gender.setSize(360, 17);
        lbl_app_fee = new JLabel();
        lbl_app_fee.setSize(360, 17);
        lbl_con_fee = new JLabel();
        lbl_con_fee.setSize(360, 17);
        lbl_module = new JLabel();
        lbl_module.setSize(360, 17);
        lbl_dob = new JLabel();
        lbl_dob.setSize(360, 17);
        lbl_doj = new JLabel();
        lbl_doj.setSize(360, 17);
        lbl_office = new JLabel();
        lbl_office.setSize(360, 17);
        lbl_salery = new JLabel();
        lbl_salery.setSize(360, 17);
        jpnl_grand.add(lbl_name);
        jpnl_grand.add(lbl_email);
        jpnl_grand.add(lbl_con);
        jpnl_grand.add(lbl_gender);
        jpnl_grand.add(lbl_nid);
        jpnl_grand.add(lbl_c_add);
        jpnl_grand.add(lbl_p_add);
        jpnl_grand.add(lbl_dept);
        jpnl_grand.add(lbl_desg);
        jpnl_grand.add(lbl_dob);
        jpnl_grand.add(lbl_doj);
        jpnl_grand.add(lbl_salery);
        jpnl_grand.add(lbl_office);
        jpnl_grand.add(lbl_module);
        jpnl_grand.add(lbl_app_fee);
        jpnl_grand.add(lbl_con_fee);
        lbl_name.setLocation(10, 55);
        lbl_name.setFont(new Font("Tahoma", Font.BOLD, 17));
        lbl_email.setLocation(10, 85);
        lbl_email.setFont(new Font("Tahoma", Font.BOLD, 14));
        lbl_con.setLocation(10, 110);
        lbl_con.setFont(new Font("Tahoma", Font.BOLD, 14));
        lbl_dept.setLocation(10, 135);
        lbl_dept.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_desg.setLocation(10, 160);
        lbl_desg.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_c_add.setLocation(10, 185);
        lbl_c_add.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_p_add.setLocation(10, 210);
        lbl_p_add.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_gender.setLocation(10, 235);
        lbl_gender.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_nid.setLocation(10, 260);
        lbl_nid.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_dob.setLocation(10, 285);
        lbl_dob.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_doj.setLocation(10, 310);
        lbl_doj.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_app_fee.setLocation(10, 335);
        lbl_app_fee.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_con_fee.setLocation(10, 360);
        lbl_con_fee.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_salery.setLocation(10, 385);
        lbl_salery.setFont(new Font("Tahoma", Font.BOLD, 15));
        lbl_module.setLocation(35, 410);
        lbl_module.setFont(new Font("Tahoma", Font.BOLD, 17));
        btn_editProfile = new JButton("Edit Info.");
        btn_editProfile.setFont(new Font("Tahoma", Font.BOLD, 17));
        btn_editProfile.setLocation(80, 460);
        btn_editProfile.setSize(145, 23);
        btn_editProfile.addActionListener(this);
        jpnl_grand.add(btn_editProfile);
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }

    public void import_editableForm() {
        if (running_ProfileType.contains("Nurse")) {
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((nurse = new Nurse_Panel(1)));
            nurse.setLocation(250, 20);
            jpnl_sup_grand.setVisible(true);
        }
        if (running_ProfileType.contains("Executive")) {
            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((member_form = new System_Member_Panel(1)));
            member_form.setLocation(20, 20);
            jpnl_sup_grand.setVisible(true);
        }
        if (running_ProfileType.contains("Doctor")) {

            jpnl_sup_grand.removeAll();
            jpnl_sup_grand.setVisible(false);
            jpnl_sup_grand.add((new_doc = new Doc_Panel(1)));
            new_doc.setLocation(20, 20);
            jpnl_sup_grand.setVisible(true);

        }
        if (running_ProfileType.contains("Service")) {

        }
        if (running_ProfileType.contains("Test")) {

        }
    }
}
