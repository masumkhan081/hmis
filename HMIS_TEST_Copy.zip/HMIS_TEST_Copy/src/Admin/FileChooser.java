package Admin;

import static Admin.Admin_Module.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Masum Khan
 */
public class FileChooser extends javax.swing.JFrame implements ActionListener {

    static String file_Path;
    static int file_Type_Sign = 0;
    static String path;
    static int i = 0, j = 0;
    static int image_sign;

    public FileChooser(int i) {

        image_sign = i;
        initComponents();
        setDefaultCloseOperation(1);
        setLocationRelativeTo(null);
        file_Chooser_Frame.addActionListener(this);
        FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg");
        file_Chooser_Frame.setFileFilter(filter);
        // file_Chooser_Frame.setFileSystemView(new Fil);
        setVisible(true);

    }
//
//    public static void main(String args[]) {
//    new FileChooser(0).setVisible(true);
//
//    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getActionCommand().equals("CancelSelection")) {

            System.out.println("Cancel");
            setVisible(false);
        }
        if (ae.getActionCommand().equals("ApproveSelection")) {

            try {
                path = file_Chooser_Frame.getSelectedFile().getCanonicalPath();

                System.out.println(path);
            } catch (Exception ex) {
                System.out.println("reporting exp >> " + ex.getMessage());
            }
            System.out.println("pre " + image_sign);
            if (image_sign == 0) {
                nurse.set_Image(path);
                dispose();
            }
            if (image_sign == 1) {
                System.out.println(image_sign);
                new_doc.set_Image(path);
                dispose();
            }
            if (image_sign == 2) {
                System.out.println(image_sign);
                member_form.set_Image(path);
                dispose();
            }
        }

//                            pre.setBinaryStream(2, (InputStream) fin, (int) imgfile.length());
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTimeChooserDemo1 = new lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo();
        birthdayEvaluator1 = new com.toedter.calendar.demo.BirthdayEvaluator();
        birthdayEvaluator2 = new com.toedter.calendar.demo.BirthdayEvaluator();
        imageUtils1 = new com.lavantech.gui.comp.ImageUtils();
        file_Chooser_Frame = new javax.swing.JFileChooser();
        lbl_pic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));

        file_Chooser_Frame.setApproveButtonText("open");
        file_Chooser_Frame.setBackground(new java.awt.Color(153, 153, 255));
        file_Chooser_Frame.setCurrentDirectory(new java.io.File("C:\\Users\\Masum Khan\\Desktop"));
        file_Chooser_Frame.setFont(new java.awt.Font("MingLiU_HKSCS-ExtB", 1, 13)); // NOI18N
        file_Chooser_Frame.setForeground(new java.awt.Color(51, 51, 51));
        file_Chooser_Frame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                file_Chooser_FrameActionPerformed(evt);
            }
        });

        lbl_pic.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(file_Chooser_Frame, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_pic, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(file_Chooser_Frame, javax.swing.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(lbl_pic, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void file_Chooser_FrameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_file_Chooser_FrameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_file_Chooser_FrameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator1;
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator2;
    private javax.swing.JFileChooser file_Chooser_Frame;
    private com.lavantech.gui.comp.ImageUtils imageUtils1;
    private lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo jTimeChooserDemo1;
    private javax.swing.JLabel lbl_pic;
    // End of variables declaration//GEN-END:variables

}
