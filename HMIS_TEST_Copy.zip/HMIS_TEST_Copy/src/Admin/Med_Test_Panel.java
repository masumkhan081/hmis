/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import static Admin.Admin_Module.*;
import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

public class Med_Test_Panel extends javax.swing.JPanel implements ActionListener {

    /**
     * Creates new form Med_Test_Panel
     */
    public String test_name, method, type;
    public Button btn_save, btn_clear;
    public JLabel lbl_price;
    public JTextField txt_price;
    public ArrayList<JTextField> list;
    public int x, num_component, price;
    public ArrayList<String> compnt_names;
    public ArrayList<String> ranges;
    public ArrayList<String> units;

    public Med_Test_Panel(int dick) {
        initComponents();
        setVisible(true);
        setSize(894, 510);

        btn_go.addActionListener(this);
        if (dick == 1) {
            set_Profile();
        }
    }

    public static void main(String args[]) {
        member_ID = 3;
        jfr = new JFrame();
        jfr.setSize(1049, 548);
        jfr.setLocationRelativeTo(null);

        jfr.add((med_test = new Med_Test_Panel(0)));
        med_test.setLocation(10, 10);
        System.out.println("vvvvvvvvvvvvvvvvvvvvvv");
        //  jfr.setAlwaysOnTop(true);
        //  jfr.setUndecorated(true);
        jfr.setDefaultCloseOperation(1);
        jfr.setVisible(true);
    }

    public void set_Profile() {

    }

    public void actionPerformed(ActionEvent ae) {
        price = 0;
        sign = false;

        if (ae.getSource() == btn_save) {

            compnt_names = new ArrayList<>();
            ranges = new ArrayList<>();
//            ArrayList<Integer> charges = new ArrayList<>();
            units = new ArrayList<>();
            String name, range, unit;
            int charge = 0;
            sign = false;

            try {
                price = Integer.parseInt(txt_price.getText());
            } catch (NumberFormatException nfe) {
                sign = true;
                acknowledgement_Or_Warning("Invalid total price amount ", 1400);

            }
            if (sign == false && price == 0) {
                sign = true;
                acknowledgement_Or_Warning("Invalid price amount", 1400);
            }

            if (sign == false) {
                for (int i = 0; i < num_component; i++) {
                    name = list.get(i).getText();
                    range = list.get(i + num_component).getText();
                    unit = list.get(i + (num_component * 2)).getText();
//                    try {
//                        charge = Integer.parseInt(list.get(i + (num_component * 3)).getText());
//                    } catch (Exception ex) {
//                        sign = true;
//                        acknowledgement_Or_Warning("check Out component charge  !", 1900);
//                    }
                    if (sign == false && (name.isEmpty() || range.isEmpty())) {
                        sign = true;
                        acknowledgement_Or_Warning("component name & refference can't be empty  !", 2500);
                    }
                    if (sign == false) {
                        System.out.println(name + "  " + range + "  " + unit + "  " + "\n" + (i + num_component) + " " + (i + num_component * 2));

                        compnt_names.add(name);
                        units.add(unit);
                        ranges.add(range);

                    }
                    System.out.println("I am sign mr. Masum Khan" + sign);
                }
            }

            if (sign == false) {
                try {

                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(url + dbName, db_userName, db_password);

                    st = con.createStatement();
                    int new_test_id = 1;
                    query = "SELECT test_id  FROM med_tests ORDER BY test_id  DESC LIMIT 1;";
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        new_test_id = rs.getInt(1) + 1;
                    }

                    pst = con.prepareStatement("insert into med_tests values(?,?,?,?,?,?)");
                    pst.setInt(1, 0);
                    pst.setString(2, test_name);
                    pst.setString(3, type);
                    pst.setInt(4, price);
                    pst.setString(5, method);
                    pst.setString(6, jTextArea1.getText());
                    pst.executeUpdate();

                    for (int i = 0; i < compnt_names.size(); i++) {
                        pst = con.prepareStatement("insert into test_structure values(?,?,?,?)");
                        pst.setInt(1, new_test_id);
                        pst.setString(2, compnt_names.get(i));
                        pst.setString(3, units.get(i));
                        pst.setString(4, ranges.get(i));
                        pst.executeUpdate();
                    }
                    txt_test_name.setText("");
                    txt_method.setText("");
                    txt_type.setText("");
                    jPanel8.removeAll();
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                acknowledgement_Or_Warning("Saved ", 1300);
            }
        }

        if (ae.getSource() == btn_clear) {
            System.out.println(list.size());
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setText("");
            }

            txt_price.setText("");
        }
    }

    public void acknowledgement_Or_Warning(String msg, int time) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_msg.setText("");
                if (msg.equals("Saved ")) {
                    for (int i = 0; i < list.size(); i++) {
                        list.get(i).setText("");
                    }
                    txt_price.setText("");
                }

            }
        }).start();
        lbl_msg.setText(msg);

    }

    public void method(int len) {

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_test_name = new javax.swing.JTextField();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_go = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel8 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txt_type = new javax.swing.JTextField();
        txt_method = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lbl_msg = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(894, 510));
        jPanel1.setMinimumSize(new java.awt.Dimension(894, 510));

        txt_test_name.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N

        jSpinner1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jSpinner1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Test Name");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jLabel2.setText("Number of parameters");

        btn_go.setBackground(new java.awt.Color(204, 204, 255));
        btn_go.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        btn_go.setText("Go");
        btn_go.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_go.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_goActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel8.setMaximumSize(new java.awt.Dimension(770, 2400));
        jPanel8.setMinimumSize(new java.awt.Dimension(770, 500));
        jPanel8.setPreferredSize(new java.awt.Dimension(770, 1100));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1100, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel8);

        jButton3.setText(" PDF (Reference Value instructions)");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setText("Close");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        txt_type.setBackground(new java.awt.Color(204, 204, 255));
        txt_type.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txt_method.setBackground(new java.awt.Color(204, 204, 255));
        txt_method.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Test Type:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Testing Method:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt_method, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                    .addComponent(txt_type, javax.swing.GroupLayout.Alignment.TRAILING)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_type, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_method, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lbl_msg.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_msg.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Description ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 678, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_test_name, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton3))
                                .addGap(0, 0, 0)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(7, 7, 7)
                                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(btn_go))
                                    .addComponent(jLabel2)))
                            .addComponent(lbl_msg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(53, 53, 53))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(4, 4, 4)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_go, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(txt_test_name, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(1, 1, 1)
                .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addGap(7, 7, 7)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        admin.remove_med_test();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_goActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_goActionPerformed
        // TODO add your handling code here:

        int len = (int) jSpinner1.getValue();
        num_component = len;
        test_name = txt_test_name.getText();
        method = txt_method.getText();
        type = txt_type.getText();
        if (test_name.isEmpty()) {
            jPanel8.removeAll();
            acknowledgement_Or_Warning("Test Name required ", 1600);
            sign = true;
        }
        if (sign == false && len <= 0) {
            sign = true;
            jPanel8.removeAll();
            acknowledgement_Or_Warning("must be at least one component !", 2100);
        }
        if (sign == false && (method.isEmpty() || type.isEmpty())) {
            sign = true;
            jPanel8.removeAll();
            acknowledgement_Or_Warning("method & type define a test !", 1800);
        }
        if (sign == false) {

            jPanel8.removeAll();

            jPanel8.setVisible(false);
            list = new ArrayList();
            System.out.println("??? " + jPanel8.getMaximumSize());
            jScrollPane1.setMaximumSize(jPanel8.getMaximumSize());
            JLabel lbl_test_title = new JLabel("Title: " + test_name);
            lbl_test_title.setLocation(100, 5);
            lbl_test_title.setSize(270, 20);
            lbl_test_title.setFont(new Font("Meiryo", 19, 19));
            jPanel8.add(lbl_test_title);
            JLabel lbl_test = new JLabel("Test Parameters Name");
            lbl_test.setLocation(25, 35);
            lbl_test.setSize(220, 20);
            jPanel8.add(lbl_test);
            JLabel lbl_test2 = new JLabel("Reference Value");
            lbl_test2.setLocation(270, 35);
            lbl_test2.setSize(120, 20);
            jPanel8.add(lbl_test2);

            int x = 25;
            int y = 60;
            //    parameters ..................................................................
            for (int i = 0; i < len; i++) {

                list.add(new JTextField("" + i));
                list.get(list.size() - 1).setSize(230, 26);
                list.get(list.size() - 1).setLocation(x, y);
                jPanel8.add(list.get(list.size() - 1));

                y += 38;

            }

            y += 20;
            lbl_price = new JLabel("Charge ");
            lbl_price.setLocation(x, y);
            lbl_price.setSize(180, 20);
            lbl_price.setFont(new Font("Meiryo", 18, 18));
            jPanel8.add(lbl_price);

            y += 22;
            txt_price = new JTextField();
            txt_price.setBorder(new BevelBorder(1));
            txt_price.setLocation(x, y);
            txt_price.setSize(180, 30);
            txt_price.setFont(new Font("Meiryo", 20, 20));

            jPanel8.add(txt_price);

            x = 270;
            y = 60;
            //    reference  ......................................................................

            for (int i = 0; i < len; i++) {

                list.add(new JTextField());
                list.get(list.size() - 1).setSize(280, 26);
                list.get(list.size() - 1).setLocation(x, y);
                jPanel8.add(list.get(list.size() - 1));

                y += 38;

            }

            JLabel lbl_test4 = new JLabel(" Unit ");
            lbl_test4.setLocation(555, 35);
            lbl_test4.setSize(100, 20);

            jPanel8.add(lbl_test4);
            x = 560;
            y = 60;

            // unit     ......................................................................
            for (int i = 0; i < len; i++) {

                list.add(new JTextField());
                list.get(list.size() - 1).setSize(80, 26);
                list.get(list.size() - 1).setLocation(x, y);
                list.get(list.size() - 1).setFont(new Font("Meiryo", 16, 18));
                jPanel8.add(list.get(list.size() - 1));

                y += 38;

            }
//       222222222222222222222222222222222222222222222
//            JLabel lbl_test5 = new JLabel("Charge/component");
//            lbl_test5.setLocation(650, 35);
//            lbl_test5.setSize(130, 20);
//
//            jPanel8.add(lbl_test5);
//            x = 655;
//            y = 60;
//
//            //  charg/component    ......................................................................
//            for (int i = 0; i < len; i++) {
//
//                list.add(new JTextField());
//                list.get(list.size() - 1).setSize(85, 26);
//                list.get(list.size() - 1).setLocation(x, y);
//                list.get(list.size() - 1).setFont(new Font("Meiryo", 16, 18));
//                jPanel8.add(list.get(list.size() - 1));
//
//                y += 38;
//
//            }

//            y += 100;
//            JLabel lbl_test5 = new JLabel("Description ...");
//            lbl_test5.setLocation(25, y);
//            lbl_test5.setSize(160, 20);
//
//            jPanel8.add(lbl_test5);
//            y += 20;
//            JTextArea area = new JTextArea();
//            area.setSize(560, 100);
//            area.setLocation(25, y);
//            jPanel8.add(area);
            y += 100;
            btn_save = new Button("Save & Confirm");
            btn_save.setSize(140, 30);
            btn_save.setLocation(410, y);

            btn_save.addActionListener(this);
            jPanel8.add(btn_save);
            btn_clear = new Button("Clear");
            btn_clear.setSize(80, 30);
            btn_clear.setLocation(75, y);

            btn_clear.addActionListener(this);
            jPanel8.add(btn_clear);
            jPanel8.setVisible(true);
        }

    }//GEN-LAST:event_btn_goActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_go;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JTextField txt_method;
    private javax.swing.JTextField txt_test_name;
    private javax.swing.JTextField txt_type;
    // End of variables declaration//GEN-END:variables
}
