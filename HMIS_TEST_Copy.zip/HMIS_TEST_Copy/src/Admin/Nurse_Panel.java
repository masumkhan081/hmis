/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import static Admin.Admin_Module.*;
import javax.swing.UIManager.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.Blob;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;

/**
 *
 * @author pddrgj3q
 */
public class Nurse_Panel extends javax.swing.JPanel {

    /**
     * Creates new form Nurse_Panel
     */
    static int pX,
            /**
             * Creates new form Nurse_Panel
             */
            pY, dick;
    static File imgFile;
    static FileInputStream fin;
    static ImageIcon pc;
    
    ButtonGroup r_button_g;
    
    public Nurse_Panel(int i) {
        initComponents();
        
        setVisible(true);
        setSize(783, 481);
        jspn_date1.setEditor(new JSpinner.DateEditor(jspn_date1, "dd/MM/yy"));
        jspn_date1.setDate(new Date());
        jspn_date2.setEditor(new JSpinner.DateEditor(jspn_date2, "dd/MM/yy"));
        jspn_date2.setDate(new Date());
        date_Format = new SimpleDateFormat("dd/MM/yy");
        simpleDateFormat = new SimpleDateFormat();
        simpleDateFormat.applyPattern("dd/MM/yyyy");
        r_button_g = new ButtonGroup();
        r_button_g.add(male_RB);
        r_button_g.add(female_RB);
        r_in_pat_moduleActionPerformed(evt);
        dick = i;
        if (dick == 0) {
        }
        if (dick == 1) {
            set_Profile();
        }
        
    }
    
    public void set_Profile() {
        System.out.println("dick:  " + dick);
        
        String gen;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM nurses WHERE nurse_id = '" + running_ProfileID + "'";
            rs = st.executeQuery(query);
            while (rs.next()) {
                txt_Add_C.setText(rs.getString("cur_add"));
                txt_Add_P.setText(rs.getString("per_add"));
                txt_Contact_No.setText(rs.getString("contact"));
                txt_Email.setText(rs.getString("email"));
                txt_NID.setText(rs.getString("nid"));
                txt_Dept.setText(rs.getString("dept"));
                txt_Full_Name.setText(rs.getString("name"));
                txt_salery.setText("" + rs.getInt("salery"));
                txt_desg.setText(rs.getString("type"));
                gen = rs.getString("gender");
                
                if (gen != null) {
                    if (gen.equals("male")) {
                        male_RB.setSelected(true);
                    }
                    if (gen.equals("female")) {
                        female_RB.setSelected(true);
                    }
                }
                date_Format = new SimpleDateFormat("dd/MM/yyyy");
                try {
                    jspn_date1.setDate(date_Format.parse(rs.getString("dob")));
                    jspn_date2.setDate(date_Format.parse(rs.getString("doj")));
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
            txt_Add_C.setEditable(true);
            txt_Add_P.setEditable(true);
            txt_Contact_No.setEditable(true);
            txt_Dept.setEditable(true);
            txt_Email.setEditable(true);
            txt_Full_Name.setEditable(true);
            txt_NID.setEditable(true);
            txt_desg.setEditable(true);
            txt_salery.setEditable(true);
            txt_u_name.setVisible(false);
            btn_list_dept.setVisible(true);
            // r_in_pat_module.setVisible(true);
            query = "Select * FROM accounts where user_id = " + running_ProfileID;
            rs = st.executeQuery(query);
            lbl_module_que.setText("Module Account: None .");
            while (rs.next()) {
                lbl_module_que.setText("Module Account: " + rs.getString("module"));
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    public void set_Image(String path) {
        imgFile = new File(path);
        
        try {
            fin = new FileInputStream(imgFile);
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe.getMessage());
        }
        //  ImageIcon Myimage = new ImageIcon(path);
        try {
            Image img = ImageIO.read(imgFile);                    //Myimage.getImage();

            Image newImage = img.getScaledInstance(lbl_pic.getWidth(), lbl_pic.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon image = new ImageIcon(newImage);
            lbl_pic.setIcon(image);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_Image = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btn_Save = new javax.swing.JButton();
        btn_Reset = new javax.swing.JButton();
        jpnl_pic = new javax.swing.JPanel();
        lbl_pic = new javax.swing.JLabel();
        lbl_msg = new javax.swing.JLabel();
        txt_salery = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_desg = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jspn_date2 = new com.toedter.calendar.JSpinnerDateEditor();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_Full_Name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_Contact_No = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_Add_C = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_Add_P = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_NID = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        male_RB = new javax.swing.JRadioButton();
        female_RB = new javax.swing.JRadioButton();
        lbl_edit_form = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txt_u_name = new javax.swing.JTextField();
        r_in_pat_module = new javax.swing.JRadioButton();
        lbl_module_que = new javax.swing.JLabel();
        txt_Dept = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        btn_list_dept = new javax.swing.JButton();
        jspn_date1 = new com.toedter.calendar.JSpinnerDateEditor();
        jLabel13 = new javax.swing.JLabel();
        btn_exit = new javax.swing.JButton();

        setBackground(new java.awt.Color(0, 51, 51));

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));
        jPanel1.setMaximumSize(new java.awt.Dimension(704, 459));
        jPanel1.setMinimumSize(new java.awt.Dimension(704, 459));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        btn_Image.setFont(new java.awt.Font("Carlito", 1, 14)); // NOI18N
        btn_Image.setText("BROWSE IMAGE");
        btn_Image.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Image.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Image.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ImageActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel7.setText("Joining Date:");

        btn_Save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_Save.setText("Save");
        btn_Save.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_Save.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Save.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        btn_Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SaveActionPerformed(evt);
            }
        });

        btn_Reset.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_Reset.setText("clear");
        btn_Reset.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_Reset.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Reset.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ResetActionPerformed(evt);
            }
        });

        jpnl_pic.setBackground(new java.awt.Color(0, 51, 51));

        javax.swing.GroupLayout jpnl_picLayout = new javax.swing.GroupLayout(jpnl_pic);
        jpnl_pic.setLayout(jpnl_picLayout);
        jpnl_picLayout.setHorizontalGroup(
            jpnl_picLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_picLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_pic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnl_picLayout.setVerticalGroup(
            jpnl_picLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_picLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lbl_pic, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        lbl_msg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_msg.setText("..");

        txt_salery.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel8.setText("Salery :");

        jLabel9.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel9.setText("Type/Designation:");

        jspn_date2.setBackground(new java.awt.Color(15, 38, 38));
        jspn_date2.setBorder(null);
        jspn_date2.setForeground(new java.awt.Color(255, 204, 102));
        jspn_date2.setModel(new javax.swing.SpinnerDateModel());
        jspn_date2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jspn_date2.setMaximumSize(new java.awt.Dimension(125, 22));
        jspn_date2.setMinimumSize(new java.awt.Dimension(125, 22));
        jspn_date2.setPreferredSize(new java.awt.Dimension(125, 22));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnl_pic, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txt_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_Save, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbl_msg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_salery, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_Image, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jspn_date2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jpnl_pic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_Image, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspn_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_salery, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_Reset, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Save, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 0));
        jLabel1.setText("Full Name:");

        txt_Full_Name.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Full_Name.setBorder(null);
        txt_Full_Name.setDisabledTextColor(new java.awt.Color(51, 0, 0));
        txt_Full_Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_Full_NameActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 0, 0));
        jLabel2.setText("Email:");

        txt_Email.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Email.setBorder(null);
        txt_Email.setDisabledTextColor(new java.awt.Color(51, 0, 0));
        txt_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_EmailActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 0, 0));
        jLabel3.setText("Contact No:");

        txt_Contact_No.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Contact_No.setBorder(null);
        txt_Contact_No.setDisabledTextColor(new java.awt.Color(51, 0, 0));

        jLabel4.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 0, 0));
        jLabel4.setText("Address: (Current)");

        txt_Add_C.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Add_C.setBorder(null);
        txt_Add_C.setDisabledTextColor(new java.awt.Color(51, 0, 0));

        jLabel6.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 0, 0));
        jLabel6.setText("Address:(permanent)");

        txt_Add_P.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Add_P.setBorder(null);
        txt_Add_P.setDisabledTextColor(new java.awt.Color(51, 0, 0));

        jLabel5.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 0, 0));
        jLabel5.setText("NID:");

        txt_NID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_NID.setBorder(null);
        txt_NID.setDisabledTextColor(new java.awt.Color(51, 0, 0));
        txt_NID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_NIDActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel14.setText(" Birth Date:");

        male_RB.setBackground(new java.awt.Color(204, 204, 255));
        male_RB.setFont(new java.awt.Font("Meiryo", 1, 11)); // NOI18N
        male_RB.setText("Male");
        male_RB.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 51, 51)));

        female_RB.setBackground(new java.awt.Color(204, 204, 255));
        female_RB.setFont(new java.awt.Font("Meiryo", 1, 11)); // NOI18N
        female_RB.setText("Female");
        female_RB.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 51, 51)));
        female_RB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                female_RBActionPerformed(evt);
            }
        });

        lbl_edit_form.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jPanel4.setBackground(new java.awt.Color(0, 51, 51));

        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });

        r_in_pat_module.setBackground(new java.awt.Color(0, 51, 51));
        r_in_pat_module.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        r_in_pat_module.setForeground(new java.awt.Color(255, 204, 102));
        r_in_pat_module.setText("In-Patient Care");
        r_in_pat_module.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                r_in_pat_moduleActionPerformed(evt);
            }
        });

        lbl_module_que.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_module_que.setForeground(new java.awt.Color(204, 204, 255));
        lbl_module_que.setText("Module Use Right ?");
        lbl_module_que.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 153, 51)));

        txt_Dept.setEditable(false);
        txt_Dept.setBackground(new java.awt.Color(204, 255, 204));
        txt_Dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_Dept.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_Dept.setToolTipText("");
        txt_Dept.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(102, 51, 0)));
        txt_Dept.setMaximumSize(new java.awt.Dimension(284, 28));
        txt_Dept.setMinimumSize(new java.awt.Dimension(284, 28));
        txt_Dept.setPreferredSize(new java.awt.Dimension(284, 28));
        txt_Dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DeptActionPerformed(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(204, 255, 204));
        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(204, 255, 204));
        jLabel16.setText("Department");

        btn_list_dept.setBackground(new java.awt.Color(0, 21, 21));
        btn_list_dept.setFont(new java.awt.Font("Algerian", 1, 11)); // NOI18N
        btn_list_dept.setForeground(new java.awt.Color(204, 255, 204));
        btn_list_dept.setText("...");
        btn_list_dept.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_list_dept.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btn_list_dept.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btn_list_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_list_deptActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(r_in_pat_module, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addComponent(lbl_module_que, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_u_name, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(txt_Dept, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btn_list_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, 0))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lbl_module_que)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(r_in_pat_module)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_Dept, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_list_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(258, 258, 258))
        );

        jspn_date1.setBackground(new java.awt.Color(15, 38, 38));
        jspn_date1.setBorder(null);
        jspn_date1.setForeground(new java.awt.Color(255, 204, 102));
        jspn_date1.setModel(new javax.swing.SpinnerDateModel());
        jspn_date1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Add_P, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txt_Add_C, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Contact_No, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_edit_form, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_Full_Name, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(male_RB, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(female_RB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(txt_NID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(lbl_edit_form, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Full_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Contact_No, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Add_C, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Add_P, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_NID, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(male_RB, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(female_RB, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel13.setFont(new java.awt.Font("MingLiU_HKSCS-ExtB", 1, 15)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 153));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("    Personal Info & Info. For Hospital Use");
        jLabel13.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 1, new java.awt.Color(102, 51, 0)));

        btn_exit.setBackground(new java.awt.Color(0, 51, 51));
        btn_exit.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 204, 102));
        btn_exit.setText("X");
        btn_exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 743, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ImageActionPerformed
        // TODO add your handling code here:
        FileChooser obj = new FileChooser(0);
    }//GEN-LAST:event_btn_ImageActionPerformed
    public void acknowledgement_Or_Warning(String msg, int time) {
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_msg.setText("");
                
            }
        }).start();
        lbl_msg.setText(msg);
        
    }
    private void btn_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SaveActionPerformed
        // TODO add your handling code here:

        sign = false;
        int salery = 0;
        String type = "";
        id = 1;
        type = txt_desg.getText();
        dept = txt_Dept.getText();
        try {
            dob = date_Format.format(jspn_date1.getDate());
            doj = date_Format.format(jspn_date2.getDate());
        } catch (Exception npe) {
            System.out.println("in dob,doj conversion: " + npe);
        }
        if (dob == null || doj == null) {
            System.out.println("f*** off !");
        }
        System.out.println(doj + " >>  " + dob);
        if (male_RB.isSelected()) {
            gender = "male";
        }
        if (female_RB.isSelected()) {
            gender = "female";
        }
        module_user_name = txt_u_name.getText();
        name = txt_Full_Name.getText();
        email = txt_Email.getText();
        nid = txt_NID.getText();
        contact = txt_Contact_No.getText();
        p_add = txt_Add_P.getText();
        c_add = txt_Add_C.getText();
        
        if (name.isEmpty() || contact.isEmpty() || (c_add.isEmpty() && p_add.isEmpty())) {
            System.out.println("incomplete !!");
            sign = true;
            acknowledgement_Or_Warning("Too incomplete ", 1800);
        }
        if (sign == false && r_in_pat_module.isSelected() && (module_user_name.length() < 6 || module_user_name.equals("user name.."))) {
            sign = true;
            acknowledgement_Or_Warning("module user name = ? ", 1800);
        }
        if (sign == false) {
            try {
                salery = Integer.parseInt(txt_salery.getText());
            } catch (Exception exp) {
                sign = true;
                acknowledgement_Or_Warning("Uncountable salery", 2000);
            }
        }
        if (sign == false && dick == 1) {
            nurse_ID = 2;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                
                query = "UPDATE nurses SET"
                        + " nurse_id = ? ,"
                        + " dept =?,"
                        + " name =? ,"
                        + " email = ? ,"
                        + " contact = ? ,"
                        + " per_add = ? ,"
                        + " cur_add = ? ,"
                        + " nid = ? ,"
                        + " gender = ? ,"
                        + " dob = ? ,"
                        + " doj= ? ,"
                        + " type = ? ,"
                        + " salery = ? ,"
                        + " image = ? "
                        + " WHERE nurse_id = " + nurse_ID + " ";
                pst = con.prepareStatement(query);
                pst.setInt(1, nurse_ID);
                pst.setString(2, dept);
                pst.setString(3, name);
                pst.setString(4, email);
                pst.setString(5, contact);
                pst.setString(6, p_add);
                pst.setString(7, c_add);
                pst.setString(8, nid);
                pst.setString(9, gender);
                pst.setString(10, dob);
                pst.setString(11, doj);
                pst.setString(12, type);
                pst.setInt(13, salery);
                if (fin == null) {
                    pst.setBinaryStream(14, is);
                }
                if (fin != null) {
                    pst.setBinaryStream(14, (InputStream) fin, (int) imgFile.length());
                }
                pst.executeUpdate();
            } catch (Exception exp) {
                System.out.println(exp);
            }
            btn_ResetActionPerformed(evt);
        }
        if (sign == false && dick == 0) {
            try {
                
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                nurse_ID = 1;
                query = "SELECT nurse_id  FROM  nurses ORDER BY nurse_id  DESC LIMIT 1;";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    nurse_ID = rs.getInt(1) + 1;
                }
                System.out.println();
                if (module_right == true) {
                    
                    pass = "NU" + nurse_ID + "-" + Admin_Module.get_auto_generated_pass();
                    pst = con.prepareStatement("insert into accounts values(?,?,?,?,?,?,?)");
                    System.out.println("pass $$ " + pass);
                    pst.setInt(1, nurse_ID);
                    pst.setString(2, module_user_name);
                    pst.setString(3, pass);
                    pst.setString(4, "Never Logged In");
                    pst.setString(5, "Nurse");
                    pst.setString(6, email);
                    pst.setString(7, "IPCU");
                    pst.executeUpdate();
                }
                pst = con.prepareStatement("insert into nurses values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, nurse_ID);
                pst.setString(2, dept);
                pst.setString(3, name);
                pst.setString(4, email);
                pst.setString(5, contact);
                pst.setString(6, p_add);
                pst.setString(7, c_add);
                pst.setString(8, nid);
                pst.setString(9, gender);
                pst.setString(10, dob);
                pst.setString(11, doj);
                pst.setString(12, type);
                pst.setInt(13, salery);
                if (fin == null) {
                    pst.setBinaryStream(14, is);
                }
                if (fin != null) {
                    pst.setBinaryStream(14, (InputStream) fin, (int) imgFile.length());
                }
                System.out.println("before execution");
                pst.executeUpdate();
                con.close();
                st.close();
                
            } catch (Exception ex) {
                System.out.println(ex);
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(1200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    btn_ResetActionPerformed(evt);
                }
            }).start();
            acknowledgement_Or_Warning("S A V E D !", 2200);
        }
    }//GEN-LAST:event_btn_SaveActionPerformed
//    public static void main(String args[]) {
//        jfr = new JFrame();
//        jfr.setSize(800, 548);
//        jfr.setLocationRelativeTo(null);
//        jfr.add((nurse = new Nurse_Panel(1)));
//        nurse.setLocation(10, 10);
//        jfr.setDefaultCloseOperation(1);
//        jfr.setVisible(true);
//    }
    private void btn_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ResetActionPerformed
        // TODO add your handling code here:
        txt_Add_C.setText("");
        txt_Add_P.setText("");
        txt_Contact_No.setText("");
        txt_Email.setText("");
        txt_Full_Name.setText("");
        txt_NID.setText("");
        r_in_pat_module.setSelected(false);
        txt_u_name.setText("user name..");
        r_button_g.clearSelection();
        jspn_date2.setDate(new Date());
        jspn_date1.setDate(new Date());
        lbl_pic.setIcon(null);
        txt_Dept.setText("");
        txt_salery.setText("");
        txt_desg.setText("");
    }//GEN-LAST:event_btn_ResetActionPerformed

    private void txt_Full_NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_Full_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_Full_NameActionPerformed

    private void txt_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_EmailActionPerformed

    private void txt_NIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_NIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_NIDActionPerformed

    private void female_RBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_female_RBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_female_RBActionPerformed

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        // TODO add your handling code here:
        admin.remove_Nurse();
    }//GEN-LAST:event_btn_exitActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void r_in_pat_moduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_r_in_pat_moduleActionPerformed
        // TODO add your handling code here:
        if (r_in_pat_module.isSelected()) {
            module_right = true;
            txt_u_name.setEnabled(true);
        }
        if (!r_in_pat_module.isSelected()) {
            module_right = false;
            txt_u_name.setEnabled(false);
        }
    }//GEN-LAST:event_r_in_pat_moduleActionPerformed

    private void txt_DeptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DeptActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DeptActionPerformed
    public void set_dept_Name(String dept_name) {
        System.out.println("dept: " + dept);
        dept = dept_name;
        txt_Dept.setText(dept);
    }
    private void btn_list_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_list_deptActionPerformed
        // TODO add your handling code here:
        try {
            if (suggestion == null) {
                System.out.println("got null");
                suggestion = new Suggestion_List("dept", "nurse");
            }
            if (suggestion.isVisible()) {
                suggestion.setVisible(true);
                suggestion.setAlwaysOnTop(true);
            }
        } catch (NullPointerException npe) {
            System.out.println(npe);
            suggestion = new Suggestion_List("dept", "nurse");
        }
    }//GEN-LAST:event_btn_list_deptActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Image;
    private javax.swing.JButton btn_Reset;
    private javax.swing.JButton btn_Save;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_list_dept;
    private javax.swing.JRadioButton female_RB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jpnl_pic;
    private com.toedter.calendar.JSpinnerDateEditor jspn_date1;
    private com.toedter.calendar.JSpinnerDateEditor jspn_date2;
    private javax.swing.JLabel lbl_edit_form;
    private javax.swing.JLabel lbl_module_que;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JLabel lbl_pic;
    private javax.swing.JRadioButton male_RB;
    private javax.swing.JRadioButton r_in_pat_module;
    private javax.swing.JTextField txt_Add_C;
    private javax.swing.JTextField txt_Add_P;
    private javax.swing.JTextField txt_Contact_No;
    private javax.swing.JTextField txt_Dept;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_Full_Name;
    private javax.swing.JTextField txt_NID;
    private javax.swing.JTextField txt_desg;
    private javax.swing.JTextField txt_salery;
    private javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables
}
