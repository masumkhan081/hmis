/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Doctor;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pddrgj3q
 */
public class Doctor_Module extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form new_Doctor
     */
    static FileWriter file_Writer;
    static BufferedWriter buffer_Writer;
    static String folderPath = "c:" + File.separator + "HMIS_Temp",
            pathOfpresFile = "C:" + File.separator + "HMIS_Temp" + File.separator + "pres.txt";
    static Scanner scannerObjOfPres;
    static InputStream is;
    static FileInputStream fin;
    static File prescription;
    static View_Self_Schedule my_schedule;
    static int app_id = 0, pat_id, doc_id, test_id, case_id, ser_id, bed_id, pX, pY, temp_id;
    static String name, email, contact, doj, p_add, c_add, gender, age, dept_name, receipt_Code, pres, bed_type, pat_type, search_content, dept;
    static ArrayList<Integer> ids;
    static Doctor_Module doc_module;
    static Connection con = null;
    static Statement st = null;
    static ResultSet rs;
    static String query;
    static ResultSet temp_rs;
    static Statement temp_st = null;
    static String temp_query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String db_userName = "root";
    static String db_password = "";
    static ArrayList<String> sugg;
    static SimpleDateFormat simpleDateFormat;
    static DateFormat date_Format;
    private int module_User_ID;
    String module_User_Pass, module_User_Name;
    static boolean sign;
    static DefaultListModel jlist_model;
    private int running_pat;
    static java.awt.event.ActionEvent evt;
    static DefaultComboBoxModel cmb_model;

    public Doctor_Module() {

        initComponents();
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        txt_pres.setEnabled(false);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
        chk_write_presActionPerformed(evt);
        txt_search_content.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                search_content = txt_search_content.getText();
                btn_searchActionPerformed(evt);
            }

            public void removeUpdate(DocumentEvent e) {
                search_content = txt_search_content.getText();
                btn_searchActionPerformed(evt);
            }

            public void insertUpdate(DocumentEvent e) {
                search_content = txt_search_content.getText();
                btn_searchActionPerformed(evt);
            }

        });
        module_User_ID = 1;
        set_patBy_Depts();
        set_generics();
        //  set_Frame_to_Initial(false);
    }

    public void set_generics() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + "full_pms", db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT generic from drug_stock;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_drug_byGeneric.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
    }

    public void set_patBy_Depts() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT dept from beds;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_pat_by_dept.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
    }

    public void set_Frame_to_Initial(boolean bool) {

        Component[] com = jPanel3.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        com = jPanel1.getComponents();

        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        if (bool == false) {
            txt_conf_pass.setVisible(bool);
            btn_update.setVisible(bool);

        }
        if (bool == true) {
            txt_email.setVisible(false);
            txt_pass.setVisible(false);
            btn_login_out.setText("Log Out");
            btn_update.setVisible(true);
        }
    }

    public void searcH() {

    }

    public void actionPerformed(ActionEvent ae) {
//        if (ae.getSource() == drug) {
//            new_Drug_Field();
//        }
//        if (ae.getSource() == test) {
//            new_Test_Field();
//        }

    }

    public void new_Test_Field() {

    }

    public void new_Drug_Field() {

    }

    public void set_Tools() {

    }

    public void acknowledgement_Or_Warning(String warning_Msg, int time) {
        //  jOptionPane = new JOptionPane(warning_Msg, JOptionPane.INFORMATION_MESSAGE);
        //  final JDialog dialog = jOptionPane.createDialog("pokath!");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_pat_name.setText("");
                if (time == 1505) {
                    txt_search_content.setBackground(new Color(0, 51, 51));

                }
                if (time == 1500) {
                    lbl_warning.setText("");
                }

            }
        }).start();
        if (time == 1505) {
            txt_search_content.setBackground(Color.RED);
        }
        if (time == 1500) {
            lbl_warning.setText("Miss Match !");
        }
        if (time == 2000) {
            lbl_pat_name.setText(warning_Msg);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btn_login_out = new javax.swing.JButton();
        txt_email = new javax.swing.JTextField();
        txt_pass = new javax.swing.JTextField();
        txt_conf_pass = new javax.swing.JTextField();
        lbl_msg = new javax.swing.JLabel();
        btn_update = new javax.swing.JButton();
        lbl_warning = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        btn_get_pat = new javax.swing.JButton();
        cmb_searchBy = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        txt_search_content = new javax.swing.JTextField();
        btn_prev_pres = new javax.swing.JButton();
        btn_app_tobe = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        lbl_tbl_title = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        btn_my_sch = new javax.swing.JButton();
        btn_search = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btn_Run_InPat = new javax.swing.JButton();
        btn_viewDrugs = new javax.swing.JButton();
        cmb_pat_by_dept = new javax.swing.JComboBox<>();
        cmb_drug_byGeneric = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        lbl_pat_name = new javax.swing.JLabel();
        lbl_age = new javax.swing.JLabel();
        lbl_gender = new javax.swing.JLabel();
        lbl_contact = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        chk_write_pres = new javax.swing.JCheckBox();
        btn_save_print = new javax.swing.JButton();
        btn_plus_med = new javax.swing.JButton();
        btn_plus_test = new javax.swing.JButton();
        btn_note = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jlist_suggestion = new javax.swing.JList<>();
        txt_name = new javax.swing.JTextField();
        txt_group = new javax.swing.JTextField();
        txt_rules = new javax.swing.JTextField();
        btn_go = new javax.swing.JButton();
        lbl_rules = new javax.swing.JLabel();
        lbl_name = new javax.swing.JLabel();
        lbl_group = new javax.swing.JLabel();
        btn_view_pres = new javax.swing.JButton();
        lbl_event_id = new javax.swing.JLabel();
        lbl_add = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btn_save_print1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_pres = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1358, 711));
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(10, 25, 18));
        jPanel2.setMaximumSize(new java.awt.Dimension(1365, 711));
        jPanel2.setMinimumSize(new java.awt.Dimension(1365, 711));
        jPanel2.setPreferredSize(new java.awt.Dimension(1365, 711));

        jPanel3.setBackground(new java.awt.Color(10, 25, 18));
        jPanel3.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 0, 0, new java.awt.Color(0, 102, 102)));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(10, 25, 18));

        btn_login_out.setBackground(new java.awt.Color(255, 255, 255));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_login_out.setText("In");
        btn_login_out.setActionCommand("Log  Out");
        btn_login_out.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        txt_email.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_email.setText("user name..");
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_emailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });

        txt_pass.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_pass.setText("pass..");
        txt_pass.setMaximumSize(new java.awt.Dimension(170, 19));
        txt_pass.setMinimumSize(new java.awt.Dimension(170, 19));
        txt_pass.setPreferredSize(new java.awt.Dimension(170, 19));
        txt_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passFocusLost(evt);
            }
        });

        txt_conf_pass.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_conf_pass.setText("confirm pass");
        txt_conf_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusLost(evt);
            }
        });

        lbl_msg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_msg.setForeground(new java.awt.Color(204, 204, 255));
        lbl_msg.setText("Date : 19.10.18");

        btn_update.setBackground(new java.awt.Color(255, 255, 255));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_update.setText("Edit");
        btn_update.setActionCommand("Log  Out");
        btn_update.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txt_email, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_login_out, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lbl_msg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(145, 145, 145)
                .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0))
        );

        jPanel5.setBackground(new java.awt.Color(10, 25, 18));

        btn_get_pat.setBackground(new java.awt.Color(0, 0, 0));
        btn_get_pat.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_get_pat.setForeground(new java.awt.Color(204, 204, 255));
        btn_get_pat.setText("Selected Patient ");
        btn_get_pat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_get_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_get_patActionPerformed(evt);
            }
        });

        cmb_searchBy.setBackground(new java.awt.Color(0, 0, 0));
        cmb_searchBy.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cmb_searchBy.setForeground(new java.awt.Color(255, 255, 255));
        cmb_searchBy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "patient contact" }));
        cmb_searchBy.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(204, 204, 255));
        jButton4.setText("Test & Info");
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        txt_search_content.setBackground(new java.awt.Color(0, 0, 0));
        txt_search_content.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_search_content.setForeground(new java.awt.Color(255, 255, 255));
        txt_search_content.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_search_content.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 2, new java.awt.Color(0, 102, 102)));
        txt_search_content.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_search_contentKeyTyped(evt);
            }
        });

        btn_prev_pres.setBackground(new java.awt.Color(0, 0, 0));
        btn_prev_pres.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btn_prev_pres.setForeground(new java.awt.Color(204, 204, 255));
        btn_prev_pres.setText("Patient History");
        btn_prev_pres.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_prev_pres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_prev_presActionPerformed(evt);
            }
        });

        btn_app_tobe.setBackground(new java.awt.Color(0, 0, 0));
        btn_app_tobe.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_app_tobe.setForeground(new java.awt.Color(204, 204, 255));
        btn_app_tobe.setText("App To Be");
        btn_app_tobe.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_app_tobe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_app_tobeActionPerformed(evt);
            }
        });

        tbl_Result_Exhibition.setAutoCreateRowSorter(true);
        tbl_Result_Exhibition.setBackground(new java.awt.Color(204, 255, 204));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setDoubleBuffered(true);
        tbl_Result_Exhibition.setFillsViewportHeight(true);
        tbl_Result_Exhibition.setFocusCycleRoot(true);
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(204, 102, 0));
        tbl_Result_Exhibition.setMaximumSize(new java.awt.Dimension(534, 187));
        tbl_Result_Exhibition.setMinimumSize(new java.awt.Dimension(534, 187));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setPreferredSize(new java.awt.Dimension(534, 187));
        tbl_Result_Exhibition.setRowHeight(25);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(255, 204, 102));
        jScrollPane2.setViewportView(tbl_Result_Exhibition);

        lbl_tbl_title.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_tbl_title.setForeground(new java.awt.Color(204, 204, 255));
        lbl_tbl_title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(204, 204, 255));
        jButton5.setText("Service& Info");
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        btn_my_sch.setBackground(new java.awt.Color(0, 0, 0));
        btn_my_sch.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_my_sch.setForeground(new java.awt.Color(204, 204, 255));
        btn_my_sch.setText("My Patients");
        btn_my_sch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_my_sch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_my_schActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(0, 0, 0));
        btn_search.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_search.setForeground(new java.awt.Color(204, 204, 255));
        btn_search.setText("Search");
        btn_search.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        jButton1.setText("View");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(cmb_searchBy, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_app_tobe, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_prev_pres, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(btn_my_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btn_get_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btn_search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, 0)
                        .addComponent(jButton1)
                        .addGap(0, 0, 0))
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_searchBy, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_app_tobe, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_get_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_prev_pres, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_my_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE))
        );

        btn_Run_InPat.setBackground(new java.awt.Color(0, 0, 0));
        btn_Run_InPat.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_Run_InPat.setForeground(new java.awt.Color(204, 204, 255));
        btn_Run_InPat.setText("In. Patients");
        btn_Run_InPat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_Run_InPat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Run_InPatActionPerformed(evt);
            }
        });

        btn_viewDrugs.setBackground(new java.awt.Color(0, 0, 0));
        btn_viewDrugs.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btn_viewDrugs.setForeground(new java.awt.Color(204, 204, 255));
        btn_viewDrugs.setText("Drugs & Info");
        btn_viewDrugs.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_viewDrugs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewDrugsActionPerformed(evt);
            }
        });

        cmb_pat_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_pat_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_pat_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_pat_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept.", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_pat_by_dept.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_pat_by_deptActionPerformed(evt);
            }
        });

        cmb_drug_byGeneric.setBackground(new java.awt.Color(2, 25, 25));
        cmb_drug_byGeneric.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_drug_byGeneric.setForeground(new java.awt.Color(204, 255, 204));
        cmb_drug_byGeneric.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "generics:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_drug_byGeneric.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_drug_byGeneric.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_drug_byGeneric.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_drug_byGeneric.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_byGenericActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btn_viewDrugs, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(cmb_drug_byGeneric, 0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btn_Run_InPat, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(cmb_pat_by_dept, 0, 0, Short.MAX_VALUE))))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_Run_InPat, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_pat_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_viewDrugs, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_drug_byGeneric, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(10, 25, 18));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, new java.awt.Color(0, 102, 102)));
        jPanel1.setMaximumSize(new java.awt.Dimension(778, 260));
        jPanel1.setMinimumSize(new java.awt.Dimension(778, 260));

        lbl_pat_name.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_pat_name.setForeground(new java.awt.Color(255, 255, 255));
        lbl_pat_name.setText("name: Mr . andrew j koplan ");
        lbl_pat_name.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_pat_name.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_pat_name.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_age.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_age.setForeground(new java.awt.Color(255, 255, 255));
        lbl_age.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_age.setText("age: 35/36 years");
        lbl_age.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_age.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_age.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_gender.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_gender.setForeground(new java.awt.Color(255, 255, 255));
        lbl_gender.setText("Gender:  male");
        lbl_gender.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_gender.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_gender.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_contact.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_contact.setForeground(new java.awt.Color(255, 255, 255));
        lbl_contact.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_contact.setText("contact: 01833297233");
        lbl_contact.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_contact.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_contact.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_email.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_email.setForeground(new java.awt.Color(255, 255, 255));
        lbl_email.setText("Payment: clear");
        lbl_email.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_email.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_email.setPreferredSize(new java.awt.Dimension(220, 18));

        chk_write_pres.setBackground(new java.awt.Color(255, 255, 255));
        chk_write_pres.setFont(new java.awt.Font("Impact", 0, 13)); // NOI18N
        chk_write_pres.setText("Write Prescription");
        chk_write_pres.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 2, true));
        chk_write_pres.setBorderPainted(true);
        chk_write_pres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_write_presActionPerformed(evt);
            }
        });

        btn_save_print.setBackground(new java.awt.Color(3, 28, 28));
        btn_save_print.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_save_print.setForeground(new java.awt.Color(204, 255, 153));
        btn_save_print.setText(" Print");
        btn_save_print.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_save_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_save_printActionPerformed(evt);
            }
        });

        btn_plus_med.setBackground(new java.awt.Color(0, 0, 0));
        btn_plus_med.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_plus_med.setForeground(new java.awt.Color(255, 255, 255));
        btn_plus_med.setText("+Medicine");
        btn_plus_med.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_plus_med.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_plus_medActionPerformed(evt);
            }
        });

        btn_plus_test.setBackground(new java.awt.Color(0, 0, 0));
        btn_plus_test.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_plus_test.setForeground(new java.awt.Color(255, 255, 255));
        btn_plus_test.setText("+Test");
        btn_plus_test.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_plus_test.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_plus_testActionPerformed(evt);
            }
        });

        btn_note.setBackground(new java.awt.Color(0, 0, 0));
        btn_note.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_note.setForeground(new java.awt.Color(255, 255, 255));
        btn_note.setText("+Note");
        btn_note.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_note.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_noteActionPerformed(evt);
            }
        });

        jlist_suggestion.setBackground(new java.awt.Color(1, 27, 27));
        jlist_suggestion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlist_suggestion.setForeground(new java.awt.Color(204, 255, 204));
        jlist_suggestion.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jlist_suggestion);

        txt_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nameActionPerformed(evt);
            }
        });

        btn_go.setBackground(new java.awt.Color(0, 0, 0));
        btn_go.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        btn_go.setForeground(new java.awt.Color(204, 204, 204));
        btn_go.setText("Done");
        btn_go.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_go.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_goActionPerformed(evt);
            }
        });

        lbl_rules.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_rules.setForeground(new java.awt.Color(255, 255, 255));
        lbl_rules.setText("Rules:");

        lbl_name.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_name.setForeground(new java.awt.Color(255, 255, 255));
        lbl_name.setText("Medicine Name:");

        lbl_group.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_group.setForeground(new java.awt.Color(255, 255, 255));
        lbl_group.setText("Group:");

        btn_view_pres.setBackground(new java.awt.Color(0, 0, 0));
        btn_view_pres.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_view_pres.setForeground(new java.awt.Color(255, 204, 153));
        btn_view_pres.setText("View");
        btn_view_pres.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lbl_add.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_add.setForeground(new java.awt.Color(255, 255, 255));
        lbl_add.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_add.setText("Khadimpara , sylhet .");
        lbl_add.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_add.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_add.setPreferredSize(new java.awt.Dimension(220, 18));

        jSeparator1.setBackground(new java.awt.Color(0, 51, 51));
        jSeparator1.setForeground(new java.awt.Color(0, 51, 51));
        jSeparator1.setMaximumSize(new java.awt.Dimension(560, 2));
        jSeparator1.setMinimumSize(new java.awt.Dimension(560, 2));

        btn_save_print1.setBackground(new java.awt.Color(3, 28, 28));
        btn_save_print1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_save_print1.setForeground(new java.awt.Color(204, 255, 153));
        btn_save_print1.setText("Save Prescription ");
        btn_save_print1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_save_print1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_save_print1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(lbl_email, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(lbl_add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(lbl_gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(lbl_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(lbl_age, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lbl_rules, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_rules, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btn_go, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(txt_name)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(lbl_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGap(188, 188, 188)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lbl_group, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_group, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(chk_write_pres, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(26, 26, 26)
                            .addComponent(btn_plus_med)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btn_plus_test)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lbl_event_id, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(btn_note)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btn_view_pres)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_save_print1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_save_print, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_age, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(lbl_event_id)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_gender, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_email, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_add, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_plus_med)
                            .addComponent(btn_plus_test)
                            .addComponent(btn_note)
                            .addComponent(btn_view_pres)
                            .addComponent(chk_write_pres))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_name, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_group, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_group, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addComponent(lbl_rules, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_rules, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_go, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_save_print, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_save_print1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0))
        );

        txt_pres.setColumns(20);
        txt_pres.setRows(5);
        jScrollPane3.setViewportView(txt_pres);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addGap(0, 0, 0))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_get_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_get_patActionPerformed
        // TODO add your handling code here:
        sign = false;
        int ind = tbl_Result_Exhibition.getSelectedRow();
        if (ind >= 0 && lbl_tbl_title.getText().startsWith("Appointments")) {
            app_id = ids.get(ind * 2);
            pat_id = ids.get(ind * 2 + 1);

            try {
                query = "SELECT * FROM patients WHERE pat_id = " + pat_id;
                rs = st.executeQuery(query);
                while (rs.next()) {
                    lbl_pat_name.setText("Name: " + rs.getString("name"));
                    lbl_contact.setText("Contact: " + rs.getString("contact"));
                    lbl_gender.setText("Gender: " + rs.getString("gender"));
                    lbl_add.setText(rs.getString("address"));
                    lbl_email.setText("Email: " + rs.getString("email"));
                    //  lbl_age.setText("DOB: "+rs.getString("dob"));
                    tbl_Result_Exhibition.clearSelection();
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
        }
    }//GEN-LAST:event_btn_get_patActionPerformed

    private void chk_write_presActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_write_presActionPerformed
        // TODO add your handling code here:
        if (chk_write_pres.isSelected()) {
            btn_go.setEnabled(true);
            btn_note.setEnabled(true);
            btn_plus_med.setEnabled(true);
            btn_plus_test.setEnabled(true);
            btn_view_pres.setEnabled(true);
            txt_pres.setEnabled(true);
        } else {
            btn_view_pres.setEnabled(false);
            btn_go.setEnabled(false);
            btn_note.setEnabled(false);
            btn_plus_med.setEnabled(false);
            btn_plus_test.setEnabled(false);
            txt_pres.setEnabled(false);
        }
    }//GEN-LAST:event_chk_write_presActionPerformed

    private void btn_plus_medActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_plus_medActionPerformed
        // TODO add your handling code here:

        lbl_name.setText("Medicine Name:");
        lbl_rules.setText("Rules:");
        txt_name.setVisible(true);
        txt_group.setVisible(true);
        txt_rules.setVisible(true);
        lbl_group.setVisible(true);
        lbl_name.setVisible(true);
        lbl_rules.setVisible(true);
    }//GEN-LAST:event_btn_plus_medActionPerformed

    private void btn_plus_testActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_plus_testActionPerformed
        // TODO add your handling code here:
        txt_name.setVisible(false);
        txt_group.setVisible(false);
        lbl_rules.setVisible(false);
        lbl_group.setVisible(false);
        lbl_name.setText("Test Name:");
        txt_rules.setVisible(true);
        lbl_name.setVisible(true);
    }//GEN-LAST:event_btn_plus_testActionPerformed

    private void txt_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nameActionPerformed

    private void btn_goActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_goActionPerformed
        // TODO add your handling code here:
        String name, rules, note, group;
        String all[];
        sign = false;
        if (lbl_name.getText().equals("Test Name:")) {
            name = txt_rules.getText();
            txt_pres.setText(txt_pres.getText() + "\n Test #  " + name + ".\n");
        }
        if (lbl_name.getText().equals("Note:")) {
            note = txt_rules.getText();
            txt_pres.setText(txt_pres.getText() + "\n Note #  " + note + ".\n");
        }
        if (lbl_name.getText().equals("Medicine Name:")) {
            name = txt_name.getText();
            group = txt_group.getText();
            rules = txt_rules.getText();
            txt_pres.setText(txt_pres.getText() + "\n Medicine #  " + name + "\n " + group + ".\n " + rules + ".\n");
        }
    }//GEN-LAST:event_btn_goActionPerformed

    private void btn_noteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_noteActionPerformed
        // TODO add your handling code here:
        txt_name.setVisible(false);
        txt_group.setVisible(false);
        lbl_rules.setVisible(false);
        lbl_group.setVisible(false);
        lbl_name.setText("Note:");
        lbl_name.setVisible(true);
        txt_rules.setVisible(true);
    }//GEN-LAST:event_btn_noteActionPerformed

    private void btn_save_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_save_printActionPerformed
        // TODO add your handling code here:

//        pres = txt_pres.getText();
//        System.out.println(lbl_event_id.getText());
//        //  evt_ID = Integer.parseInt(lbl_event_id.getText());
//
//        System.out.println("got changes " + evt_ID);
//        try {
//            st = con.createStatement();
//            query = "UPDATE appointments SET "
//                    + " prescription = ? "
//                    + " WHERE pat_id = " + id + " ";
//            pst = con.prepareStatement(query);
//            pst.setString(3, pres);
//
//            pst.executeUpdate();
//        } catch (Exception exp) {
//            System.out.println(exp);
//        }

    }//GEN-LAST:event_btn_save_printActionPerformed

    private void btn_app_tobeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_app_tobeActionPerformed
        // TODO add your handling code here:

        ids = new ArrayList();
        ResultSet temp_rs;
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "App Date";
        coloumn[1] = "Pat Name";
        coloumn[2] = "Contact";
        coloumn[3] = "Payment";
        coloumn[4] = "Serial";
        sign = false;
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM appointments WHERE doc_id = " + module_User_ID + " AND status = '" + "Not Done" + "' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                app_id = Integer.parseInt(rs.getString("app_id"));
                pat_id = rs.getInt("pat_id");
                ids.add(app_id);
                ids.add(pat_id);
                data[0] = rs.getString("date");
                data[3] = rs.getString("bill");
                query = "SELECT * FROM patients WHERE pat_id = " + pat_id;
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    data[1] = temp_rs.getString("name");
                    data[2] = temp_rs.getString("contact");
                }
//                query = "SELECT * FROM serial WHERE app_id = " + app_id + " ";
//                st = con.createStatement();
//                temp_rs = st.executeQuery(query);
//                while (temp_rs.next()) {
//                data[4] = "15"; //temp_rs.getString("serial_no");
//                //     }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("oh ! dump ass " + ex);
        }
        lbl_tbl_title.setText("Appointments (To Be)");
    }//GEN-LAST:event_btn_app_tobeActionPerformed

    private void btn_my_schActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_my_schActionPerformed
        // TODO add your handling code here:
//        module_User_ID = 2;
//        try {
//            if (my_schedule == null) {
//                System.out.println("got null");
//                my_schedule = new View_Self_Schedule(module_User_ID);
//            }
//            if (my_schedule.isVisible()) {
//                my_schedule.setVisible(true);
//                my_schedule.setAlwaysOnTop(true);
//            }
//        } catch (NullPointerException npe) {
//            System.out.println(npe);
//            my_schedule = new View_Self_Schedule(module_User_ID);
//        }
        ids = new ArrayList();
        ResultSet temp_rs;
        String[] coloumn = new String[4];
        String[] data;
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "App Date";
        coloumn[1] = "Pat Name";
        coloumn[2] = "Contact";
        coloumn[3] = "Address";

        sign = false;
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM appointments WHERE doc_id = " + module_User_ID;
            rs = st.executeQuery(query);
            data = new String[4];

            while (rs.next()) {

                app_id = rs.getInt("app_id");
                pat_id = rs.getInt("pat_id");
                System.out.println("pat id :" + pat_id);
                ids.add(app_id);
                ids.add(pat_id);
                data[0] = rs.getString("date");
                temp_query = "SELECT * FROM patients WHERE pat_id = " + pat_id;
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[1] = temp_rs.getString("name");
                    data[2] = temp_rs.getString("contact");
                    data[3] = temp_rs.getString("address");
                    arr.add(data);
                }
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("oh ! dump ass " + ex);
        }
        lbl_tbl_title.setText("Patients Appointed (Previously)");

    }//GEN-LAST:event_btn_my_schActionPerformed

    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:
        if (btn_login_out.getText().equals("In")) {
            module_User_Name = txt_email.getText();
            module_User_Pass = txt_pass.getText();
            System.out.println(module_User_Name + "   " + module_User_Pass);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "SELECT * FROM accounts";
                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (module_User_Name.equals(rs.getString("user_name")) && module_User_Pass.equals(rs.getString("pass")) && rs.getString("module").equals("Doctor")) {
                        module_User_ID = Integer.parseInt(rs.getString("user_id"));
                        System.out.println("mid " + module_User_ID);
                        query = "SELECT * FROM doctors where doc_id = " + module_User_ID;
                        rs = st.executeQuery(query);
                        while (rs.next()) {
                            lbl_msg.setText(lbl_msg.getText() + ", " + rs.getString("name") + ", " + rs.getString("dept"));
                            sign = true;
                        }
                        if (sign == true) {
                            set_Frame_to_Initial(true);
                            btn_login_out.setText("Out");
                        }
                    }
                }
                if (sign == false) {
                    acknowledgement_Or_Warning("Missmatch !", 1500);
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
        }

    }//GEN-LAST:event_btn_login_outActionPerformed

    private void txt_emailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusGained
        // TODO add your handling code here:
        if (txt_email.getText().equals("user name..")) {
            txt_email.setText("");
        }
    }//GEN-LAST:event_txt_emailFocusGained

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        // TODO add your handling code here:
        if (txt_email.getText().equals("")) {
            txt_email.setText("user name..");
        }
    }//GEN-LAST:event_txt_emailFocusLost

    private void txt_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusGained
        // TODO add your handling code here:
        if (txt_pass.getText().equals("pass..")) {
            txt_pass.setText("");
        }
    }//GEN-LAST:event_txt_passFocusGained

    private void txt_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusLost
        // TODO add your handling code here:
        if (txt_pass.getText().equals("")) {
            txt_pass.setText("pass..");
        }
    }//GEN-LAST:event_txt_passFocusLost

    private void txt_conf_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusGained
        // TODO add your handling code here:
        btn_update.setText("Update");

        if (txt_conf_pass.getText().equals("confirm pass")) {
            txt_conf_pass.setText("");
        }
    }//GEN-LAST:event_txt_conf_passFocusGained

    private void txt_conf_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusLost
        if (txt_conf_pass.getText().equals("")) {
            txt_conf_pass.setText("confirm pass");
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txt_conf_passFocusLost

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
        String pass2 = "";
        if (btn_update.getText().equals("Edit")) {
            txt_email.setVisible(true);
            txt_pass.setVisible(true);
            txt_conf_pass.setVisible(true);

        }
        if (btn_update.getText().equals("Update")) {

            if ((email = txt_email.getText()).isEmpty() || (db_password = txt_pass.getText()).isEmpty() || (pass2 = txt_conf_pass.getText()).isEmpty()) {
                acknowledgement_Or_Warning("you kidding !", 1500);
            }

        }

    }//GEN-LAST:event_btn_updateActionPerformed

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Type";
        coloumn[3] = "Charge";
        coloumn[3] = "Testing Method";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        ids = new ArrayList<>();

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT * FROM med_tests";

            rs = st.executeQuery(query);

            while (rs.next()) {
                ids.add(rs.getInt("test_id"));
                data[0] = rs.getString("test_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("charge");
                data[4] = rs.getString("testing_method");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Diagnostic Imaging Tests");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(70);

    }//GEN-LAST:event_jButton4ActionPerformed

    private void btn_prev_presActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_prev_presActionPerformed
        // TODO add your handling code here:
        int ind = tbl_Result_Exhibition.getSelectedRow();
        sign = false;
        if (ind >= 0 && lbl_tbl_title.getText().startsWith("Appointments")) {
            pat_id = ids.get(ind * 2 + 1);
            System.out.println("pat id app: " + pat_id);
            sign = true;
        }
        if (ind >= 0 && lbl_tbl_title.getText().startsWith("Patients")) {
            pat_id = ids.get(ind * 2 + 1);
            System.out.println("pat id pats : " + pat_id);
            sign = true;
        }
        if (sign == true) {
            String[] coloumn = new String[2];
            String[] data = new String[2];
            ArrayList<Object[]> arr = new ArrayList<Object[]>();
            coloumn[0] = "App.Date/Case";
            coloumn[1] = "Type";
            ids = new ArrayList();
            sign = false;
            DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dtm);
//            pat_id = 1;           ///  check later !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();

                query = "SELECT app_id , date , prescription FROM appointments WHERE pat_id = " + pat_id;
                rs = st.executeQuery(query);
                while (rs.next()) {
                    ids.add(rs.getInt("app_id"));
                    System.out.println("app_id:   ??  " + rs.getInt("app_id"));
                    data[0] = rs.getString("date");
                    data[1] = "Prescribed Via Appointment";

                    System.out.println(data[1]);
                    arr.add(data);
                    dtm.addRow(arr.get(0));
                }

                query = "SELECT case_id , case_title,dept FROM in_pat_cases WHERE pat_id = " + pat_id;
                rs = st.executeQuery(query);
                while (rs.next()) {
                    ids.add(rs.getInt("case_id"));
                    data[0] = rs.getString("case_title");
                    data[1] = "Admission: " + rs.getString("dept");
                    arr.add(data);
                    dtm.addRow(arr.get(0));
                }

                lbl_tbl_title.setText("History Of The Patient");
            } catch (Exception exp) {
                System.out.println(exp);
            }
        }
    }//GEN-LAST:event_btn_prev_presActionPerformed
    public void view() {

    }
    private void txt_search_contentKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_search_contentKeyTyped
        // TODO add your handling code here: 
    }//GEN-LAST:event_txt_search_contentKeyTyped

    private void btn_save_print1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_save_print1ActionPerformed
        // TODO add your handling code here:
        try {

            boolean successbool = (new File(folderPath)).mkdirs();
            prescription = new File(pathOfpresFile);
            prescription.createNewFile();
            System.out.println("000000000");

            scannerObjOfPres = new Scanner(prescription);
            file_Writer = new FileWriter(pathOfpresFile, true);
            buffer_Writer = new BufferedWriter(file_Writer);
            System.out.println("aaaaaaaaaaa");
            buffer_Writer.write(txt_pres.getText());
            buffer_Writer.newLine();
            buffer_Writer.close();
            System.out.println(txt_pres.getText());

            fin = new FileInputStream(prescription);
            System.out.println("bbbbbbbbbbbb");
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            System.out.println("xxxxxxxxxxxxx");
            query = "UPDATE appointments SET "
                    + " prescription = ?"
                    + " WHERE app_id = " + app_id + " ";
            pst = con.prepareStatement(query);
            pst.setBinaryStream(1, (InputStream) fin, (int) prescription.length());
            pst.executeUpdate();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        prescription.delete();
    }//GEN-LAST:event_btn_save_print1ActionPerformed

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        // TODO add your handling code here:
        contact = txt_search_content.getText();
        if (!contact.isEmpty()) {
            String[] coloumn = new String[3];
            String[] data = new String[3];
            ArrayList<Object[]> arr_show = new ArrayList<Object[]>();
            ids = new ArrayList<>();
            coloumn[0] = "Full Name";
            coloumn[1] = "Contact";
            coloumn[2] = "Address";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "SELECT * FROM patients WHERE contact = '" + contact + "'";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    data[0] = rs.getString("name");
                    data[1] = rs.getString("contact");
                    data[2] = rs.getString("address");
                    ids.add(rs.getInt("pat_id"));
                    arr_show.add(data);
                    dm.addRow(arr_show.get(0));
                }
                arr_show.clear();
                lbl_tbl_title.setText("Resulted Patients:");
            } catch (Exception ex) {
                System.out.println(" btn_searchActionPerformed :" + ex);
            }
        }

    }//GEN-LAST:event_btn_searchActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        String[] coloumn = new String[4];
        String[] data = new String[4];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();

        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Type";
        coloumn[3] = "Charge";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM services";
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("service_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("charge");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Services");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(70);

    }//GEN-LAST:event_jButton5ActionPerformed
    public void view_RunningPatients(String q) {
        query = q;
        ResultSet temp_rs;
        ids = new ArrayList();
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "Pat Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Adm. Date";
        coloumn[3] = "Room num";
        coloumn[4] = "Floor";
        coloumn[5] = "Type";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                case_id = rs.getInt("case_id");
                System.out.println("case id: " + case_id);
                pat_id = rs.getInt("pat_id");
                System.out.println("pat id: " + pat_id);
                ids.add(pat_id);
                temp_query = "SELECT * FROM patients WHERE pat_id = " + pat_id + " ";
                temp_st = con.createStatement();
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[0] = temp_rs.getString("name");
                    data[1] = temp_rs.getString("contact");
                    System.out.println(data[0] + " >< " + data[1]);
                }
                temp_query = "SELECT * FROM bed_booking WHERE case_id = " + case_id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    bed_id = temp_rs.getInt("bed_id");
                    data[2] = temp_rs.getString("booking_time");
                    System.out.println("");
                }
                temp_query = "SELECT * FROM beds WHERE bed_id = " + bed_id;

                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString("room_num");
                    data[4] = temp_rs.getString("floor");
                    data[5] = temp_rs.getString("type");
                    System.out.println(data[5]);
                    arr.add(data);
                    dtm.addRow(arr.get(0));
                }

            }
        } catch (Exception ex) {
            System.out.println("from running pat:   " + ex);
        }
        lbl_tbl_title.setText("Running Patients (Admitted)");

    }
    private void btn_Run_InPatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Run_InPatActionPerformed
        // TODO add your handling code here:
        view_RunningPatients("SELECT * FROM in_pat_cases WHERE status = '" + "running'");
    }//GEN-LAST:event_btn_Run_InPatActionPerformed

    private void cmb_drug_byGenericActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_byGenericActionPerformed
        // TODO add your handling code here:
        String drug_group;
        if (cmb_drug_byGeneric.getSelectedIndex() > -1) {

            drug_group = cmb_drug_byGeneric.getSelectedItem().toString();
            System.out.println(drug_group);
            view_Drugs("generic", drug_group);
        }
    }//GEN-LAST:event_cmb_drug_byGenericActionPerformed

    public void view_Drugs(String where, String str_sign) {

        if (str_sign == "all") {
            query = "SELECT * FROM drug_stock";
        } else {
            query = "SELECT * FROM drug_stock WHERE " + where + " = '" + str_sign + "'";
        }
        System.out.println("\n\n" + query);
        String[] coloumn = new String[7];
        String[] data = new String[7];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        ids = new ArrayList<>();
        coloumn[0] = "Drug Name";
        coloumn[1] = "Group name";
        coloumn[2] = "ComPany";
        coloumn[3] = "Type";
        coloumn[4] = "Available Pcs";
        coloumn[5] = "MRP";
        coloumn[6] = "exp date";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + "full_pms", db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();

            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("drug_name");
                data[1] = rs.getString("generic");
                data[2] = rs.getString("company");
                data[3] = rs.getString("type");
                data[5] = rs.getString("mrp");

                temp_id = rs.getInt("drug_id");

                temp_query = "SELECT exp_date  , left_amount  from stock_detail  where drug_id =" + temp_id;

                temp_rs = temp_st.executeQuery(temp_query);
                sign = false;
                data[6] = "";
                data[4] = "";
                while (temp_rs.next()) {
                    ids.add(temp_id);
                    data[6] = temp_rs.getString(1);
                    data[4] = temp_rs.getString(2);
                    sign = true;
                    arr.add(data);
                    dm.addRow(arr.get(0));
                }
                if (sign == false) {
                    ids.add(temp_id);
                    arr.add(data);
                    dm.addRow(arr.get(0));
                }
                temp_rs.close();
            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tbl_title.setText("Drugs From Stock");
        tbl_Result_Exhibition.getColumnModel().getColumn(6).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(6).setMinWidth(70);
    }

    private void btn_viewDrugsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewDrugsActionPerformed
        // TODO add your handling code here:
        view_Drugs("", "all");
    }//GEN-LAST:event_btn_viewDrugsActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int ind = tbl_Result_Exhibition.getSelectedRow();
        if (lbl_tbl_title.getText().startsWith("History") && ind >= 0) {
            if (tbl_Result_Exhibition.getValueAt(ind, 1).toString().startsWith("Prescribed")) {
                app_id = ids.get(ind);

                try {
                    query = "SELECT prescription FROM appointments WHERE app_id =" + app_id;
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        Blob File;
                        File = (Blob) rs.getBlob("prescription");
                        is = File.getBinaryStream();
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                    String fullString = "\n\n";
                    while (reader.ready()) {
                        String line = reader.readLine();
                        fullString += "\t" + line + "\n";
                        System.out.println(line);
                    }
                    txt_pres.setText(fullString);
                    txt_pres.setEnabled(true);
                    System.out.println("still not null");
                    int b = 0;
                    FileOutputStream fos = new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\file.txt");
                    System.out.println(is.read());
                    while ((b = is.read()) != -1) {
                        fos.write(b);
                    }
                    fos.flush();
                } catch (Exception exp) {
                    System.out.println(exp);
                }

            }
            if (tbl_Result_Exhibition.getValueAt(ind, 1).toString().startsWith("Admission:")) {
                case_id = ids.get(ind);
                try {
                    query = "SELECT report FROM in_pat_cases WHERE case_id =" + case_id;
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        Blob File;
                        File = (Blob) rs.getBlob("report");
                        is = File.getBinaryStream();
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                    String fullString = "";
                    while (reader.ready()) {
                        String line = reader.readLine();
                        fullString += "\t" + line + "\n";
                        System.out.println(line);
                    }
                    txt_pres.setText(fullString);
                    txt_pres.setEnabled(true);
                    System.out.println("still not null");
                    int b = 0;
                    FileOutputStream fos = new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\file1.txt");
                    System.out.println(is.read());
                    while ((b = is.read()) != -1) {
                        fos.write(b);
                    }
                    fos.flush();
                } catch (Exception exp) {
                    System.out.println(exp);
                }
            }
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmb_pat_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_pat_by_deptActionPerformed
        // TODO add your handling code here:

        if (cmb_pat_by_dept.getSelectedIndex() > -1) {
            dept = cmb_pat_by_dept.getSelectedItem().toString();
            view_RunningPatients("SELECT * FROM in_pat_cases WHERE status = '" + "running" + "' AND dept = '" + dept + "'");
        }
    }//GEN-LAST:event_cmb_pat_by_deptActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doctor_Module.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doctor_Module.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doctor_Module.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doctor_Module.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        //   UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doctor_Module().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Run_InPat;
    private javax.swing.JButton btn_app_tobe;
    private javax.swing.JButton btn_get_pat;
    private javax.swing.JButton btn_go;
    private javax.swing.JButton btn_login_out;
    private javax.swing.JButton btn_my_sch;
    private javax.swing.JButton btn_note;
    private javax.swing.JButton btn_plus_med;
    private javax.swing.JButton btn_plus_test;
    private javax.swing.JButton btn_prev_pres;
    private javax.swing.JButton btn_save_print;
    private javax.swing.JButton btn_save_print1;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_update;
    private javax.swing.JButton btn_viewDrugs;
    private javax.swing.JButton btn_view_pres;
    private javax.swing.JCheckBox chk_write_pres;
    private javax.swing.JComboBox<String> cmb_drug_byGeneric;
    private javax.swing.JComboBox<String> cmb_pat_by_dept;
    private javax.swing.JComboBox<String> cmb_searchBy;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JList<String> jlist_suggestion;
    private javax.swing.JLabel lbl_add;
    private javax.swing.JLabel lbl_age;
    private javax.swing.JLabel lbl_contact;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_event_id;
    private javax.swing.JLabel lbl_gender;
    private javax.swing.JLabel lbl_group;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lbl_pat_name;
    private javax.swing.JLabel lbl_rules;
    private javax.swing.JLabel lbl_tbl_title;
    private javax.swing.JLabel lbl_warning;
    private javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_conf_pass;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_group;
    private javax.swing.JTextField txt_name;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextArea txt_pres;
    private javax.swing.JTextField txt_rules;
    private javax.swing.JTextField txt_search_content;
    // End of variables declaration//GEN-END:variables

}
//        DocumentListener documentListener = new DocumentListener() {
//            public void changedUpdate(DocumentEvent documentEvent) {
//            }
//            public void insertUpdate(DocumentEvent documentEvent) {
//    System.out.println(txt_group_name.getText());
//     System.out.println(txt_com_name.getText());
//
//            }
//            public void removeUpdate(DocumentEvent documentEvent) {
//            }
//        };
//        txt_com_name.getDocument().addDocumentListener(documentListener);
//        txt_group_name.getDocument().addDocumentListener(documentListener);
