/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IPCU;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DateEditor;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pddrgj3q
 */
public class In_Patient_Care_Unit extends javax.swing.JFrame {

    /**
     * Creates new form In_Patient_Care_Unit
     */
    static int app_id = 0, pat_id, doc_id, test_id, case_id, ser_id, bed_id, pX, pY, bed_vacancy;
    static String name, family, case_title, booking_time, nid, email, contact, dob, p_add, c_add, gender, age, dept_name, receipt_Code, pres, bed_type, pat_type, search_content, blood, tbl_Result_Type, dept;
    static ArrayList<Integer> tbl_Result_ids;
    static Suggestion_List suggestion;
    static Connection con = null;
    static Statement st = null;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "pokath";
    static String db_userName = "root";
    static String db_password = "";
    static ArrayList<String> sugg;
    static SimpleDateFormat simpleDateFormat;
    static DateFormat date_Format;
    public DefaultListModel jlist_model;
    static In_Patient_Care_Unit ipcu;
    static boolean changes, old_patient, sign, pat_selection, doc_selection, bed_selection;
    static Patient_Admission pat_adm;
    private int module_user_ID;
    static ArrayList<String> Listed_sugg;
    static DefaultListModel model;
    String module_use_pass, module_user_name;

    private int running_pat;
    static java.awt.event.ActionEvent evt;

    public In_Patient_Care_Unit() {
        initComponents();
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        jspn_date1.setValue(new Date(System.currentTimeMillis()));
        ((DateEditor) jspn_date1.getEditor()).getFormat().applyPattern("dd.MM.yy HH:mm:ss.SSS");
//        jlist_model = new DefaultListModel();
//        JList list = new JList(); 
//        list.setModel(jlist_model);
//        list.setSize(100, 200);
//        jpnl_grand.add(list);
//        list.setLocation(100, 350);
//        list.setVisible(true);
        //  set_Frame_to_Initial(false);
        setSize(1350, 760);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
        tbl_Result_Type = "";
    }

    public void close_InPatient() {
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }

    public void set_Frame_to_Initial(boolean bool) {

        Component[] com = jpnl_functions.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        com = jpnl_with_tbl.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        if (bool == false) {
            txt_conf_pass.setVisible(bool);
            btn_update.setVisible(bool);
        }
        if (bool == true) {
            txt_u_name.setVisible(false);
            txt_pass.setVisible(false);
            btn_login_out.setText("Out");
            btn_update.setVisible(true);
        }
    }

    public void clear_jpnl_grand() {
        jpnl_grand.removeAll();
    }

    public void set_Warning(String warning_Msg, int time) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (time == 1650) {
                    lbl_missmtch.setText("");
                }
            }
        }).start();
        if (time == 1650) {
            lbl_missmtch.setText("Missmatch !");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jpnl_with_tbl = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        lbl_tbl_title = new javax.swing.JLabel();
        jpnl_functions = new javax.swing.JPanel();
        jpnl_login = new javax.swing.JPanel();
        txt_u_name = new javax.swing.JTextField();
        txt_pass = new javax.swing.JTextField();
        btn_login_out = new javax.swing.JButton();
        txt_conf_pass = new javax.swing.JTextField();
        btn_update = new javax.swing.JButton();
        lbl_missmtch = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        btn_emptyBeds1 = new javax.swing.JButton();
        btn_emptyBeds2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btn_run_in_pat = new javax.swing.JButton();
        cmb_bed_by_dept = new javax.swing.JComboBox<>();
        btn_bedsAll = new javax.swing.JButton();
        btn_bedsEmpties = new javax.swing.JButton();
        btn_bedsOccup = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jspn_s_t = new com.toedter.calendar.JSpinnerDateEditor();
        lbl_s_t = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        btn_run_in_pat1 = new javax.swing.JButton();
        cmb_search_By = new javax.swing.JComboBox<>();
        txt_search_content2 = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jpnl_grand = new javax.swing.JPanel();
        jpnl_pat_personal = new javax.swing.JPanel();
        lbl_pat_name = new javax.swing.JLabel();
        lbl_age = new javax.swing.JLabel();
        lbl_pat_contact = new javax.swing.JLabel();
        lbl_add = new javax.swing.JLabel();
        lbl_care_of = new javax.swing.JLabel();
        lbl_fam_contact = new javax.swing.JLabel();
        lbl_id_bed = new javax.swing.JLabel();
        jpnl_bill_title = new javax.swing.JLabel();
        jpnl_bed_history = new javax.swing.JPanel();
        lbl_counter = new javax.swing.JLabel();
        jpnl_next_back_done = new javax.swing.JPanel();
        btn_next = new javax.swing.JButton();
        btn_back = new javax.swing.JButton();
        btn_done = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lbl_disc = new javax.swing.JLabel();
        rbtn_perc = new javax.swing.JRadioButton();
        rbtn_cash = new javax.swing.JRadioButton();
        jspnr_disc = new javax.swing.JSpinner();
        lbl_date4 = new javax.swing.JLabel();
        jspn_date1 = new com.toedter.calendar.JSpinnerDateEditor();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel6.setBackground(new java.awt.Color(218, 218, 255));
        jPanel6.setMaximumSize(new java.awt.Dimension(1360, 830));
        jPanel6.setMinimumSize(new java.awt.Dimension(1360, 830));
        jPanel6.setPreferredSize(new java.awt.Dimension(1360, 830));

        jpnl_with_tbl.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_with_tbl.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 0, 1, new java.awt.Color(0, 102, 102)));
        jpnl_with_tbl.setMaximumSize(new java.awt.Dimension(790, 973));
        jpnl_with_tbl.setMinimumSize(new java.awt.Dimension(790, 973));
        jpnl_with_tbl.setPreferredSize(new java.awt.Dimension(790, 973));

        tbl_Result_Exhibition.setBackground(new java.awt.Color(27, 37, 37));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(204, 204, 255));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setDoubleBuffered(true);
        tbl_Result_Exhibition.setFocusable(false);
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 204, 204));
        tbl_Result_Exhibition.setMaximumSize(new java.awt.Dimension(310, 600));
        tbl_Result_Exhibition.setMinimumSize(new java.awt.Dimension(310, 600));
        tbl_Result_Exhibition.setPreferredSize(new java.awt.Dimension(310, 600));
        tbl_Result_Exhibition.setRowHeight(24);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(19, 36, 36));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(255, 204, 204));
        jScrollPane2.setViewportView(tbl_Result_Exhibition);

        lbl_tbl_title.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jpnl_functions.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_functions.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 102, 102)));
        jpnl_functions.setMaximumSize(new java.awt.Dimension(786, 235));
        jpnl_functions.setMinimumSize(new java.awt.Dimension(786, 235));
        jpnl_functions.setPreferredSize(new java.awt.Dimension(786, 235));

        jpnl_login.setBackground(new java.awt.Color(204, 255, 204));

        txt_u_name.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });
        txt_u_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_u_nameActionPerformed(evt);
            }
        });

        txt_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_pass.setText("pass..");
        txt_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passFocusLost(evt);
            }
        });

        btn_login_out.setBackground(new java.awt.Color(204, 255, 204));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_login_out.setText("In");
        btn_login_out.setActionCommand("Log  Out");
        btn_login_out.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        txt_conf_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_conf_pass.setText("confirm pass");
        txt_conf_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_conf_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusLost(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(204, 255, 204));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_update.setText("Edit");
        btn_update.setActionCommand("Log  Out");
        btn_update.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        lbl_missmtch.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_missmtch.setForeground(new java.awt.Color(255, 255, 153));
        lbl_missmtch.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jpnl_loginLayout = new javax.swing.GroupLayout(jpnl_login);
        jpnl_login.setLayout(jpnl_loginLayout);
        jpnl_loginLayout.setHorizontalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_loginLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_missmtch, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnl_loginLayout.createSequentialGroup()
                        .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_u_name, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnl_loginLayout.createSequentialGroup()
                                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                                    .addComponent(txt_pass))
                                .addGap(0, 0, 0)
                                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(6, 6, 6))))
        );
        jpnl_loginLayout.setVerticalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_loginLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lbl_missmtch, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2))
        );

        jButton6.setBackground(new java.awt.Color(193, 193, 248));
        jButton6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton6.setText("Bill Details");
        jButton6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jButton6.setContentAreaFilled(false);

        btn_emptyBeds1.setBackground(new java.awt.Color(193, 193, 248));
        btn_emptyBeds1.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        btn_emptyBeds1.setText("Add Consultation Visit");
        btn_emptyBeds1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_emptyBeds1.setContentAreaFilled(false);
        btn_emptyBeds1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_emptyBeds1ActionPerformed(evt);
            }
        });

        btn_emptyBeds2.setBackground(new java.awt.Color(193, 193, 248));
        btn_emptyBeds2.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        btn_emptyBeds2.setText("Add Drug And Accesories");
        btn_emptyBeds2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_emptyBeds2.setContentAreaFilled(false);
        btn_emptyBeds2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_emptyBeds2ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setMaximumSize(new java.awt.Dimension(784, 170));
        jPanel2.setMinimumSize(new java.awt.Dimension(784, 170));

        jLabel2.setText("Beds:");

        btn_run_in_pat.setBackground(new java.awt.Color(204, 255, 204));
        btn_run_in_pat.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_run_in_pat.setForeground(new java.awt.Color(0, 0, 0));
        btn_run_in_pat.setText("Running In Patients");
        btn_run_in_pat.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        btn_run_in_pat.setContentAreaFilled(false);
        btn_run_in_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_run_in_patActionPerformed(evt);
            }
        });

        cmb_bed_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_bed_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_bed_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_bed_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by type:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(255, 204, 102))); // NOI18N
        cmb_bed_by_dept.setMaximumSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_dept.setMinimumSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_dept.setPreferredSize(new java.awt.Dimension(150, 24));
        cmb_bed_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_bed_by_deptActionPerformed(evt);
            }
        });

        btn_bedsAll.setBackground(new java.awt.Color(0, 51, 51));
        btn_bedsAll.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_bedsAll.setForeground(new java.awt.Color(204, 255, 204));
        btn_bedsAll.setText("All");
        btn_bedsAll.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_bedsAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bedsAllActionPerformed(evt);
            }
        });

        btn_bedsEmpties.setBackground(new java.awt.Color(0, 51, 51));
        btn_bedsEmpties.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_bedsEmpties.setForeground(new java.awt.Color(204, 255, 204));
        btn_bedsEmpties.setText("Empty");
        btn_bedsEmpties.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_bedsEmpties.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bedsEmptiesActionPerformed(evt);
            }
        });

        btn_bedsOccup.setBackground(new java.awt.Color(0, 51, 51));
        btn_bedsOccup.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_bedsOccup.setForeground(new java.awt.Color(204, 255, 204));
        btn_bedsOccup.setText("Occupied");
        btn_bedsOccup.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_bedsOccup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bedsOccupActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(193, 193, 248));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("services and charge");
        jButton1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(btn_bedsAll, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(3, 3, 3)))
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmb_bed_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(btn_bedsEmpties, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_bedsOccup, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(btn_run_in_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_bed_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_bedsAll, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_bedsEmpties, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_bedsOccup, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_run_in_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jButton7.setBackground(new java.awt.Color(193, 193, 248));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 0, 0));
        jButton7.setText("Patient Admission");
        jButton7.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jButton7.setContentAreaFilled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(193, 193, 248));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton4.setText("Take To Billing -->>");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jspn_s_t.setBackground(new java.awt.Color(0, 51, 51));
        jspn_s_t.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_s_t.setForeground(new java.awt.Color(204, 255, 153));
        jspn_s_t.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N

        lbl_s_t.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        lbl_s_t.setText("Start Time");

        jButton5.setBackground(new java.awt.Color(193, 193, 248));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setText("Bills On Given Time ");
        jButton5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        btn_run_in_pat1.setBackground(new java.awt.Color(204, 255, 204));
        btn_run_in_pat1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_run_in_pat1.setForeground(new java.awt.Color(0, 0, 0));
        btn_run_in_pat1.setText("Consultants");
        btn_run_in_pat1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        btn_run_in_pat1.setContentAreaFilled(false);
        btn_run_in_pat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_run_in_pat1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lbl_s_t)
                            .addComponent(jspn_s_t, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(116, 116, 116)
                        .addComponent(jButton5)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                        .addComponent(btn_run_in_pat1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(174, 174, 174)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lbl_s_t))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_run_in_pat1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_s_t, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4)
                        .addGap(22, 22, 22))))
        );

        cmb_search_By.setBackground(new java.awt.Color(212, 226, 228));
        cmb_search_By.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        cmb_search_By.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pat_ID", "Service_Name", "Adm. Date", "bed No" }));
        cmb_search_By.setOpaque(false);

        txt_search_content2.setBackground(new java.awt.Color(212, 226, 228));
        txt_search_content2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        txt_search_content2.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 102, 102)));
        txt_search_content2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_content2ActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(193, 193, 248));
        btn_search.setText("Search");
        btn_search.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        btn_search.setContentAreaFilled(false);

        javax.swing.GroupLayout jpnl_functionsLayout = new javax.swing.GroupLayout(jpnl_functions);
        jpnl_functions.setLayout(jpnl_functionsLayout);
        jpnl_functionsLayout.setHorizontalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_functionsLayout.createSequentialGroup()
                        .addComponent(jpnl_login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                                .addComponent(btn_emptyBeds2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                                .addComponent(btn_emptyBeds1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(txt_search_content2, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(2, Short.MAX_VALUE))
        );
        jpnl_functionsLayout.setVerticalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_functionsLayout.createSequentialGroup()
                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_functionsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_emptyBeds2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_emptyBeds1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_search_content2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jpnl_login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jpnl_with_tblLayout = new javax.swing.GroupLayout(jpnl_with_tbl);
        jpnl_with_tbl.setLayout(jpnl_with_tblLayout);
        jpnl_with_tblLayout.setHorizontalGroup(
            jpnl_with_tblLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_with_tblLayout.createSequentialGroup()
                .addGroup(jpnl_with_tblLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_with_tblLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 774, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jpnl_functions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jpnl_with_tblLayout.setVerticalGroup(
            jpnl_with_tblLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_with_tblLayout.createSequentialGroup()
                .addComponent(jpnl_functions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jpnl_with_tblLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 494, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(1, 24, 24));
        jPanel3.setForeground(new java.awt.Color(153, 204, 255));

        jButton3.setText("Min");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setText("Exit");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 102));
        jLabel1.setText("In Patient Care Unit");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jpnl_grand.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_grand.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 0, 0, new java.awt.Color(102, 51, 0)));
        jpnl_grand.setMaximumSize(new java.awt.Dimension(575, 730));
        jpnl_grand.setMinimumSize(new java.awt.Dimension(575, 730));
        jpnl_grand.setPreferredSize(new java.awt.Dimension(575, 730));

        jpnl_pat_personal.setBackground(new java.awt.Color(1, 27, 27));
        jpnl_pat_personal.setForeground(new java.awt.Color(255, 255, 255));

        lbl_pat_name.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_pat_name.setForeground(new java.awt.Color(204, 255, 204));
        lbl_pat_name.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_pat_name.setText("name: Mr . andrew j koplan ");
        lbl_pat_name.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_pat_name.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_pat_name.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_age.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_age.setForeground(new java.awt.Color(204, 255, 204));
        lbl_age.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_age.setText("age: 35/36 years");
        lbl_age.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_age.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_age.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_pat_contact.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_pat_contact.setForeground(new java.awt.Color(204, 255, 204));
        lbl_pat_contact.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_pat_contact.setText("contact: 01833297233");
        lbl_pat_contact.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_pat_contact.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_pat_contact.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_add.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_add.setForeground(new java.awt.Color(204, 255, 204));
        lbl_add.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_add.setText("Khadimpara , sylhet .");
        lbl_add.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_add.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_add.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_care_of.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_care_of.setForeground(new java.awt.Color(204, 255, 204));
        lbl_care_of.setText("Care Of:");
        lbl_care_of.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_care_of.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_care_of.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_fam_contact.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_fam_contact.setForeground(new java.awt.Color(204, 255, 204));
        lbl_fam_contact.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_fam_contact.setText("Contact: 01750000309");
        lbl_fam_contact.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_fam_contact.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_fam_contact.setPreferredSize(new java.awt.Dimension(220, 18));

        lbl_id_bed.setFont(new java.awt.Font("Trajan Pro", 1, 12)); // NOI18N
        lbl_id_bed.setForeground(new java.awt.Color(204, 255, 204));
        lbl_id_bed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_id_bed.setText("ID: 134 ,  Current room: C-101AC");
        lbl_id_bed.setMaximumSize(new java.awt.Dimension(220, 18));
        lbl_id_bed.setMinimumSize(new java.awt.Dimension(220, 18));
        lbl_id_bed.setPreferredSize(new java.awt.Dimension(220, 18));

        javax.swing.GroupLayout jpnl_pat_personalLayout = new javax.swing.GroupLayout(jpnl_pat_personal);
        jpnl_pat_personal.setLayout(jpnl_pat_personalLayout);
        jpnl_pat_personalLayout.setHorizontalGroup(
            jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_pat_personalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_pat_personalLayout.createSequentialGroup()
                        .addComponent(lbl_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_age, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_pat_personalLayout.createSequentialGroup()
                        .addComponent(lbl_pat_contact, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_add, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnl_pat_personalLayout.createSequentialGroup()
                        .addComponent(lbl_care_of, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_fam_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addComponent(lbl_id_bed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jpnl_pat_personalLayout.setVerticalGroup(
            jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_pat_personalLayout.createSequentialGroup()
                .addComponent(lbl_id_bed, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_age, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_pat_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_add, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_pat_personalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_care_of, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_fam_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jpnl_bill_title.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jpnl_bill_title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jpnl_bill_title.setText("ABC Hospital Bill");
        jpnl_bill_title.setMaximumSize(new java.awt.Dimension(548, 18));
        jpnl_bill_title.setMinimumSize(new java.awt.Dimension(548, 18));

        jpnl_bed_history.setBackground(new java.awt.Color(204, 255, 204));

        lbl_counter.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbl_counter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_counter.setMaximumSize(new java.awt.Dimension(80, 19));
        lbl_counter.setMinimumSize(new java.awt.Dimension(80, 19));
        lbl_counter.setPreferredSize(new java.awt.Dimension(80, 19));

        jpnl_next_back_done.setBackground(new java.awt.Color(0, 51, 51));
        jpnl_next_back_done.setMaximumSize(new java.awt.Dimension(405, 26));
        jpnl_next_back_done.setMinimumSize(new java.awt.Dimension(405, 24));
        jpnl_next_back_done.setPreferredSize(new java.awt.Dimension(543, 22));

        btn_next.setBackground(new java.awt.Color(0, 0, 0));
        btn_next.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_next.setForeground(new java.awt.Color(204, 255, 153));
        btn_next.setText("Next");
        btn_next.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_next.setContentAreaFilled(false);
        btn_next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nextActionPerformed(evt);
            }
        });

        btn_back.setBackground(new java.awt.Color(0, 0, 0));
        btn_back.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_back.setForeground(new java.awt.Color(204, 255, 153));
        btn_back.setText("Back");
        btn_back.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_back.setContentAreaFilled(false);
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });

        btn_done.setBackground(new java.awt.Color(0, 0, 0));
        btn_done.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_done.setForeground(new java.awt.Color(204, 255, 153));
        btn_done.setText("Done");
        btn_done.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_done.setContentAreaFilled(false);
        btn_done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_doneActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Taken Charge:");

        javax.swing.GroupLayout jpnl_next_back_doneLayout = new javax.swing.GroupLayout(jpnl_next_back_done);
        jpnl_next_back_done.setLayout(jpnl_next_back_doneLayout);
        jpnl_next_back_doneLayout.setHorizontalGroup(
            jpnl_next_back_doneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_next_back_doneLayout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_back, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(btn_next, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );
        jpnl_next_back_doneLayout.setVerticalGroup(
            jpnl_next_back_doneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_next_back_doneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btn_back, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_next, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        lbl_disc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_disc.setText("Discount:");

        rbtn_perc.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_perc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        rbtn_perc.setText("%");

        rbtn_cash.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_cash.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        rbtn_cash.setText("/=");

        jspnr_disc.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 19)); // NOI18N
        jspnr_disc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspnr_disc.setMaximumSize(new java.awt.Dimension(78, 24));
        jspnr_disc.setMinimumSize(new java.awt.Dimension(78, 24));
        jspnr_disc.setPreferredSize(new java.awt.Dimension(78, 24));

        lbl_date4.setBackground(new java.awt.Color(204, 204, 255));
        lbl_date4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_date4.setText("Release Time:");

        jspn_date1.setBackground(new java.awt.Color(15, 38, 38));
        jspn_date1.setBorder(null);
        jspn_date1.setForeground(new java.awt.Color(255, 204, 102));
        jspn_date1.setModel(new javax.swing.SpinnerDateModel());
        jspn_date1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        javax.swing.GroupLayout jpnl_bed_historyLayout = new javax.swing.GroupLayout(jpnl_bed_history);
        jpnl_bed_history.setLayout(jpnl_bed_historyLayout);
        jpnl_bed_historyLayout.setHorizontalGroup(
            jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnl_next_back_done, javax.swing.GroupLayout.DEFAULT_SIZE, 565, Short.MAX_VALUE)
            .addGroup(jpnl_bed_historyLayout.createSequentialGroup()
                .addComponent(lbl_date4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(103, 103, 103)
                .addComponent(lbl_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(rbtn_perc)
                .addGap(0, 0, 0)
                .addComponent(rbtn_cash)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_counter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jspnr_disc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5))
        );
        jpnl_bed_historyLayout.setVerticalGroup(
            jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_bed_historyLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(lbl_counter, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_bed_historyLayout.createSequentialGroup()
                        .addGroup(jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbl_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(rbtn_cash, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(rbtn_perc, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jspnr_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_bed_historyLayout.createSequentialGroup()
                        .addGroup(jpnl_bed_historyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_date4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addComponent(jpnl_next_back_done, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jpnl_grandLayout = new javax.swing.GroupLayout(jpnl_grand);
        jpnl_grand.setLayout(jpnl_grandLayout);
        jpnl_grandLayout.setHorizontalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnl_bill_title, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_grandLayout.createSequentialGroup()
                .addGroup(jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnl_pat_personal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnl_bed_history, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8))
        );
        jpnl_grandLayout.setVerticalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_grandLayout.createSequentialGroup()
                .addComponent(jpnl_bill_title, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnl_pat_personal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jpnl_bed_history, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jpnl_with_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jpnl_grand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jpnl_with_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_grand, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 1365, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 749, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_search_content2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_content2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_content2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[4];
        String[] data = new String[4];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Type";
        coloumn[3] = "Charge";

        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT * FROM services";
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("service_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("charge");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("services");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_bedsAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bedsAllActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "ID";
        coloumn[1] = "Status";
        coloumn[2] = "Type";
        coloumn[3] = "Floor";
        coloumn[4] = "Room Phy No";

        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT * FROM beds";

            rs = st.executeQuery(query);

            while (rs.next()) {
                data[0] = rs.getString("bed_id");
                data[1] = rs.getString("status");
                data[2] = rs.getString("type");
                data[3] = rs.getString("floor");
                data[4] = rs.getString("room_num");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
        tbl_Result_Type = "Beds And Status";
        lbl_tbl_title.setText(tbl_Result_Type);
    }//GEN-LAST:event_btn_bedsAllActionPerformed

    private void btn_run_in_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_run_in_patActionPerformed
        // TODO add your handling code here:
        ResultSet temp_rs;
        tbl_Result_ids = new ArrayList();
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();

        coloumn[0] = "Pat Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Adm. Date";
        coloumn[3] = "Room num";
        coloumn[4] = "Floor";
        coloumn[5] = "Type";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM in_pat_cases WHERE status = '" + "Running" + "' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                case_id = Integer.parseInt(rs.getString("case_id"));
                pat_id = rs.getInt("pat_id");
                tbl_Result_ids.add(pat_id);
                query = "SELECT * FROM patients WHERE pat_id = " + pat_id + " ";
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    data[0] = temp_rs.getString("name");
                    data[1] = temp_rs.getString("contact");
                }
                query = "SELECT * FROM bed_booking WHERE case_id = " + case_id;
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    bed_id = Integer.parseInt(temp_rs.getString("bed_id"));
                    data[2] = temp_rs.getString("booking_time");
                }
                query = "SELECT * FROM beds WHERE bed_id = " + bed_id;
                st = con.createStatement();
                temp_rs = st.executeQuery(query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString("room_num");
                    data[4] = temp_rs.getString("floor");
                    data[5] = temp_rs.getString("type");
                }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("from running pat:   " + ex);
        }
        tbl_Result_Type = "Running InPatients";
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(60);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(60);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(60);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(60);
    }//GEN-LAST:event_btn_run_in_patActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void txt_u_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_u_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_u_nameActionPerformed

    private void txt_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusGained
        // TODO add your handling code here:
        if (txt_pass.getText().equals("pass..")) {
            txt_pass.setText("");
        }
    }//GEN-LAST:event_txt_passFocusGained

    private void txt_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusLost
        // TODO add your handling code here:
        if (txt_pass.getText().equals("")) {
            txt_pass.setText("pass..");
        }
    }//GEN-LAST:event_txt_passFocusLost

    private void txt_conf_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusGained
        // TODO add your handling code here:
        btn_update.setText("Update");

        if (txt_conf_pass.getText().equals("confirm pass")) {
            txt_conf_pass.setText("");
        }
    }//GEN-LAST:event_txt_conf_passFocusGained

    private void txt_conf_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusLost
        if (txt_conf_pass.getText().equals("")) {
            txt_conf_pass.setText("confirm pass");
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txt_conf_passFocusLost

    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        if (btn_login_out.getText().equals("In")) {
            module_user_name = txt_u_name.getText();
            module_use_pass = txt_pass.getText();
            System.out.println(module_user_name + "  ?  " + module_use_pass);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "SELECT * FROM accounts WHERE user_name = '" + module_user_name + "' AND pass = '" + module_use_pass + "'";
                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (rs.getString("module").equals("IPCU")) {
                        sign = true;
                        module_user_ID = rs.getInt("user_id");
                        set_Frame_to_Initial(sign);
                    }
                }
                if (sign == false) {
                    set_Warning("Missmatch !", 1650);
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_login_outActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
//        String pass2 = "";
//        if (btn_update.getText().equals("Edit")) {
//            txt_login_email.setVisible(true);
//            txt_pass.setVisible(true);
//            txt_conf_pass.setVisible(true);
//            btn_cancel.setVisible(true);
//        }
//        if (btn_update.getText().equals("Update")) {
//
//            if ((email = txt_login_email.getText()).isEmpty() || (password = txt_pass.getText()).isEmpty() || (pass2 = txt_conf_pass.getText()).isEmpty()) {
//                acknowledgement_Or_Warning("you kidding !", 1500);
//            }
//
//        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nextActionPerformed
        // TODO add your handling code here:
//
//        if (metric == 1) {
//            if (count_running == count_done) {
//                count_running += 1;
//                lbl_counter.setText("new/" + count_done);
//                btn_clearActionPerformed(evt);
//            }
//            if (count_running < count_done) {
//                count_running += 1;
//                lbl_counter.setText(count_running + "/" + count_done);
//                txt_drug_name.setText(purchase_order.get(count_running - 1)[1]);
//                txt_group_name.setText(purchase_order.get(count_running - 1)[2]);
//                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[3]);
//                jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[4]));
//
//            }
//        }
//        if (metric == 0) {
//            if (count_running == count_done) {
//                count_running += 1;
//                lbl_counter.setText("new/" + count_done);
//                btn_clearActionPerformed(evt);
//            }
//            if (count_running < count_done) {
//                count_running += 1;
//                lbl_counter.setText(count_running + "/" + count_done);
//                txt_drug_name.setText(purchase_order.get(count_running - 1)[0]);
//                txt_group_name.setText(purchase_order.get(count_running - 1)[1]);
//                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[2]);
//                txt_com_name.setText(purchase_order.get(count_running - 1)[3]);
//            }
//        }
//        if (metric == 2) {
//            if (count_running == count_done) {
//                count_running += 1;
//                lbl_counter.setText("new/" + count_done);
//                btn_clearActionPerformed(evt);
//            }
//            if (count_running < count_done) {
//                count_running += 1;
//                lbl_counter.setText(count_running + "/" + count_done);
//                txt_drug_name.setText(purchase_order.get(count_running - 1)[4]);
//                txt_group_name.setText(purchase_order.get(count_running - 1)[5]);
//                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[6]);
//                txt_com_name.setText(purchase_order.get(count_running - 1)[7]);
//                jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[1]));
//                try {
//                    jspn_date1.setDate(date_Format.parse(purchase_order.get(count_running - 1)[3]));
//                } catch (Exception exp) {
//                    System.out.println(exp);
//                }
//                txt_bill.setText(purchase_order.get(count_running - 1)[2]);
//            }
//            System.out.println("next > done: " + count_done + "  run: " + count_running);
//        }
    }//GEN-LAST:event_btn_nextActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:

        System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(jspn_date1.getDate()));
        System.out.println(new SimpleDateFormat("HH:mm").format(jspn_date1.getDate()));

//        if (count_running > 1) {
//            count_running -= 1;
//            set_BY_count_running();
//            lbl_counter.setText(count_running + "/" + count_done);
//        }
    }//GEN-LAST:event_btn_backActionPerformed

    private void btn_doneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_doneActionPerformed
        // TODO add your handling code here:
//
//        sign = false;
//        drug_type = "";
//        if (cmb_type.getSelectedIndex() != -1) {
//            drug_type = cmb_type.getSelectedItem().toString();
//        }
//        quant = (int) jspnr_quant.getValue();
//        drug_group = txt_group_name.getText();
//        drug_name = txt_drug_name.getText();
//        com_name = txt_com_name.getText();
//        if (metric == 3) {
//            if (quant < 1) {
//                sign = true;
//                status_In_Time("quantity !", 2000);
//            }
//            if (quant > available) {
//                sign = true;
//                status_In_Time("Exceeds availabe !", 2000);
//            }
//            try {
//                pur_bill = Integer.parseInt(txt_bill.getText());
//            } catch (Exception exp) {
//                sign = true;
//                status_In_Time("Invalid Bill", 2000);
//            }
//            if (sign == false) {
//                grad_tot += pur_bill;
//                str = new String[5];
//                str[0] = String.valueOf(drug_id);
//                str[1] = String.valueOf(quant);
//                str[2] = String.valueOf(pur_bill);
//                str[3] = date_Format.format(jspn_date1.getDate());
//                str[4] = String.valueOf(available);
//                lbl_grand_tot.setText(String.valueOf(grad_tot));
//            }
//        }
//        if (metric == 2) {
//            if (drug_name.isEmpty()) {
//                sign = true;
//                status_In_Time("Select Drug", 2000);
//            }
//            try {
//                pur_bill = Integer.parseInt(txt_bill.getText());
//            } catch (Exception exp) {
//                sign = true;
//                status_In_Time("Invalid Bill", 2000);
//            }
//            if (pur_bill < 1 || quant < 0) {
//                sign = true;
//                status_In_Time(" !!!!!! ", 2000);
//            }
//            if (date_Format.format(jspn_date1.getDate()).equals(date_Format.format(new Date())) && sign == false) {
//                System.out.println(date_Format.format(new Date()) + "  =? " + date_Format.format(jspn_date1.getDate()));
//                sign = true;
//                status_In_Time("exp date", 2000);
//            }
//            if (sign == false) {
//                grad_tot += pur_bill;
//                str = new String[8];
//                str[0] = String.valueOf(drug_id);
//                str[1] = String.valueOf(quant);
//                str[2] = String.valueOf(pur_bill);
//                str[3] = date_Format.format(jspn_date1.getDate());
//                str[4] = drug_name;
//                str[5] = drug_group;
//                str[6] = drug_type;
//                str[7] = com_name;
//                lbl_grand_tot.setText(String.valueOf(grad_tot));
//                //                System.out.println(str[0] + " > " + str[1] + " > " + str[2] + " > " + str[3]);
//            }
//        }
//        if (metric == 0) {
//            if (drug_group.isEmpty() || com_name.isEmpty() || drug_name.isEmpty() || drug_type.isEmpty()) {
//                status_In_Time("Incomplete", 2200);
//                sign = true;
//            }
//            if (sign == false) {
//                str = new String[4];
//                str[0] = drug_name;
//                str[1] = drug_group;
//                str[2] = drug_type;
//                str[3] = com_name;
//            }
//        }
//        //                                                IF IT IS SENDING OR SAVING ORDER
//        if (metric == 1) {
//            if (quant < 1) {
//                sign = true;
//                status_In_Time("Not Yet", 2100);
//            }
//            if (sign == false) {
//                str = new String[5];
//                str[0] = String.valueOf(drug_id);
//                str[1] = drug_name;
//                str[2] = drug_group;
//                str[3] = drug_type;
//                str[4] = String.valueOf(quant);
//            }
//        }
//        //                                                  IF IT IS FOR PURCHASE
//
//        if (sign == false) {
//            System.out.println("  btn_done > done:  " + count_done + "  run: " + count_running);
//            if (count_running <= count_done) {
//                purchase_order.remove(count_running - 1);
//                purchase_order.add(count_running - 1, str);
//                btn_nextActionPerformed(evt);
//            } else {
//                purchase_order.add(count_done, str);
//                count_done += 1;
//                count_running += 1;
//                lbl_counter.setText("new/" + count_done);
//            }
//            btn_clearActionPerformed(evt);
//        }
    }//GEN-LAST:event_btn_doneActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add(jpnl_bed_history);
        jpnl_grand.add(jpnl_pat_personal);
        jpnl_grand.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((pat_adm = new Patient_Admission(1)));
        pat_adm.setLocation(0, 0);
        jpnl_grand.setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed
    public void View_Beds() {

    }
    private void btn_emptyBeds1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_emptyBeds1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_emptyBeds1ActionPerformed

    private void btn_emptyBeds2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_emptyBeds2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_emptyBeds2ActionPerformed

    private void cmb_bed_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_bed_by_deptActionPerformed
        // TODO add your handling code here:
        if (cmb_bed_by_dept.getSelectedIndex() > -1) {
            dept = cmb_bed_by_dept.getSelectedItem().toString();
            //  view_Doctors("SELECT * FROM doctors where dept = '" + dept + "'");
        }
    }//GEN-LAST:event_cmb_bed_by_deptActionPerformed

    private void btn_bedsEmptiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bedsEmptiesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_bedsEmptiesActionPerformed

    private void btn_bedsOccupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bedsOccupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_bedsOccupActionPerformed

    private void btn_run_in_pat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_run_in_pat1ActionPerformed
        // TODO add your handling code here:

        tbl_Result_ids = new ArrayList<>();

        query = "SELECT * FROM doctors";
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Name";
        coloumn[1] = "Department";
        coloumn[2] = "Contact";
        coloumn[3] = "desg";
        coloumn[4] = "Consultation Fee";

        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                tbl_Result_ids.add(Integer.parseInt(rs.getString("doc_id")));
                data[0] = rs.getString("name");
                data[1] = rs.getString("dept");
                data[2] = rs.getString("contact");
                data[3] = rs.getString("desg");
                data[4] = rs.getString("consultation_fee");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        tbl_Result_Type = "Consultants";

    }//GEN-LAST:event_btn_run_in_pat1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        setState(1);
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(In_Patient_Care_Unit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(In_Patient_Care_Unit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(In_Patient_Care_Unit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(In_Patient_Care_Unit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (ipcu = new In_Patient_Care_Unit()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_bedsAll;
    private javax.swing.JButton btn_bedsEmpties;
    private javax.swing.JButton btn_bedsOccup;
    private javax.swing.JButton btn_done;
    private javax.swing.JButton btn_emptyBeds1;
    private javax.swing.JButton btn_emptyBeds2;
    private javax.swing.JButton btn_login_out;
    private javax.swing.JButton btn_next;
    private javax.swing.JButton btn_run_in_pat;
    private javax.swing.JButton btn_run_in_pat1;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> cmb_bed_by_dept;
    private javax.swing.JComboBox<String> cmb_search_By;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel jpnl_bed_history;
    private javax.swing.JLabel jpnl_bill_title;
    private javax.swing.JPanel jpnl_functions;
    private javax.swing.JPanel jpnl_grand;
    private javax.swing.JPanel jpnl_login;
    private javax.swing.JPanel jpnl_next_back_done;
    private javax.swing.JPanel jpnl_pat_personal;
    private javax.swing.JPanel jpnl_with_tbl;
    private com.toedter.calendar.JSpinnerDateEditor jspn_date1;
    private com.toedter.calendar.JSpinnerDateEditor jspn_s_t;
    private javax.swing.JSpinner jspnr_disc;
    private javax.swing.JLabel lbl_add;
    private javax.swing.JLabel lbl_age;
    private javax.swing.JLabel lbl_care_of;
    private javax.swing.JLabel lbl_counter;
    private javax.swing.JLabel lbl_date4;
    private javax.swing.JLabel lbl_disc;
    private javax.swing.JLabel lbl_fam_contact;
    private javax.swing.JLabel lbl_id_bed;
    private javax.swing.JLabel lbl_missmtch;
    private javax.swing.JLabel lbl_pat_contact;
    private javax.swing.JLabel lbl_pat_name;
    private javax.swing.JLabel lbl_s_t;
    private javax.swing.JLabel lbl_tbl_title;
    private javax.swing.JRadioButton rbtn_cash;
    private javax.swing.JRadioButton rbtn_perc;
    public static javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_conf_pass;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextField txt_search_content2;
    private javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables
}
