/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Initiation;

import com.itextpdf.text.*;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.*;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Color;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfPage;
import com.sun.scenario.effect.ImageData;
import java.io.FileOutputStream;
import javax.swing.ImageIcon;
import com.itextpdf.text.Image;

import com.itextpdf.io.image.ImageDataFactory;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Masum Khan
 */
public class NewClass {

    static Connection con = null;
    static Statement st = null;
    static ResultSet temp_rs;
    static Statement temp_st = null;
    static String temp_query;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "pokath";
    static String db_userName = "root";
    static String db_password = "";

    public static void main(String args[]) {

        String fullString;
        try {

            Rectangle pageSize = new Rectangle(500, 600);
            pageSize.setBackgroundColor(new BaseColor(0xFF, 0xFF, 0xDE));

            Document document = new Document(pageSize);

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\app_To_Be.pdf"));
            com.itextpdf.text.Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
            document.open();

            fullString = "       md ahad hussain          \n\n";
            document.add(new Paragraph(fullString));
            document.add(Chunk.NEWLINE);

            font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLUE);
            Chunk chunk = new Chunk("Hello World ebfweifiweiuiuvweigivhweg \n\n", font);
            document.add(chunk);
            document.add(Chunk.NEWLINE);
            Paragraph p1 = new Paragraph("ha ha the last ");

            PdfContentByte cb = writer.getDirectContent();
            cb.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false), 24);
            cb.setColorFill(BaseColor.BLUE);
            cb.setRGBColorFill(120, 255, 300);
            cb.moveTo(400, 200);
            cb.lineTo(10, 200);
            cb.moveTo(410, 225);
            cb.lineTo(410, 100);
            cb.setLineDash((float) 1.8);
            cb = writer.getDirectContent();
            cb.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false), 24);
            cb.saveState();

            cb.beginText();
            cb.moveText(100, 200);

            cb.showText("i am last experiment  !");
            cb.endText();
            cb.restoreState();

            cb.stroke();
            document.close();
//
//            ImageIcon Myimage = new ImageIcon("C:\\Users\\Masum Khan\\Desktop\\ert.jpg");
//            java.awt.Image img = Myimage.getImage();
//            java.awt.Image newImage = img.getScaledInstance(100, 80, java.awt.Image.SCALE_SMOOTH);
//            // ImageIcon image = new ImageIcon(newImage);
//            Chunk fox = new Chunk(Image.getInstance("C:\\Users\\Masum Khan\\Desktop\\ert.jpg"), 0, -15);
//            Chunk dog = new Chunk(Image.getInstance("C:\\Users\\Masum Khan\\Desktop\\ert.png"), 0, -15);
            // Paragraph p = new Paragraph(fox);
//            p.add(fox);
//            p.add(dog);
            // document.add(p);
//            Image img2 = Image.getInstance("C:\\Users\\Masum Khan\\Desktop\\ert.png");
//            img2.setAbsolutePosition(200, 400);
            String imFile = "C:\\Users\\Masum Khan\\Desktop\\app_To_Be.pdf";
            File pdfFile = new File("C:/Users/Masum Khan/Desktop/app_To_Be.pdf");
            byte[] pdfData = new byte[(int) pdfFile.length()];
            DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
            dis.readFully(pdfData);  // read from file into byte[] array
            dis.close();
            FileInputStream fin = new FileInputStream(pdfFile);

            try {

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "UPDATE doctors SET"
                        + " image = ? "
                        + " WHERE doc_id = " + 2 + " ";
                pst = con.prepareStatement(query);
                //  pst.setBytes(1, pdfData); 
                pst.setBinaryStream(1, (InputStream) fin, (int) (pdfFile.length()));
                pst.executeUpdate();
                File file = new File("C:/Users/Masum Khan/Desktop/app_To_Be2.pdf");
                FileOutputStream output = new FileOutputStream(file);
                query = "SELECT image FROM doctors WHERE doc_id = " + 2;
                rs = st.executeQuery(query);
                while (rs.next()) {
                    InputStream input = rs.getBinaryStream("image");
                    byte[] buffer = new byte[1024];
                    while (input.read(buffer) > 0) {
                        output.write(buffer);
                    }
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
//            com.itextpdf.io.image.ImageData data = ImageDataFactory.create(imFile);
//            String dest = "C:\\Users\\Masum Khan\\Desktop\\app_To_Be.pdf";
//            com.itextpdf.kernel.pdf.PdfWriter writer2 = new com.itextpdf.kernel.pdf.PdfWriter(dest);
//
//            // Creating a PdfDocument       
//            com.itextpdf.kernel.pdf.PdfDocument pdf = new com.itextpdf.kernel.pdf.PdfDocument(writer2);
//
//            // Creating a Document        
//            com.itextpdf.layout.Document document2 = new com.itextpdf.layout.Document(pdf);
//            com.itextpdf.io.image.ImageData data2 = com.itextpdf.io.image.ImageDataFactory.create("C:\\Users\\Masum Khan\\Desktop\\ert.png");
//            com.itextpdf.layout.element.Image image2 = new com.itextpdf.layout.element.Image(data2);
//            // Creating an Image object        
//            // Image image2 = new Image(data);
//            document2.add(image2);

//            Image image = Image.getInstance(imFile);
//            image.scaleToFit(100f, 100f);
//            image.setAbsolutePosition(100, 300);
//            document.add(image);
//            document.add(p1);
//            document.addHeader("what would be the header ", "Header");
//            font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.GREEN);
//            chunk = new Chunk("Omega 400 taka only  \n\n", font);
//            document.add(chunk);
//            document.add(Chunk.NEWLINE);
//
//            
        } catch (Exception exp) {
            System.out.println(exp);
        }
    }
}
