/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Initiation;

// import static hmis_test.HMIS_TEST.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author pddrgj3q
 */
public class Test_DB {

    static Connection con = null;
    static Statement st = null;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String userName = "root";
    static String password = "";

    public Test_DB() {

        make_Up_DB();
    }

    public static void main(String args[]) {
        Test_DB db = new Test_DB();
    }

    public void make_Up_DB() {

        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(url, userName, password);

            rs = con.getMetaData().getCatalogs();
            boolean sign = false;
            System.out.println("reached");
            while (rs.next()) {
                if (dbName.equals(rs.getString(1))) {
                    sign = true;
                    System.out.println("the database " + dbName + " exists");
                    break;
                }
            }
            if (sign == false) {
                query = "CREATE DATABASE " + dbName;
                st = con.createStatement();
                st.executeUpdate(query);
                st.close();
                con = DriverManager.getConnection(url + dbName, userName, password);
                st = con.createStatement();

                query = "CREATE TABLE doctors ("
                        + "doc_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50) NULL, "
                        + "email VARCHAR(30) NULL,"
                        + "contact VARCHAR(20) NULL,"
                        + "nid VARCHAR(20) NULL,"
                        + "per_add VARCHAR(105) NULL,"
                        + "cur_add VARCHAR(105) NULL,"
                        + "dept VARCHAR(55) ,"
                        + "degrees VARCHAR(75),"
                        + "dob VARCHAR(15) NULL,"
                        + "doj VARCHAR(15) NULL,"
                        + "type VARCHAR(15) NULL,"
                        + "image MEDIUMBLOB NULL,"
                        + "consultation_fee int,"
                        + "appointment_fee int,"
                        + "office VARCHAR(15) NULL,"
                        + "doc_schedule VARCHAR(350) NULL,"
                        + "PRIMARY KEY (doc_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE accounts ("
                        + "user_id int ,"
                        + "user_name VARCHAR(55), "
                        + "pass VARCHAR(55), "
                        + "status VARCHAR(65) ,"
                        + "type VARCHAR(45),"
                        + "email VARCHAR(45),"
                        + "module VARCHAR(45))";
                st.executeUpdate(query);

                query = "CREATE TABLE in_pat_cases ("
                        + "case_id int NOT NULL AUTO_INCREMENT ,"
                        + "pat_id int NOT NULL ,"
                        + "case_title VARCHAR(50),"
                        + "care_of VARCHAR(45),"
                        + "dept VARCHAR(35),"
                        + "status VARCHAR(15),"
                        + "bill int NOT NULL ,"
                        + "report BLOB ,"
                        + "PRIMARY KEY (case_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE service_taking ("
                        + "case_id int NOT NULL ,"
                        + "report blob,"
                        + "monitor int ,"
                        + "approved_by VARCHAR(70),"
                        + "taken_charge int,"
                        + "time VARCHAR(20),"
                        + "ser_id int NOT NULL )";
                st.executeUpdate(query);

                query = "CREATE TABLE bed_booking ("
                        + "case_id int NOT NULL ,"
                        + "bed_id int NOT NULL ,"
                        + "booking_time VARCHAR(15),"
                        + "taken_charge  int,"
                        + "release_time VARCHAR(15))";
                st.executeUpdate(query);
                query = "CREATE TABLE patients ("
                        + "pat_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50) , "
                        + "email VARCHAR(30) NULL,"
                        + "contact VARCHAR(20) ,"
                        + "nid VARCHAR(20) NULL,"
                        + "address VARCHAR(45) NULL,"
                        + "family VARCHAR(55) ,"
                        + "gender VARCHAR(15),"
                        + "blood_group VARCHAR(10),"
                        + "dob VARCHAR(15),"
                        + "PRIMARY KEY (pat_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE system_executives ("
                        + "member_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50), "
                        + "email VARCHAR(30),"
                        + "nid VARCHAR(20),"
                        + "age INT(11),"
                        + "per_add VARCHAR(15),"
                        + "cur_add VARCHAR(15),"
                        + "contact VARCHAR(20),"
                        + "desg VARCHAR(15),"
                        + "image MEDIUMBLOB,"
                        + "PRIMARY KEY (member_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE beds ("
                        + "bed_id VARCHAR(25),"
                        + "dept VARCHAR(45),"
                        + "floor INT(11),"
                        + "room_num VARCHAR(30),"
                        + "type VARCHAR(50),"
                        + "receptivity INT(10),"
                        + "description TEXT,"
                        + "status VARCHAR(20) NULL,"
                        + "charge INT(10),"
                        + "vacancy INT(10),"
                        + "PRIMARY KEY (bed_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE Services ("
                        + "service_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(70), "
                        + "sub_name VARCHAR(80), "
                        + "type VARCHAR(65) NULL,"
                        + "description TEXT, "
                        + "charge int(11), "
                        + "PRIMARY KEY (service_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE departments ("
                        + "dept_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(75),"
                        + "description TEXT null,"
                        + "initiation VARCHAR(15) NULL,"
                        + "PRIMARY KEY (dept_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE med_tests ("
                        + "test_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(15),"
                        + "type VARCHAR(15),"
                        + "charge INT(12),"
                        + "testing_method VARCHAR(150),"
                        + "description TEXT,"
                        + "PRIMARY KEY (test_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE test_structure ("
                        + "test_id int(11) NOT NULL ,"
                        + "component_name VARCHAR(90),"
                        + "unit VARCHAR(55),"
                        + "reference VARCHAR(65))";
                st.executeUpdate(query);

                query = "CREATE TABLE Nurses ("
                        + "nurse_id int NOT NULL AUTO_INCREMENT,"
                        + "dept VARCHAR(30), "
                        + "name VARCHAR(50), "
                        + "email VARCHAR(30),"
                        + "contact VARCHAR(50),"
                        + "per_add VARCHAR(100),"
                        + "cur_add VARCHAR(100),"
                        + "nid VARCHAR(25),"
                        + "gender VARCHAR(15),"
                        + "dob VARCHAR(15),"
                        + "doj VARCHAR(15),"
                        + "type VARCHAR(55),"
                        + "salery int(11),"
                        + "image MEDIUMBLOB,"
                        + "PRIMARY KEY (nurse_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE appointments ("
                        + "app_id int NOT NULL AUTO_INCREMENT,"
                        + "doc_id int(11), "
                        + "pat_id int(11),"
                        + "date VARCHAR(20),"
                        + "status VARCHAR(20),"
                        + "prescription BLOB ,"
                        + "bill int(11) null,"
                        + "PRIMARY KEY (app_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE test_taking ("
                        + "event_id int NOT NULL AUTO_INCREMENT,"
                        + "pat_id int(11),"
                        + "event_date VARCHAR(20),"
                        + "PRIMARY KEY (event_id))";
                st.executeUpdate(query);

                query = "CREATE TABLE test_taking_detail ("
                        + "event_id int, "
                        + "test_id int(11),"
                        + "specimen_id VARCHAR(25),"
                        + "specimen_status VARCHAR(20),"
                        + "delivery_date VARCHAR(20),"
                        + "Tested_by int,"
                        + "test_result blob,"
                        + "status VARCHAR(20),"
                        + "bill int(11))";
                st.executeUpdate(query);

                query = "CREATE TABLE surgeries ("
                        + "surgery_id int, "
                        + "title VARCHAR(40),"
                        + "dept VARCHAR(35),"
                        + "method VARCHAR(80),"
                        + "type VARCHAR(40),"
                        + "prerequisit_diagnosis VARCHAR(50),"
                        + "charge int(11))";
                st.executeUpdate(query);

                query = "CREATE TABLE surgery_events ("
                        + "event_id int,"
                        + "pat_id int(11),"
                        + "care_of VARCHAR(20),"
                        + "surgical_procedure VARCHAR(80),"
                        + "date VARCHAR(20),"
                        + "pre_surgery_report blob,"
                        + "post_surgical_report blob,"
                        + "status VARCHAR(20))";
                st.executeUpdate(query);

                query = "CREATE TABLE  event_surgeons ("
                        + "event_id int,"
                        + "doc_id int(11),"
                        + "role VARCHAR(20))";
                st.executeUpdate(query);

                Test_Data testData = new Test_Data();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
