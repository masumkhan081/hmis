/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Initiation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Masum Khan
 */
public class Test_Data {

    static InputStream is;
    static Connection con = null;
    static Statement st = null;
    static ResultSet temp_rs;
    static Statement temp_st = null;
    static String temp_query;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String db_userName = "root";
    static String db_password = "";
    static String folderPath = "c:" + File.separator + "HMIS";
    static String origin = "D:\\CSE_150103020010\\HMIS__00000000000000000000\\HMIS_TEST_Copy\\src\\Sample_Data_Files\\";
    static String pathOfFile = "";

    static File file_ToBeRead;

    static JOptionPane jOptionPane;

    static Scanner scannerObj = new Scanner(System.in);
    static FileWriter docWriter;
    static BufferedWriter doc_BW;
    static FileOutputStream fos_Doc;

    public Test_Data() {

        insert_Sample();
    }

    public static void main(String[] args) {
        Test_Data obj = new Test_Data();
    }

    public void insert_Sample() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
        } catch (Exception exp) {
            System.out.println(exp);
        }
        insertSampleDocts();
        insertSamplePatients();
        insertSampleBeds();
        insertSampleDepts();
        insert_Appointments();
    }

    static void insert_Appointments() {

        String str[];
        pathOfFile = "C:" + File.separator + "HMIS" + File.separator + "Appointments.txt";
        String fullString;
        try {
            System.out.println("in try ");
            file_ToBeRead = new File(pathOfFile);
            System.out.println("in try 2");
            scannerObj = new Scanner(file_ToBeRead);
            System.out.println("in try 3");
            fullString = "";
            while (scannerObj.hasNextLine()) {
                fullString += scannerObj.nextLine();
            }
            str = fullString.split("}");
            System.out.println("fullstring:   " + str.length);
            for (int i = 0; i < str.length; i++) {
                String str2[];
                str2 = str[i].split("%");
                str2[0] = str2[0].replaceAll(" ", "");
                str2[1] = str2[1].replaceAll(" ", "");
                str2[2] = str2[2].replaceAll(" ", "");
                System.out.println(str2[1] + "   ids: " + Integer.parseInt(str2[0]));
                pst = con.prepareStatement("insert into appointments values(?,?,?,?,?,?,?)");
                pst.setInt(1, Integer.parseInt(str2[0]));
                pst.setInt(2, Integer.parseInt(str2[1]));
                pst.setInt(3, Integer.parseInt(str2[2]));
                pst.setString(4, str2[3]);
                pst.setString(5, str2[4]);
                pst.setBinaryStream(6, is);
                pst.setInt(7, 500);

                pst.executeUpdate();
            }
        } catch (Exception ex) {
            System.out.println(">>   " + ex);
        }

    }

    static void insertSampleDepts() {

        String str[];
        pathOfFile = pathOfFile + "Departments.txt";
        String fullString;
        try {
            file_ToBeRead = new File(pathOfFile);
            scannerObj = new Scanner(file_ToBeRead);
            fullString = "";
            while (scannerObj.hasNextLine()) {
                fullString += scannerObj.nextLine();
            }
            str = fullString.split("}");

            for (int i = 0; i < str.length; i++) {
                String str2[];
                str2 = str[i].split("%");
                if (str2[0].contains(" ")) {
                    str2[0] = str2[0].replaceAll(" ", "");
                }
                System.out.println(str2[1] + "   ids: " + Integer.parseInt(str2[0]));
                pst = con.prepareStatement("insert into departments values(?,?,?,?)");
                pst.setInt(1, Integer.parseInt(str2[0]));
                pst.setString(2, str2[1]);
                pst.setString(3, "");
                pst.setString(4, "");

                pst.executeUpdate();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    static void insertSampleBeds() {

        String str[];
        pathOfFile = "C:" + File.separator + "HMIS" + File.separator + "Beds.txt";
        String fullString;
        try {
            file_ToBeRead = new File(pathOfFile);
            scannerObj = new Scanner(file_ToBeRead);
            fullString = "";
            while (scannerObj.hasNextLine()) {
                fullString += scannerObj.nextLine();
            }
            str = fullString.split("}");

            for (int i = 0; i < str.length; i++) {
                String str2[];
                str2 = str[i].split("%");
                if (str2[0].contains(" ")) {
                    str2[0] = str2[0].replaceAll(" ", "");
                }

                if (str2[5].contains(" ")) {
                    str2[5] = str2[5].replaceAll(" ", "");
                }
                if (str2[7].contains(" ")) {
                    str2[7] = str2[7].replaceAll(" ", "");
                }

                pst = con.prepareStatement("insert into beds values(?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, Integer.parseInt(str2[0]));
                pst.setString(2, str2[1]);
                pst.setString(3, str2[2]);
                pst.setString(4, str2[3]);
                pst.setString(5, str2[4]);
                pst.setInt(6, Integer.parseInt(str2[5]));
                pst.setString(7, " ");
                pst.setString(8, str2[6]);
                pst.setInt(9, Integer.parseInt(str2[7]));
                pst.setInt(10, Integer.parseInt(str2[5]));
                pst.executeUpdate();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    static void insertSamplePatients() {
        String str[];
        pathOfFile += "Patients.txt";
        String fullString;
        try {
            file_ToBeRead = new File(pathOfFile);
            scannerObj = new Scanner(file_ToBeRead);
            fullString = "";
            while (scannerObj.hasNextLine()) {
                fullString += scannerObj.nextLine();
            }
            str = fullString.split("}");

            for (int i = 0; i < str.length; i++) {
                String str2[];
                str2 = str[i].split("%");
                str2[0] = str2[0].replaceAll(" ", "");
                pst = con.prepareStatement("insert into patients values(?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, Integer.parseInt(str2[0]));
                pst.setString(2, str2[1]);
                pst.setString(3, str2[2]);
                pst.setString(4, str2[3]);
                pst.setString(5, "");
                pst.setString(6, str2[4]);
                pst.setString(7, str2[5]);
                pst.setString(8, str2[6]);
                pst.setString(9, str2[7]);
                pst.setString(10, str2[8]);
                pst.executeUpdate();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    static void insertSampleDocts() {
        try {
            pathOfFile = pathOfFile + "Doctors.txt";
            boolean successbool = (new File(folderPath)).mkdirs();
            file_ToBeRead = new File(pathOfFile);
            scannerObj = new Scanner(file_ToBeRead);
            String fullString = "";
            while (scannerObj.hasNextLine()) {
                fullString += scannerObj.nextLine();
            }
            String str[] = fullString.split("}");

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            System.out.println("str len: " + str.length);
            for (int i = 0; i < str.length; i++) {
                String str2[] = new String[15];
                str2 = str[i].split("%");
                System.out.println("  " + str2[0] + "   <>  " + str2[1]);
                str2[0] = str2[0].replaceAll(" ", "");

                str2[11] = str2[11].replaceAll(" ", "");
                str2[12] = str2[12].replaceAll(" ", "");
                System.out.println("++++  " + Integer.parseInt(str2[0]));
                System.out.println("\n");
                pst = con.prepareStatement("insert into doctors values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, Integer.parseInt(str2[0]));
                pst.setString(2, str2[1]);
                pst.setString(3, str2[2]);
                pst.setString(4, str2[3]);
                pst.setString(5, str2[4]);
                pst.setString(6, str2[5]);
                pst.setString(7, str2[6]);
                pst.setString(8, str2[7]);
                pst.setString(9, str2[8]);
                pst.setString(10, str2[9]);
                pst.setString(11, "");
                pst.setString(12, str2[10]);
                pst.setBinaryStream(13, null);
                pst.setInt(14, Integer.parseInt(str2[11]));
                pst.setInt(15, Integer.parseInt(str2[12]));
                pst.setString(16, str2[13]);
                pst.setString(17, str2[14]);

                pst.executeUpdate();
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
