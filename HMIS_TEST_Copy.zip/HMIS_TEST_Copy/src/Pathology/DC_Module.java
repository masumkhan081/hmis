/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pathology;

import Pathology.TestTaking;
import com.itextpdf.text.BaseColor;
import com.jtattoo.plaf.BaseComboBoxUI;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.InputStream;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.Barcode128;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import java.io.FileOutputStream;
import javax.swing.text.LabelView;

/**
 *
 * @author pddrgj3q
 */
public class DC_Module extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form DC_Module
     */
    static boolean pat_selection, test_selection, sign;
    static int test_taking_pat_id, taken_test_id, taken_test_charge, test_ID, evt_id, discount, id, specimen_evtID, specimen_testID;
    static String taken_test_method, taken_test_type, taken_test_name, del_date, lbl_title;
    static String str[];
    static JButton btn_minn, btn_exitt, btn_gap;
    int pX, pY;
    static InputStream is;
    static TestTaking test_taking;
    static DefaultListModel jlist_model;
    static ArrayList<String[]> arr_show;
    static ArrayList<String> test_types;
    static ArrayList<Integer> ids;
    //  public String lbl_title = "";
    static DateFormat date_Format;
    static int grand_tot;
    static New_Patient new_pat;
    static DefaultComboBoxModel cmb_model;
    static ArrayList<String[]> tests_Taken;
    static DC_Module dc_Module;
    static Connection con = null;
    static Statement st = null;
    static Statement temp_st = null;
    static JFrame jfr;
    static ResultSet rs;
    static ResultSet temp_rs;
    static String query;
    static String temp_query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String db_UserName = "root";
    static String db_UserPass = "";
    static ArrayList<String> sugg;
    ArrayList<String[]> contacts;
    static java.awt.event.ActionEvent evt;
    static JTextField txt_spec_id;
    static com.toedter.calendar.JSpinnerDateEditor jspn_collTime;
    static JButton close, save;
    static Label lbl_spec_ID;
    static TestResult_Form resultForm;

    public DC_Module() {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        btn_exitt = new JButton(" X ");

        btn_exitt.setBackground(Color.BLACK);
        btn_exitt.setFont(new Font("Segoe UI Black", Font.BOLD, 15));

        btn_exitt.setBorder(new EmptyBorder(1, 1, 1, 1));
        btn_exitt.setForeground(Color.CYAN);

        btn_minn = new JButton(" Min ");
        btn_minn.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
        btn_minn.setBorder(new EmptyBorder(1, 1, 1, 1));
        btn_minn.setBackground(Color.BLACK);
        btn_minn.setForeground(Color.CYAN);
        btn_exitt.addActionListener(this);
        btn_minn.addActionListener(this);
        jspn_delivered_on.setEditor(new JSpinner.DateEditor(jspn_delivered_on, "dd/MM/yyyy"));
        jspn_delivered_on.setDate(new Date());
        jspn_admitted_on.setEditor(new JSpinner.DateEditor(jspn_admitted_on, "dd/MM/yyyy"));
        jspn_admitted_on.setDate(new Date());
        date_Format = new SimpleDateFormat("dd/MM/yyyy");
        jlist_model = new DefaultListModel();
        tests_Taken = new ArrayList<>();
        setTypes();
        get_Patients();

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });

        DocumentListener documentListener = new DocumentListener() {
            public void changedUpdate(DocumentEvent documentEvent) {
                btn_searchActionPerformed(evt);
            }

            public void insertUpdate(DocumentEvent documentEvent) {
                btn_searchActionPerformed(evt);
            }

            public void removeUpdate(DocumentEvent documentEvent) {
                btn_searchActionPerformed(evt);
            }
        };
        txt_search.getDocument().addDocumentListener(documentListener);

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == btn_exitt) {
            System.exit(0);
        }
        if (ae.getSource() == btn_minn) {
            setState(1);
        }
        if (ae.getSource() == save) {
            String specimen_ID;
            del_date = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(jspn_collTime.getDate());
            System.out.println("to be saved  " + del_date);

            if (!del_date.isEmpty()) {
                lbl_spec_ID.setText("Specimen ID: " + specimen_evtID + "_" + specimen_testID + "_" + del_date);
                lbl_spec_ID.setVisible(true);
                save.setEnabled(false);

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
                    st = con.createStatement();

                    query = "UPDATE test_taking_detail SET"
                            + " specimen_id = ? ,"
                            + " specimen_status =? "
                            + " WHERE event_id = '" + specimen_evtID + "' AND test_id = '" + specimen_testID + "'";
                    pst = con.prepareStatement(query);
                    pst.setString(1, specimen_evtID + "_" + specimen_testID + "_" + del_date);
                    pst.setString(2, "Collected");

                    pst.executeUpdate();

                } catch (Exception npe) {
                    System.out.println("in execution >>>>" + npe);
                }
            }
        }
        if (ae.getSource() == close) {
            System.out.println("to be closed");
            jpnl_grand.setVisible(false);
            jpnl_grand.removeAll();
            jpnl_grand.setVisible(true);

        }
    }

    public void get_Patients() {
        //mnbv
        String str[];
        contacts = new ArrayList<>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT DISTINCT pat_id FROM test_taking";
            rs = st.executeQuery(query);
            while (rs.next()) {
                str = new String[2];
                id = rs.getInt("pat_id");
                System.out.println("id:  ? " + id);
                str[0] = String.valueOf(id);
                temp_query = "SELECT  contact FROM patients WHERE pat_id ='" + id + "'";
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    str[1] = temp_rs.getString("contact");
                }
                contacts.add(str);
                System.out.println(str[0] + "   ?? " + str[1]);
            }
        } catch (Exception exp) {
            System.out.println(exp + " get_Patients");
        }

    }

    public void clear_Grand_Pnl() {

        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }

    public void setTypes() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "SELECT DISTINCT type from med_tests ;";
            rs = st.executeQuery(query);
            sugg.add("All");
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_test_by_type.setModel(cmb_model);
            sugg.clear();
            cmb_test_by_type.setSelectedIndex(-1);
        } catch (Exception exp) {
            System.out.println("exception in get coms.. " + exp);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        txt_search = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        txt_u_name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_pass = new javax.swing.JTextField();
        lbl_con_pass = new javax.swing.JLabel();
        txt_conf_pass = new javax.swing.JTextField();
        btn_login_out = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        lbl_msg = new javax.swing.JLabel();
        chk_pat_con = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jpnl_grand = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_view_tests = new javax.swing.JButton();
        cmb_test_by_type = new javax.swing.JComboBox<>();
        btn_test_detail = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        btn_rec_examination = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jspn_delivered_on = new com.toedter.calendar.JSpinnerDateEditor();
        btn_exp_before_list = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jspn_admitted_on = new com.toedter.calendar.JSpinnerDateEditor();
        btn_exp_before_list1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btn_view_patients = new javax.swing.JButton();
        btn_view_patients1 = new javax.swing.JButton();
        btn_view_patients2 = new javax.swing.JButton();
        btn_add_specimen = new javax.swing.JButton();
        btn_rec_examination2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        lbl_tbl_title = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1118, 582));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 4, true));
        jPanel1.setMaximumSize(new java.awt.Dimension(1310, 712));
        jPanel1.setMinimumSize(new java.awt.Dimension(1310, 712));
        jPanel1.setPreferredSize(new java.awt.Dimension(1310, 712));

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));
        jPanel4.setMaximumSize(new java.awt.Dimension(1252, 130));
        jPanel4.setMinimumSize(new java.awt.Dimension(1252, 130));
        jPanel4.setPreferredSize(new java.awt.Dimension(1252, 130));

        jButton7.setBackground(new java.awt.Color(0, 51, 51));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton7.setForeground(new java.awt.Color(204, 255, 153));
        jButton7.setText("min");
        jButton7.setBorder(null);
        jButton7.setBorderPainted(false);
        jButton7.setMaximumSize(new java.awt.Dimension(55, 22));
        jButton7.setMinimumSize(new java.awt.Dimension(55, 22));
        jButton7.setPreferredSize(new java.awt.Dimension(55, 22));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 51, 51));
        jButton6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton6.setForeground(new java.awt.Color(204, 255, 153));
        jButton6.setText("exit");
        jButton6.setBorder(null);
        jButton6.setBorderPainted(false);
        jButton6.setMaximumSize(new java.awt.Dimension(55, 22));
        jButton6.setMinimumSize(new java.awt.Dimension(55, 22));
        jButton6.setPreferredSize(new java.awt.Dimension(55, 22));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        txt_search.setBackground(new java.awt.Color(204, 204, 255));
        txt_search.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        txt_search.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_search.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btn_search.setBackground(new java.awt.Color(1, 34, 34));
        btn_search.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_search.setForeground(new java.awt.Color(204, 204, 255));
        btn_search.setText("Search");
        btn_search.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Pass:");

        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        lbl_con_pass.setBackground(new java.awt.Color(255, 255, 255));
        lbl_con_pass.setText("confirm:");

        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btn_login_out.setBackground(new java.awt.Color(255, 255, 255));
        btn_login_out.setText("Log In");
        btn_login_out.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(255, 255, 255));
        btn_update.setText("Edit");
        btn_update.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lbl_msg.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_update))
                    .addComponent(txt_u_name)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_con_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_pass)
                            .addComponent(txt_conf_pass, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_con_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        chk_pat_con.setBackground(new java.awt.Color(204, 255, 204));
        chk_pat_con.setText("Patient / Contact");
        chk_pat_con.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_pat_conActionPerformed(evt);
            }
        });

        jCheckBox2.setBackground(new java.awt.Color(204, 255, 204));
        jCheckBox2.setText("Test / Title");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(chk_pat_con, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addComponent(jCheckBox2)
                        .addGap(0, 0, 0)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chk_pat_con)
                            .addComponent(txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnl_grand.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_grand.setMaximumSize(new java.awt.Dimension(368, 500));
        jpnl_grand.setMinimumSize(new java.awt.Dimension(368, 500));
        jpnl_grand.setPreferredSize(new java.awt.Dimension(368, 500));

        javax.swing.GroupLayout jpnl_grandLayout = new javax.swing.GroupLayout(jpnl_grand);
        jpnl_grand.setLayout(jpnl_grandLayout);
        jpnl_grandLayout.setHorizontalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jpnl_grandLayout.setVerticalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 553, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));

        btn_view_tests.setBackground(new java.awt.Color(204, 255, 204));
        btn_view_tests.setText("View Tests");
        btn_view_tests.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_tests.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_testsActionPerformed(evt);
            }
        });

        cmb_test_by_type.setBackground(new java.awt.Color(204, 255, 204));
        cmb_test_by_type.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        cmb_test_by_type.setOpaque(false);
        cmb_test_by_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_test_by_typeActionPerformed(evt);
            }
        });

        btn_test_detail.setBackground(new java.awt.Color(204, 255, 204));
        btn_test_detail.setText("Test Detail");
        btn_test_detail.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_test_detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_test_detailActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(204, 255, 204));
        jButton8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton8.setText("New Patient");
        jButton8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jButton8.setContentAreaFilled(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(204, 255, 204));
        jButton4.setText("To be delivered");
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(204, 255, 204));
        jButton5.setText("Recently delivered");
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        btn_rec_examination.setBackground(new java.awt.Color(204, 255, 204));
        btn_rec_examination.setText("Test Taking");
        btn_rec_examination.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        btn_rec_examination.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_rec_examinationActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(23, 32, 32));
        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 51, 0));
        jLabel2.setText("  Delivered On:");

        jspn_delivered_on.setBackground(new java.awt.Color(204, 255, 204));
        jspn_delivered_on.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_delivered_on.setForeground(new java.awt.Color(0, 0, 0));
        jspn_delivered_on.setModel(new javax.swing.SpinnerDateModel());
        jspn_delivered_on.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N

        btn_exp_before_list.setBackground(new java.awt.Color(204, 255, 204));
        btn_exp_before_list.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        btn_exp_before_list.setText("go");
        btn_exp_before_list.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_exp_before_list.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exp_before_listActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(23, 32, 32));
        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 51, 0));
        jLabel3.setText("Patient admitted on:");

        jspn_admitted_on.setBackground(new java.awt.Color(204, 255, 204));
        jspn_admitted_on.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_admitted_on.setForeground(new java.awt.Color(0, 0, 0));
        jspn_admitted_on.setModel(new javax.swing.SpinnerDateModel());
        jspn_admitted_on.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N

        btn_exp_before_list1.setBackground(new java.awt.Color(204, 255, 204));
        btn_exp_before_list1.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        btn_exp_before_list1.setText("go");
        btn_exp_before_list1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_exp_before_list1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exp_before_list1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(23, 32, 32));
        jButton2.setForeground(new java.awt.Color(255, 255, 153));
        jButton2.setText("Change Delivery Status ");

        jLabel1.setText("  Regular Action");
        jLabel1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(102, 51, 0)));

        jLabel4.setText("  Regular View");
        jLabel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(102, 51, 0)));

        btn_view_patients.setBackground(new java.awt.Color(204, 255, 204));
        btn_view_patients.setText("Patients");
        btn_view_patients.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_patients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_patientsActionPerformed(evt);
            }
        });

        btn_view_patients1.setBackground(new java.awt.Color(204, 255, 204));
        btn_view_patients1.setText("Tests Off Specimen");
        btn_view_patients1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_patients1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_patients1ActionPerformed(evt);
            }
        });

        btn_view_patients2.setBackground(new java.awt.Color(204, 255, 204));
        btn_view_patients2.setText("Tests Off Result");
        btn_view_patients2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_patients2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_patients2ActionPerformed(evt);
            }
        });

        btn_add_specimen.setBackground(new java.awt.Color(204, 255, 204));
        btn_add_specimen.setText("Add Specimen");
        btn_add_specimen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        btn_add_specimen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_specimenActionPerformed(evt);
            }
        });

        btn_rec_examination2.setBackground(new java.awt.Color(204, 255, 204));
        btn_rec_examination2.setText("Add Result");
        btn_rec_examination2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        btn_rec_examination2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_rec_examination2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jspn_delivered_on, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(btn_exp_before_list, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jspn_admitted_on, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(btn_exp_before_list1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_rec_examination, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
                    .addComponent(btn_view_tests, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_test_by_type, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_test_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btn_view_patients1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                        .addComponent(btn_view_patients, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btn_view_patients2, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_add_specimen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                            .addComponent(btn_rec_examination2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_rec_examination, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_add_specimen, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(btn_rec_examination2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_tests, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(cmb_test_by_type, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_view_patients, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_patients1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_patients2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_test_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jspn_delivered_on, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_exp_before_list, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jspn_admitted_on, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_exp_before_list1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setMaximumSize(new java.awt.Dimension(738, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(738, 500));

        tbl_Result_Exhibition.setAutoCreateRowSorter(true);
        tbl_Result_Exhibition.setBackground(new java.awt.Color(6, 35, 35));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(204, 255, 204));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setFillsViewportHeight(true);
        tbl_Result_Exhibition.setFocusCycleRoot(true);
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 51, 51));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setRowHeight(25);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(19, 36, 36));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(255, 204, 102));
        jScrollPane2.setViewportView(tbl_Result_Exhibition);

        lbl_tbl_title.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_tbl_title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_tbl_title.setText("Result Title");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnl_grand, javax.swing.GroupLayout.DEFAULT_SIZE, 410, Short.MAX_VALUE))
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 1302, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jpnl_grand, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
//        jPanel2.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void cmb_test_by_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_test_by_typeActionPerformed
        // TODO add your handling code here:
        if (cmb_test_by_type.getSelectedIndex() == 0) {
            view_Tests("SELECT * FROM med_tests", "Medical Tests (All)");
            lbl_title = "Medical Tests (All)";
        }
        if (cmb_test_by_type.getSelectedIndex() > 0) {

            view_Tests("SELECT * FROM med_tests WHERE  type= '" + cmb_test_by_type.getSelectedItem().toString() + "'", "Medical Tests of  (" + cmb_test_by_type.getSelectedItem().toString() + ")");
            lbl_title = "Medical Tests Of " + cmb_test_by_type.getSelectedItem().toString();
        }
        lbl_tbl_title.setText(lbl_title);
    }//GEN-LAST:event_cmb_test_by_typeActionPerformed

    private void btn_rec_examinationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_rec_examinationActionPerformed
        // TODO add your handling code here:
        pat_selection = false;
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((test_taking = new TestTaking()));
        test_taking.setLocation(0, 20);
        jpnl_grand.setVisible(true);

    }//GEN-LAST:event_btn_rec_examinationActionPerformed

    private void btn_exp_before_listActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exp_before_listActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_exp_before_listActionPerformed

    private void btn_exp_before_list1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exp_before_list1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_exp_before_list1ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        setState(1);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        dc_Module = null;
    }//GEN-LAST:event_jButton6ActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:

        String u_name, pass;
        if (btn_login_out.getText().equals("Log In")) {
            u_name = txt_u_name.getText();
            pass = txt_pass.getText();
            System.out.println(u_name + "   " + pass);
            try {

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);

                st = con.createStatement();
                query = "SELECT * FROM accounts ";

                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (u_name.equals(rs.getString("user_name")) && pass.equals(rs.getString("pass")) && rs.getString("module").equals("Diagnostic Center")) {
                        sign = true;
                        break;
                    }
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
            if (sign == true) {
                set_Up_Module(sign);
            } else {
                status_In_Time("Missmatch !", 1500);
            }
        } else {
            System.exit(0);
        }

    }//GEN-LAST:event_btn_login_outActionPerformed
    public void view_Tests(String q, String title) {
        query = q;
        lbl_title = title;
        String[] coloumn = new String[4];
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();
        ids = new ArrayList<>();

        coloumn[0] = "name";
        coloumn[1] = "Type";
        coloumn[2] = "Test Method";
        coloumn[3] = "Charge";
        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();

            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("name");
                data[1] = rs.getString("type");
                data[2] = rs.getString("testing_method");
                data[3] = rs.getString("charge");
                id = rs.getInt(1);
                System.out.println("id: " + id);
                sign = false;
                ids.add(id);
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
                arr_show.clear();
            }
            lbl_tbl_title.setText(lbl_title);
        } catch (Exception ex) {
            System.out.println("view tests :" + ex);
        }
    }
    private void btn_view_testsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_testsActionPerformed
        // TODO add your handling code here:  
        view_Tests("SELECT * FROM med_tests", "Medical Tests (All)");
        lbl_title = "Medical Tests (All)";

    }//GEN-LAST:event_btn_view_testsActionPerformed

    private void btn_test_detailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_test_detailActionPerformed
        // TODO add your handling code here:

        int row = tbl_Result_Exhibition.getSelectedRow();
        if (row > -1 && lbl_tbl_title.getText().startsWith("Medical Tests")) {
            test_ID = ids.get(row);
            Test_Detail testDetail = new Test_Detail();
        }

    }//GEN-LAST:event_btn_test_detailActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:

        ids = new ArrayList();
        ResultSet temp_rs;
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Event ID";
        coloumn[1] = "Test ID";
        coloumn[2] = "Patient name";
        coloumn[3] = "Contact";
        coloumn[4] = "Issued On";
        coloumn[5] = "Del Date";
        sign = false;
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "SELECT * FROM test_taking_detail WHERE status = 'Ready'";
            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("event_id");
                data[1] = rs.getString("test_id");
                data[5] = rs.getString("delivery_date");
                System.out.println(data[1] + "      ?============= " + data[0]);
                temp_query = "SELECT * FROM test_taking WHERE event_id = " + Integer.parseInt(data[0]);
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    id = temp_rs.getInt("pat_id");
                    data[4] = temp_rs.getString("event_date");

                }
                temp_query = "SELECT * FROM patients WHERE pat_id = " + id;
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[2] = temp_rs.getString("name");
                    data[3] = temp_rs.getString("contact");
                }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("oh ! dump ass " + ex);
        }
        lbl_tbl_title.setText("Tests Not Delivered Yet");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(70);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_pat = new New_Patient()));
        new_pat.setLocation(0, 25);
        jpnl_grand.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed
    public void view_Patients(String q, String title) {

        query = q;
        lbl_title = title;
        String[] coloumn = new String[5];
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();
        ids = new ArrayList<>();
        coloumn[0] = "ID";
        coloumn[1] = "Patient name";
        coloumn[2] = "Address";
        coloumn[3] = "Contact";
        coloumn[4] = "dob";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();

            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("pat_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("address");
                data[3] = rs.getString("contact");
                data[4] = rs.getString("dob");
                ids.add(Integer.parseInt(data[0]));
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
            arr_show.clear();
        } catch (Exception ex) {
            System.out.println("view patients :" + ex);
        }
        lbl_tbl_title.setText(lbl_title);
    }
    private void btn_view_patientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_patientsActionPerformed
        // TODO add your handling code here:
        view_Patients("SELECT * FROM  patients", "Patients (All)");
    }//GEN-LAST:event_btn_view_patientsActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        // TODO add your handling code here:

        String content = txt_search.getText();
        System.out.println("got shot ");
        if (chk_pat_con.isSelected()) {

            String[] coloumn = new String[3];
            String[] data = new String[3];
            arr_show = new ArrayList<String[]>();
            ids = new ArrayList<>();
            coloumn[0] = "Full Name";
            coloumn[1] = "Contact";
            coloumn[2] = "Address";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dm);
            if (content.length() > 5) {
                for (int i = 0; i < contacts.size(); i++) {
                    id = Integer.parseInt(contacts.get(i)[0]);
                    System.out.println(content + "  >>>%  " + contacts.get(i)[1]);
                    if (contacts.get(i)[1].startsWith(content)) {
                        try {
                            Class.forName("com.mysql.jdbc.Driver");
                            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
                            st = con.createStatement();
                            query = "SELECT * FROM patients WHERE pat_id =" + id;
                            rs = st.executeQuery(query);
                            while (rs.next()) {
                                data[0] = rs.getString("name");
                                data[1] = rs.getString("contact");
                                data[2] = rs.getString("address");
                                ids.add(rs.getInt("pat_id"));
                                arr_show.add(data);
                                dm.addRow(arr_show.get(0));
                                arr_show.clear();
                            }
                            lbl_tbl_title.setText("Resulted Patients:");
                        } catch (Exception ex) {
                            System.out.println(" btn_searchActionPerformed :" + ex);
                        }
                    }
                }
            } else {
                tbl_Result_Exhibition.removeAll();
            }
        }

    }//GEN-LAST:event_btn_searchActionPerformed

    private void btn_view_patients1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_patients1ActionPerformed
        // TODO add your handling code here:

        ids = new ArrayList();
        ResultSet temp_rs;
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Event ID";
        coloumn[1] = "Test ID";
        coloumn[2] = "Patient name";
        coloumn[3] = "Contact";
        coloumn[4] = "Issued On";
        coloumn[5] = "Del Date";
        sign = false;
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "SELECT * FROM test_taking_detail WHERE specimen_status = 'Not Collected'";
            rs = st.executeQuery(query);
            while (rs.next()) {
//                evt_id = rs.getInt("event_id");
//                test_ID = rs.getInt("test_id");
//                ids.add(evt_id);
//                ids.add(test_ID); 
                data[0] = rs.getString("event_id");
                data[1] = rs.getString("test_id");
                data[5] = rs.getString("delivery_date");
                System.out.println(data[1] + "      ?============= " + data[0]);
                temp_query = "SELECT * FROM test_taking WHERE event_id = " + Integer.parseInt(data[0]);
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    id = temp_rs.getInt("pat_id");
                    data[4] = temp_rs.getString("event_date");

                }
                temp_query = "SELECT * FROM patients WHERE pat_id = " + id;
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[2] = temp_rs.getString("name");
                    data[3] = temp_rs.getString("contact");
                }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("oh ! dump ass " + ex);
        }
        lbl_tbl_title.setText("Tests With No Specimen Attached");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(70);

    }//GEN-LAST:event_btn_view_patients1ActionPerformed

    private void btn_view_patients2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_patients2ActionPerformed
        // TODO add your handling code here:
        ids = new ArrayList();
        ResultSet temp_rs;
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Event ID";
        coloumn[1] = "Test ID";
        coloumn[2] = "Patient name";
        coloumn[3] = "Contact";
        coloumn[4] = "Issued On";
        coloumn[5] = "Del Date";
        sign = false;
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "SELECT * FROM test_taking_detail WHERE specimen_status = 'Collected' AND status ='Not Ready' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("event_id");
                data[1] = rs.getString("test_id");
                data[5] = rs.getString("delivery_date");
                System.out.println(data[1] + "      ?============= " + data[0]);
                temp_query = "SELECT * FROM test_taking WHERE event_id = " + Integer.parseInt(data[0]);
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    id = temp_rs.getInt("pat_id");
                    data[4] = temp_rs.getString("event_date");
                }
                temp_query = "SELECT * FROM patients WHERE pat_id = " + id;
                st = con.createStatement();
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[2] = temp_rs.getString("name");
                    data[3] = temp_rs.getString("contact");
                }
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println("oh ! dump ass " + ex);
        }
        lbl_tbl_title.setText("Tests With No Result Attached");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(70);


    }//GEN-LAST:event_btn_view_patients2ActionPerformed

    private void chk_pat_conActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_pat_conActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chk_pat_conActionPerformed

    private void btn_add_specimenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_specimenActionPerformed
        // TODO add your handling code here:
        jpnl_grand.setVisible(false);
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(true);

        int row = tbl_Result_Exhibition.getSelectedRow();
        if (lbl_tbl_title.getText().startsWith("Tests With No Specimen") && row > -1
                && tbl_Result_Exhibition.getSelectedRows().length == 1) {

            specimen_evtID = Integer.parseInt(tbl_Result_Exhibition.getValueAt(row, 0).toString());
            specimen_testID = Integer.parseInt(tbl_Result_Exhibition.getValueAt(row, 1).toString());

            jpnl_grand.setVisible(false);
            System.out.println("reached !");

            Label title = new Label("Specimen Collection Record:");
            title.setSize(250, 18);
            title.setLocation(15, 18);
            title.setFont(new Font("Tahoma", Font.BOLD, 16));

            lbl_spec_ID = new Label("Specimen ID:");
            lbl_spec_ID.setFont(new Font("Tahoma", Font.BOLD, 13));
            lbl_spec_ID.setLocation(26, 140);
            lbl_spec_ID.setSize(220, 28);

//            txt_spec_id = new JTextField();
//            txt_spec_id.setLocation(136, 140);
//            txt_spec_id.setSize(125, 28);
//            txt_spec_id.setFont(new Font("Tahoma", Font.BOLD, 14));
            Label lbl_time = new Label("Collection Time:");
            lbl_time.setFont(new Font("Tahoma", Font.BOLD, 13));
            lbl_time.setSize(110, 25);
            lbl_time.setLocation(26, 190);
            jspn_collTime = new com.toedter.calendar.JSpinnerDateEditor();
            jspn_collTime.setValue(new Date(System.currentTimeMillis()));
            ((JSpinner.DateEditor) jspn_collTime.getEditor()).getFormat().applyPattern("dd.MM.yy HH:mm");
            jspn_collTime.setModel(new javax.swing.SpinnerDateModel());
            jspn_collTime.setLocation(136, 190);
            jspn_collTime.setSize(125, 28);
            jspn_collTime.setFont(new Font("Tahoma", Font.BOLD, 13));

            save = new JButton("Save");
            save.setFont(new Font("Tahoma", Font.BOLD, 14));
            save.setLocation(100, 255);
            save.setSize(100, 24);
            save.setBackground(Color.BLACK);
            save.setForeground(new Color(255, 204, 102));

            close = new JButton("X");
            close.setFont(new Font("Tahoma", Font.BOLD, 16));
            close.setLocation(265, 18);
            close.setSize(70, 22);
            close.setBackground(Color.BLACK);
            close.setForeground(new Color(255, 204, 102));

            close.addActionListener(this);
            save.addActionListener(this);
            tbl_Result_Exhibition.clearSelection();
            jpnl_grand.add(lbl_time);
            jpnl_grand.add(lbl_spec_ID);
            jpnl_grand.add(jspn_collTime);
            jpnl_grand.add(title);
            jpnl_grand.add(save);
            jpnl_grand.add(close);
            jpnl_grand.setVisible(true);
        }
    }//GEN-LAST:event_btn_add_specimenActionPerformed

    private void btn_rec_examination2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_rec_examination2ActionPerformed
        // TODO add your handling code here:
        int ind = tbl_Result_Exhibition.getSelectedRow();
        if (lbl_tbl_title.getText().startsWith("Tests With No Result") && ind > -1) {
            evt_id = Integer.parseInt(tbl_Result_Exhibition.getValueAt(ind, 0).toString());
            test_ID = Integer.parseInt(tbl_Result_Exhibition.getValueAt(ind, 1).toString());
            resultForm = new TestResult_Form(evt_id, test_ID);
        }
    }//GEN-LAST:event_btn_rec_examination2ActionPerformed

    public void set_Up_Module(boolean login_sign) {

    }

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_msg.setText("");

            }
        }).start();
        lbl_msg.setText(str);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(DC_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(DC_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(DC_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(DC_Module.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>

        // UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        //UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (dc_Module = new DC_Module()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add_specimen;
    private javax.swing.JButton btn_exp_before_list;
    private javax.swing.JButton btn_exp_before_list1;
    private javax.swing.JButton btn_login_out;
    private javax.swing.JButton btn_rec_examination;
    private javax.swing.JButton btn_rec_examination2;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_test_detail;
    private javax.swing.JButton btn_update;
    private javax.swing.JButton btn_view_patients;
    private javax.swing.JButton btn_view_patients1;
    private javax.swing.JButton btn_view_patients2;
    private javax.swing.JButton btn_view_tests;
    private javax.swing.JCheckBox chk_pat_con;
    private javax.swing.JComboBox<String> cmb_test_by_type;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel jpnl_grand;
    private com.toedter.calendar.JSpinnerDateEditor jspn_admitted_on;
    private com.toedter.calendar.JSpinnerDateEditor jspn_delivered_on;
    private javax.swing.JLabel lbl_con_pass;
    private javax.swing.JLabel lbl_msg;
    public javax.swing.JLabel lbl_tbl_title;
    public javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_conf_pass;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextField txt_search;
    private javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables
}
