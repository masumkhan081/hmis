/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pathology;

import static Pathology.DC_Module.*;

import java.sql.DriverManager;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.Font;
import com.itextpdf.text.*;
import static com.itextpdf.text.Annotation.FILE;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.swing.JFrame;

/**
 *
 * @author Masum Khan
 */
public class TestResult_Form extends javax.swing.JFrame {

    static int event_id, test_id;
    static ArrayList<JTextField> txt_result;
    static ArrayList<JLabel> lbl_ref;
    static ArrayList<JLabel> lbl_com;
    static ArrayList<String> components;
    static ArrayList<String> refernce;
    static String test_name, type, pat_name, age, sex, evt_date, del_date;

    /**
     * Creates new form TestResult_Form
     */
    public TestResult_Form(int x, int y) {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setVisible(true);

        event_id = x;
        test_id = y;
        jlist_model = new DefaultListModel();
        list_suggestion.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                System.out.println(jlist_model.size() + "  alternative :  " + list_suggestion.getSelectedIndex());
                if (jlist_model.size() > 0) {
                    int ind = list_suggestion.getSelectedIndex();
                    if (ind != -1) {
                        txt_examinedBy.setText(jlist_model.get(ind).toString());
                    }
                }
            }
        });
        make_UpForm();
        set_Examined_By();
    }

    public static void main(String[] args) {
        TestResult_Form obj = new TestResult_Form(1, 1);
//        JFrame frm = new JFrame();
//        frm.setSize(700,600);
//        frm.setVisible(true);
    }

    public void make_UpForm() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "SELECT * FROM med_tests WHERE test_id = " + test_id;
            rs = st.executeQuery(query);
            while (rs.next()) {
                test_name = rs.getString("name");
                type = rs.getString("type");

                lbl_test_name.setText(test_name);
            }
            refernce = new ArrayList<>();
            components = new ArrayList<>();
            query = "SELECT * FROM test_structure WHERE test_id = " + test_id;
            rs = st.executeQuery(query);
            while (rs.next()) {
                components.add(rs.getString("component_name"));
                refernce.add(rs.getString("reference"));
            }
            query = "SELECT * FROM test_taking WHERE event_id = " + event_id;
            rs = st.executeQuery(query);
            while (rs.next()) {
                id = rs.getInt("pat_id");
                evt_date = rs.getString("event_date");
                lbl_issuedOn.setText("Issued On: " + rs.getString("event_date"));
            }
            query = "SELECT delivery_date FROM test_taking_detail WHERE event_id = " + event_id + " AND test_id = " + test_id;
            rs = st.executeQuery(query);
            while (rs.next()) {
                del_date = rs.getString(1);
                lbl_del_date.setText("Del. Date: " + del_date);
            }
            query = "SELECT * FROM patients WHERE pat_id = " + id;
            rs = st.executeQuery(query);
            while (rs.next()) {
                pat_name = rs.getString("name");
                sex = rs.getString("gender");
                lbl_pat_name.setText(pat_name);
            }
            query = "SELECT user_id FROM accounts WHERE module= 'Pathology'";
            st = con.createStatement();
            temp_st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                id = rs.getInt(1);
                temp_query = "SELECT name FROM system_executives WHERE member_id = " + id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    jlist_model.add(jlist_model.size(), temp_rs.getString("name"));
                }
            }
            list_suggestion.setModel(jlist_model);

        } catch (Exception exp) {
            System.out.println(exp);
        }

    }

    public void set_Examined_By() {
        int i = 0, x, y;
        lbl_com = new ArrayList<>();
        x = 10;
        y = 30;
        System.out.println("size:  " + components.size());
        for (i = 0; i < components.size(); i++) {
            lbl_com.add(new JLabel(components.get(i)));
            lbl_com.get(lbl_com.size() - 1).setSize(200, 24);
            lbl_com.get(lbl_com.size() - 1).setLocation(x, y);
            lbl_com.get(lbl_com.size() - 1).setFont(new Font("Tahoma", Font.BOLD, 14));
            jpnl_form.add(lbl_com.get(lbl_com.size() - 1));
            y += 40;
        }
        x = 202;
        y = 30;
        lbl_ref = new ArrayList<>();
        for (i = 0; i < components.size(); i++) {
            lbl_ref.add(new JLabel(refernce.get(i)));
            lbl_ref.get(lbl_ref.size() - 1).setSize(220, 24);
            lbl_ref.get(lbl_ref.size() - 1).setLocation(x, y);
            lbl_ref.get(lbl_ref.size() - 1).setFont(new Font("Tahoma", Font.BOLD, 14));
            jpnl_form.add(lbl_ref.get(lbl_ref.size() - 1));
            y += 40;
        }
        x = 432;
        y = 30;
        txt_result = new ArrayList<>();
        for (i = 0; i < components.size(); i++) {
            txt_result.add(new JTextField());
            txt_result.get(txt_result.size() - 1).setSize(210, 24);
            txt_result.get(txt_result.size() - 1).setLocation(x, y);
            txt_result.get(txt_result.size() - 1).setFont(new Font("Tahoma", Font.BOLD, 14));
            jpnl_form.add(txt_result.get(txt_result.size() - 1));
            y += 40;
        }
        jpnl_form.setVisible(false);
        jpnl_form.setVisible(true);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_save = new javax.swing.JButton();
        btn_exit = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jpnl_form = new javax.swing.JPanel();
        lbl_test_name = new javax.swing.JLabel();
        lbl_test_name1 = new javax.swing.JLabel();
        lbl_pat_name = new javax.swing.JLabel();
        lbl_test_name3 = new javax.swing.JLabel();
        lbl_issuedOn = new javax.swing.JLabel();
        lbl_del_date = new javax.swing.JLabel();
        lbl_del_date1 = new javax.swing.JLabel();
        txt_examinedBy = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        list_suggestion = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btn_save.setBackground(new java.awt.Color(0, 0, 0));
        btn_save.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        btn_save.setForeground(new java.awt.Color(255, 255, 102));
        btn_save.setText("Save");
        btn_save.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_exit.setBackground(new java.awt.Color(51, 0, 0));
        btn_exit.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 204, 153));
        btn_exit.setText("Close");
        btn_exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpnl_formLayout = new javax.swing.GroupLayout(jpnl_form);
        jpnl_form.setLayout(jpnl_formLayout);
        jpnl_formLayout.setHorizontalGroup(
            jpnl_formLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 711, Short.MAX_VALUE)
        );
        jpnl_formLayout.setVerticalGroup(
            jpnl_formLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 377, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jpnl_form);

        lbl_test_name.setText("jLabel1");

        lbl_test_name1.setText("Patient:");

        lbl_pat_name.setText("jLabel1");

        lbl_test_name3.setText("Test:");

        lbl_issuedOn.setText("jLabel1");

        lbl_del_date.setText("jLabel1");

        lbl_del_date1.setText("Examined By:");

        txt_examinedBy.setMaximumSize(new java.awt.Dimension(225, 25));
        txt_examinedBy.setMinimumSize(new java.awt.Dimension(225, 25));
        txt_examinedBy.setPreferredSize(new java.awt.Dimension(225, 25));

        list_suggestion.setBackground(new java.awt.Color(1, 13, 13));
        list_suggestion.setBorder(new javax.swing.border.MatteBorder(null));
        list_suggestion.setForeground(new java.awt.Color(204, 255, 204));
        list_suggestion.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                list_suggestionValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(list_suggestion);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_test_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_test_name1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_pat_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_issuedOn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl_del_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_test_name3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(2, 2, 2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(lbl_del_date1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_examinedBy, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE))
                        .addGap(4, 4, 4)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(lbl_test_name3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_test_name)
                        .addGap(27, 27, 27)
                        .addComponent(lbl_test_name1)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_pat_name)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_issuedOn)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_del_date)
                        .addGap(24, 24, 24)
                        .addComponent(lbl_del_date1)
                        .addGap(0, 0, 0)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(txt_examinedBy, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        dispose();
    }//GEN-LAST:event_btn_exitActionPerformed
    static void getPath_Save(String path) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            path = path + "\\temp.pdf";

            Rectangle pageSize = new Rectangle(500, 600);
            pageSize.setBackgroundColor(new BaseColor(0xFF, 0xFF, 0xDE));
            Document document = new Document(pageSize);
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
            com.itextpdf.text.Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
            document.open();

//            document.addTitle(test_name);
//            document.add(new Paragraph("ha ha ha "));
//            document.add(Chunk.NEWLINE);
            PdfContentByte cb = writer.getDirectContent();
            cb.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false), 17);
            cb.setColorFill(BaseColor.BLUE);
            cb.setRGBColorFill(120, 255, 300);
            cb.moveTo(500, 500);
            cb.lineTo(10, 500);
//            cb.moveTo(410, 225);
//            cb.lineTo(410, 100);

            cb = writer.getDirectContent();
            cb.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false), 15);
            cb.saveState();

            cb.beginText();
            cb.moveText(30, 570);
            cb.showText("Test: " + test_name + " (" + type + ")  " + ",  Patient: " + pat_name + "  ("
                    + sex + ")  ");
            document.add(new Paragraph("Delivery date: " + del_date + ",  Issued On: " + evt_date));
            document.add(new Paragraph("Patient DOB:" + age));
            document.add(Chunk.NEWLINE);
            document.add(new Paragraph("                   "));
            document.add(Chunk.NEWLINE);
            document.add(new Paragraph("                   "));
            document.add(Chunk.NEWLINE);
            document.add(Chunk.NEWLINE);
            font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLUE);
            String fullstr = "";
            for (int i = 0; i < components.size(); i++) {
                document.add(new Paragraph("Parameter " + (i + 1) + ": " + components.get(i)));

                document.add(new Paragraph("Result: " + txt_result.get(i).getText()));

                document.add(new Paragraph("Reference: " + lbl_ref.get(i).getText()));
                document.add(Chunk.NEWLINE);
                document.add(Chunk.NEWLINE);
            }
            cb.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false), 17);

            cb.moveText(400, 570);

            cb.showText("ABC Pathology Lab");
            document.add(Chunk.NEWLINE);

            cb = writer.getDirectContent();

            cb.moveText(100, 300);

            cb.showText("omega\n\nomega\\omega");

            cb.endText();
            cb.restoreState();

            cb.stroke();
            document.close();

            File pdfFile = new File(path);
            FileInputStream fin = new FileInputStream(pdfFile);

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();
            query = "UPDATE test_taking_detail SET"
                    + " test_result = ? ,"
                    + "status = ? "
                    + " WHERE event_id = " + event_id + " AND test_id =  " + test_id;
            pst = con.prepareStatement(query);
            pst.setBinaryStream(1, (InputStream) fin, (int) (pdfFile.length()));
            pst.setString(2, "Ready");
            pst.executeUpdate();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:

        File_Chooser ch = new File_Chooser();
//        String file = "c:/temp/FirstPdf.pdf";
//        com.itextpdf.text.Font catFont, redFont, subFont, smallBold;
//        catFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12,
//                com.itextpdf.text.Font.NORMAL, BaseColor.RED);
//
//        redFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12,
//                com.itextpdf.text.Font.NORMAL, BaseColor.RED);
//
//        subFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 16,
//                com.itextpdf.text.Font.BOLD);
//        smallBold = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12,
//                com.itextpdf.text.Font.BOLD);
//
//        try {
//            Document document = new Document();
//            PdfWriter.getInstance(document, new FileOutputStream(FILE));
//            document.open();
//            document.addAuthor("shvbdsvdvkds  sdvhsdbhvbsd   dsvj");
//            document.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        for (int i = 0;
//                i < components.size();
//                i++) {
//
//        }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void list_suggestionValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_list_suggestionValueChanged
        // TODO add your handling code here:
        if (list_suggestion.getSelectedIndex() > -1) {

        }
    }//GEN-LAST:event_list_suggestionValueChanged

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(TestResult_Form.class
//                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
//
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(TestResult_Form.class
//                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
//
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(TestResult_Form.class
//                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
//
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(TestResult_Form.class
//                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_save;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel jpnl_form;
    private javax.swing.JLabel lbl_del_date;
    private javax.swing.JLabel lbl_del_date1;
    private javax.swing.JLabel lbl_issuedOn;
    private javax.swing.JLabel lbl_pat_name;
    private javax.swing.JLabel lbl_test_name;
    private javax.swing.JLabel lbl_test_name1;
    private javax.swing.JLabel lbl_test_name3;
    public javax.swing.JList<String> list_suggestion;
    private javax.swing.JTextField txt_examinedBy;
    // End of variables declaration//GEN-END:variables
}
