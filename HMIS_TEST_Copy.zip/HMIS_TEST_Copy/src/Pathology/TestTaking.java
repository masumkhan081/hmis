/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pathology;

import IPCU.In_Patient_Care_Unit;
import static Pathology.DC_Module.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Masum Khan
 */
public class TestTaking extends javax.swing.JPanel {

    /**
     * Creates new form TestTaking
     */
    public int adj_Charge;
    public int run;

    public TestTaking() {
        initComponents();
        setSize(405, 473);
        setLocation(10, 10);
        setVisible(true);
        jspn_del_date.setEditor(new JSpinner.DateEditor(jspn_del_date, "dd/MM/yy"));
        jspn_del_date.setDate(new Date());
        tests_Taken = new ArrayList<>();
        grand_tot = 0;
        jspnr_disc.setEnabled(false);
        txt_disc.setEnabled(false);

        ((DefaultEditor) jspnr_disc.getEditor()).getTextField().setEditable(false);

        date_Format = new SimpleDateFormat("dd/MM/yy");
        jlist_model = new DefaultListModel();
        tests_Taken = new ArrayList<>();

        DocumentListener documentListener = new DocumentListener() {
            public void changedUpdate(DocumentEvent documentEvent) {
                adjustCash_Discount();
            }

            public void insertUpdate(DocumentEvent documentEvent) {
                adjustCash_Discount();
            }

            public void removeUpdate(DocumentEvent documentEvent) {
                adjustCash_Discount();
            }
        };
        txt_disc.getDocument().addDocumentListener(documentListener);

        list_suggestion.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                System.out.println(jlist_model.size() + "  alternative :  " + list_suggestion.getSelectedIndex());
                if (jlist_model.size() > 0) {
                    int ind = list_suggestion.getSelectedIndex();
                    if (ind != -1) {
                        retrieve_Test(ind);
                    }
                }
            }
        });

    }

    public void retrieve_Test(int ind) {

        System.out.println("am i foul? " + ind);
        taken_test_id = Integer.parseInt(tests_Taken.get(ind)[0]);
        taken_test_name = tests_Taken.get(ind)[1];
        taken_test_type = tests_Taken.get(ind)[2];
        taken_test_method = tests_Taken.get(ind)[3];
        adj_Charge = Integer.parseInt(tests_Taken.get(ind)[4]);
        taken_test_charge = Integer.parseInt(tests_Taken.get(ind)[6]);
        del_date = tests_Taken.get(ind)[5];
        lbl_method.setText("Method: " + taken_test_method);
        lbl_test_Name.setText("test name: " + taken_test_name);
        lbl_charge.setText("Test Charge:" + taken_test_charge + "");
        lbl_disc.setText("adjusted:" + adj_Charge);
        lbl_type.setText("" + taken_test_type);
        try {
            jspn_del_date.setDate(date_Format.parse(del_date));
        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    public void adjustCash_Discount() {

        int disc;
        try {
            discount = Integer.parseInt(txt_disc.getText());
            adj_Charge = taken_test_charge - discount;
            lbl_withDisc.setText("Adjusted:" + (adj_Charge));
        } catch (NumberFormatException pe) {
            status_In_Time("Invalid cash discount", 2200);
        }

    }

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (i == 2202) {
                    lbl_contact.setText(".");
                }
                if (i == 2205) {
                    lbl_test_Name.setText(".");
                }
                if (i == 2200) {
                    lbl_withDisc.setText("");
                }

            }
        }).start();
        if (i == 2202) {
            lbl_contact.setText(str);
        }
        if (i == 2205) {
            lbl_test_Name.setText(str);
        }
        if (i == 2200) {
            lbl_withDisc.setText(str);
        }
    }

    public void clear() {
        lbl_charge.setText("");
        lbl_test_Name.setText("");
        lbl_type.setText("");
        lbl_method.setText("");
        buttonGroup1.clearSelection();
        jspnr_disc.setValue(0);
    }

    public static void main(String args[]) {
        jfr = new JFrame();
        jfr.setSize(415, 480);
        jfr.setLocationRelativeTo(null);
        jfr.add((test_taking = new TestTaking()));
        test_taking.setLocation(10, 10);
        jfr.setUndecorated(true);
        jfr.setDefaultCloseOperation(0);
        jfr.setVisible(true);
        taken_test_charge = 1200;
    }

    /**
     * This taken_test_method is called from within the constructor to
     * initialize the form. WARNING: Do NOT modify this code. The content of
     * this taken_test_method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        lbl_date1 = new javax.swing.JLabel();
        jspn_del_date = new com.toedter.calendar.JSpinnerDateEditor();
        lbl_grand_tot = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btn_exclude = new javax.swing.JButton();
        btn_done = new javax.swing.JButton();
        btn_detail = new javax.swing.JButton();
        lbl_test_Name = new javax.swing.JLabel();
        lbl_type = new javax.swing.JLabel();
        lbl_method = new javax.swing.JLabel();
        lbl_charge = new javax.swing.JLabel();
        btn_complete = new javax.swing.JButton();
        cmb_actions = new javax.swing.JComboBox<>();
        lbl_disc = new javax.swing.JLabel();
        rbtn_perc = new javax.swing.JRadioButton();
        rbtn_cash = new javax.swing.JRadioButton();
        jspnr_disc = new javax.swing.JSpinner();
        lbl_withDisc = new javax.swing.JLabel();
        txt_disc = new javax.swing.JTextField();
        btn_select_pat = new javax.swing.JButton();
        btn_select_test = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        list_suggestion = new javax.swing.JList<>();
        btn_exit = new javax.swing.JButton();
        lbl_name = new javax.swing.JLabel();
        lbl_contact = new javax.swing.JLabel();
        lbl_list_title = new javax.swing.JLabel();
        btn_ADD = new javax.swing.JButton();

        setBackground(new java.awt.Color(204, 255, 204));
        setMaximumSize(new java.awt.Dimension(405, 473));
        setMinimumSize(new java.awt.Dimension(405, 473));

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        lbl_date1.setBackground(new java.awt.Color(204, 204, 255));
        lbl_date1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_date1.setText("Delivery  Date:");

        jspn_del_date.setBackground(new java.awt.Color(15, 38, 38));
        jspn_del_date.setBorder(null);
        jspn_del_date.setForeground(new java.awt.Color(255, 204, 102));
        jspn_del_date.setModel(new javax.swing.SpinnerDateModel());
        jspn_del_date.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        lbl_grand_tot.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_grand_tot.setBorder(javax.swing.BorderFactory.createTitledBorder("grand total"));
        lbl_grand_tot.setMaximumSize(new java.awt.Dimension(155, 22));
        lbl_grand_tot.setMinimumSize(new java.awt.Dimension(155, 22));
        lbl_grand_tot.setPreferredSize(new java.awt.Dimension(155, 22));

        jPanel6.setBackground(new java.awt.Color(0, 51, 51));
        jPanel6.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel6.setMinimumSize(new java.awt.Dimension(405, 0));

        btn_exclude.setBackground(new java.awt.Color(0, 0, 0));
        btn_exclude.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exclude.setForeground(new java.awt.Color(204, 255, 153));
        btn_exclude.setText("Exclude This One");
        btn_exclude.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exclude.setContentAreaFilled(false);
        btn_exclude.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_excludeActionPerformed(evt);
            }
        });

        btn_done.setBackground(new java.awt.Color(0, 0, 0));
        btn_done.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_done.setForeground(new java.awt.Color(204, 255, 153));
        btn_done.setText("Done");
        btn_done.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_done.setContentAreaFilled(false);
        btn_done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_doneActionPerformed(evt);
            }
        });

        btn_detail.setBackground(new java.awt.Color(0, 0, 0));
        btn_detail.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_detail.setForeground(new java.awt.Color(204, 255, 153));
        btn_detail.setText("Detail");
        btn_detail.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_detail.setContentAreaFilled(false);
        btn_detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_detailActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_exclude)
                .addGap(104, 104, 104)
                .addComponent(btn_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_exclude, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        lbl_test_Name.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_test_Name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_test_Name.setText("!");

        lbl_type.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_type.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_type.setText("!");

        lbl_method.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_method.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_method.setText("!");

        lbl_charge.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_charge.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_charge.setText("!");

        btn_complete.setBackground(new java.awt.Color(0, 0, 0));
        btn_complete.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btn_complete.setForeground(new java.awt.Color(255, 204, 102));
        btn_complete.setText("Complete");
        btn_complete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_complete.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btn_complete.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        btn_complete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_completeActionPerformed(evt);
            }
        });

        cmb_actions.setBackground(new java.awt.Color(12, 23, 23));
        cmb_actions.setForeground(new java.awt.Color(255, 204, 102));
        cmb_actions.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Order via email", "Just Save", "Order To Be", "Print Order" }));
        cmb_actions.setSelectedIndex(-1);
        cmb_actions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_actionsActionPerformed(evt);
            }
        });

        lbl_disc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_disc.setText("Discount:");

        rbtn_perc.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_perc.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        rbtn_perc.setText("%");
        rbtn_perc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rbtn_perc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_percActionPerformed(evt);
            }
        });

        rbtn_cash.setBackground(new java.awt.Color(204, 255, 204));
        rbtn_cash.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        rbtn_cash.setText("/= ");
        rbtn_cash.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rbtn_cash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_cashActionPerformed(evt);
            }
        });

        jspnr_disc.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 17)); // NOI18N
        jspnr_disc.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));
        jspnr_disc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspnr_disc.setMaximumSize(new java.awt.Dimension(78, 24));
        jspnr_disc.setMinimumSize(new java.awt.Dimension(78, 24));
        jspnr_disc.setPreferredSize(new java.awt.Dimension(78, 24));
        jspnr_disc.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jspnr_discStateChanged(evt);
            }
        });
        jspnr_disc.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jspnr_discPropertyChange(evt);
            }
        });

        lbl_withDisc.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lbl_withDisc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_withDisc.setText("!");
        lbl_withDisc.setMaximumSize(new java.awt.Dimension(80, 19));
        lbl_withDisc.setMinimumSize(new java.awt.Dimension(80, 19));
        lbl_withDisc.setPreferredSize(new java.awt.Dimension(80, 19));

        txt_disc.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                txt_discPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cmb_actions, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_complete, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_grand_tot, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_date1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jspn_del_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(lbl_withDisc, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_disc)
                                .addGap(6, 6, 6)
                                .addComponent(rbtn_perc)
                                .addGap(0, 0, 0)
                                .addComponent(jspnr_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbtn_cash)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbl_test_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_charge, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_method, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_type, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(lbl_test_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_type, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_method, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_charge, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_withDisc, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_del_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_disc, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbtn_perc, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbtn_cash, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jspnr_disc, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(lbl_grand_tot, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(cmb_actions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_complete))
                .addGap(13, 13, 13))
        );

        btn_select_pat.setBackground(new java.awt.Color(0, 0, 0));
        btn_select_pat.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btn_select_pat.setForeground(new java.awt.Color(255, 204, 204));
        btn_select_pat.setText("Get Selected Patient");
        btn_select_pat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_select_pat.setBorderPainted(false);
        btn_select_pat.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_select_pat.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_select_pat.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_select_pat.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_select_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_select_patActionPerformed(evt);
            }
        });

        btn_select_test.setBackground(new java.awt.Color(0, 0, 0));
        btn_select_test.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btn_select_test.setForeground(new java.awt.Color(255, 204, 204));
        btn_select_test.setText("Get Selected Test");
        btn_select_test.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_select_test.setBorderPainted(false);
        btn_select_test.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_select_test.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_select_test.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_select_test.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_select_test.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_select_testActionPerformed(evt);
            }
        });

        list_suggestion.setBackground(new java.awt.Color(1, 13, 13));
        list_suggestion.setBorder(new javax.swing.border.MatteBorder(null));
        list_suggestion.setForeground(new java.awt.Color(204, 255, 204));
        list_suggestion.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                list_suggestionValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(list_suggestion);

        btn_exit.setBackground(new java.awt.Color(0, 0, 0));
        btn_exit.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 204, 153));
        btn_exit.setText("Exit");
        btn_exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        lbl_name.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 13)); // NOI18N
        lbl_name.setText(".");

        lbl_contact.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 13)); // NOI18N
        lbl_contact.setText(".");

        lbl_list_title.setFont(new java.awt.Font("Frank Ruhl Hofshi", 1, 13)); // NOI18N
        lbl_list_title.setText("Enlisted Tests Yet:");

        btn_ADD.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btn_ADD.setText("+");
        btn_ADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ADDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_name, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_list_title, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(btn_exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_select_test, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_select_pat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_ADD, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_list_title))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btn_ADD, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbl_name, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(lbl_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btn_select_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_select_test, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(6, 6, 6))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_select_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_select_patActionPerformed
        // TODO add your handling code here:

        int row = dc_Module.tbl_Result_Exhibition.getSelectedRow();
        if (row > -1 && dc_Module.lbl_tbl_title.getText().contains("Patients")) {
            test_taking_pat_id = ids.get(row);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
                st = con.createStatement();
                query = "SELECT * FROM patients WHERE  pat_id= " + test_taking_pat_id + "";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    lbl_name.setText(rs.getString("name"));
                    lbl_contact.setText(rs.getString("contact") + "," + rs.getString("address"));
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
            pat_selection = true;
            dc_Module.tbl_Result_Exhibition.clearSelection();
            btn_select_pat.setEnabled(false);
        } else {
            dc_Module.view_Patients("SELECT * FROM  patients", "Patients (All)");
        }
    }//GEN-LAST:event_btn_select_patActionPerformed

    private void btn_select_testActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_select_testActionPerformed
        // TODO add your handling code here:
        int row = dc_Module.tbl_Result_Exhibition.getSelectedRow();
        if (row > -1 && dc_Module.lbl_tbl_title.getText().contains("Medical Tests")) {
            taken_test_id = ids.get(row);
            System.out.println(row + "  taken test id: " + taken_test_id);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
                st = con.createStatement();
                query = "SELECT * FROM med_tests WHERE  test_id= " + taken_test_id + "";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    taken_test_name = rs.getString("name");
                    taken_test_charge = rs.getInt("charge");
                    taken_test_method = rs.getString("testing_method");
                    taken_test_type = rs.getString("type");
                    lbl_test_Name.setText(" Name: " + taken_test_name);
                    lbl_type.setText(" Type:" + taken_test_type);
                    lbl_method.setText(" Specimen: " + taken_test_method);
                    lbl_charge.setText(" Charge: " + taken_test_charge);
                    adj_Charge = taken_test_charge;
                    run = 1;
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
            test_selection = true;
            dc_Module.tbl_Result_Exhibition.clearSelection();
        } else {
            dc_Module.view_Tests("SELECT * FROM med_tests", "Medical Tests (All)");
        }
    }//GEN-LAST:event_btn_select_testActionPerformed

    private void btn_excludeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_excludeActionPerformed
        // TODO add your handling code here:

        for (int i = 0; i < tests_Taken.size(); i++) {
            System.out.println(tests_Taken.get(i)[1] + "()  : " + tests_Taken.get(i)[1]);
        }
        if (jlist_model.size() > 0) {
            int ind = list_suggestion.getSelectedIndex();
            if (ind != -1) {
                tests_Taken.remove(ind);
                jlist_model.remove(ind);
            }
        }
        for (int i = 0; i < tests_Taken.size(); i++) {
            System.out.println(tests_Taken.get(i)[1] + "()  : " + tests_Taken.get(i)[1]);
        }

//        if (running <= done) {
//            purchase_order.remove(running - 1);
//            if (running == done) {
//                running -= 1;
//                done -= 1;
//                lbl_counter.setText("new/" + done);
//            }
//            if (running < done) {
//                done -= 1;
//                if (running == done) {
//                    running = done;
//                } else {
//                    running = running;
//                }
//                lbl_counter.setText(running + "/" + done);
//            }
//            clear();
//        }
    }//GEN-LAST:event_btn_excludeActionPerformed
    public void set_BY_count_running() {
//        System.out.println("setByrunning;  done: " + done + "  run: " + running);
//        lbl_method.setText(tests_Taken.get(running - 1)[3]);
//        lbl_name.setText(tests_Taken.get(running - 1)[1]);
//        lbl_type.setText(tests_Taken.get(running - 1)[2]);
//        lbl_charge.setText(tests_Taken.get(running - 1)[4]);
//        try {
//            jspn_del_date.setDate(date_Format.parse(tests_Taken.get(running - 1)[5]));
//        } catch (Exception ex) {
//            System.out.println(ex);
//        }
    }
    private void btn_doneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_doneActionPerformed
        // TODO add your handling code here:
        sign = false;

        if (pat_selection == false) {
            status_In_Time("Select Patient !", 2202);
            sign = true;
        }
        if (test_selection == false) {
            status_In_Time("Select Test !", 2205);
            sign = true;
        }

//        if (jspn_del_date.getDate().before(new Date())) {
//            status_In_Time("Invalid delivery Date ! ", 2207);
//            sign = true;
//        }
//        if (rbtn_cash.isSelected()) {
//            discount = (int) jspnr_disc.getValue();
//        }
//        if (rbtn_perc.isSelected()) {
//            discount = ((int) jspnr_disc.getValue() / 100) * taken_test_charge;
//        }
//        taken_test_charge = taken_test_charge - discount;
        if (sign == false) {
            del_date = date_Format.format(jspn_del_date.getDate());
            grand_tot += adj_Charge;
            lbl_grand_tot.setText("" + grand_tot);
            str = new String[7];
            str[0] = String.valueOf(taken_test_id);
            str[1] = String.valueOf(taken_test_name);
            str[2] = String.valueOf(taken_test_type);
            str[3] = String.valueOf(taken_test_method);
            str[4] = String.valueOf(adj_Charge);
            str[5] = del_date;
            str[6] = String.valueOf(taken_test_charge);
            tests_Taken.add(str);
            System.out.println("running: " + jlist_model.size());
            jlist_model.add(jlist_model.size(), taken_test_name + ", " + taken_test_method + " >> " + del_date);
            list_suggestion.setModel(jlist_model);
            test_selection = false;
            btn_ADDActionPerformed(evt);
            btn_select_test.setEnabled(false);
        }

    }//GEN-LAST:event_btn_doneActionPerformed

    private void list_suggestionValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_list_suggestionValueChanged
        // TODO add your handling code here:
        if (list_suggestion.getSelectedIndex() > -1) {

        }
    }//GEN-LAST:event_list_suggestionValueChanged

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        // TODO add your handling code here:
        //  System.exit(0);
        dc_Module.clear_Grand_Pnl();
    }//GEN-LAST:event_btn_exitActionPerformed
    public void save_TestTaking() {

        evt_id = 1;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_UserName, db_UserPass);
            st = con.createStatement();

            query = "SELECT event_id  FROM  test_taking ORDER BY event_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                evt_id = rs.getInt(1) + 1;
            }
            System.out.println("new evt id: " + evt_id);
            pst = con.prepareStatement("insert into test_taking values(?,?,?)");
            pst.setInt(1, evt_id);
            pst.setInt(2, test_taking_pat_id);
            pst.setString(3, date_Format.format(new Date()));

            pst.executeUpdate();

            pst = con.prepareStatement("insert into test_taking_detail values(?,?,?,?,?,?,?,?,?)");
            for (int i = 0; i < tests_Taken.size(); i++) {
                pst.setInt(1, evt_id);
                pst.setInt(2, Integer.parseInt(tests_Taken.get(i)[0]));
                pst.setString(3, "");
                pst.setString(4, "Not Collected");
                pst.setString(5, tests_Taken.get(i)[5]);
                pst.setInt(6, -1);
                pst.setBinaryStream(7, is);
                pst.setString(8, "Not Ready");
                pst.setInt(9, Integer.parseInt(tests_Taken.get(i)[4]));
                pst.executeUpdate();
            }
            jlist_model.clear();

        } catch (Exception exp) {
            System.out.println(exp);
        }

    }
    private void btn_completeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_completeActionPerformed
        // TODO add your handling code here:

        save_TestTaking();


    }//GEN-LAST:event_btn_completeActionPerformed

    private void cmb_actionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_actionsActionPerformed
        // TODO add your handling code here: 
    }//GEN-LAST:event_cmb_actionsActionPerformed

    private void btn_detailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_detailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_detailActionPerformed

    private void jspnr_discStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jspnr_discStateChanged
        // TODO add your handling code here:
        System.out.println("ttc: " + taken_test_charge);
        discount = (((int) jspnr_disc.getValue()) * taken_test_charge) / 100;
        System.out.println("StateChanged " + discount);
        adj_Charge = taken_test_charge - discount;
        lbl_withDisc.setText("Adjusted:" + (adj_Charge));
    }//GEN-LAST:event_jspnr_discStateChanged

    private void jspnr_discPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jspnr_discPropertyChange
        // TODO add your handling code here:

    }//GEN-LAST:event_jspnr_discPropertyChange

    private void rbtn_percActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_percActionPerformed
        // TODO add your handling code here:
        if (rbtn_perc.isSelected()) {
            jspnr_disc.setEnabled(true);
            rbtn_cash.setSelected(false);
            txt_disc.setEnabled(false);
            txt_disc.setText("");
        } else {
            jspnr_disc.setEnabled(false);
        }

    }//GEN-LAST:event_rbtn_percActionPerformed

    private void rbtn_cashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_cashActionPerformed
        // TODO add your handling code here:
        if (rbtn_cash.isSelected()) {
            txt_disc.setEnabled(true);
            rbtn_perc.setSelected(false);
            jspnr_disc.setEnabled(false);
            jspnr_disc.setValue(0);
        } else {
            txt_disc.setEnabled(false);
        }

    }//GEN-LAST:event_rbtn_cashActionPerformed

    private void txt_discPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_txt_discPropertyChange
        // TODO add your handling code here:

    }//GEN-LAST:event_txt_discPropertyChange

    private void btn_ADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ADDActionPerformed
        // TODO add your handling code here:
        lbl_charge.setText("");
        lbl_method.setText("");
        lbl_test_Name.setText("");
        lbl_type.setText("");
        jspnr_disc.setValue(0);
        lbl_disc.setText("");
        jspn_del_date.setDate(new Date());
        rbtn_cash.setSelected(false);
        rbtn_perc.setSelected(false);
        btn_select_test.setEnabled(true);

    }//GEN-LAST:event_btn_ADDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_ADD;
    public javax.swing.JButton btn_complete;
    public javax.swing.JButton btn_detail;
    public javax.swing.JButton btn_done;
    public javax.swing.JButton btn_exclude;
    public javax.swing.JButton btn_exit;
    public javax.swing.JButton btn_select_pat;
    public javax.swing.JButton btn_select_test;
    private javax.swing.ButtonGroup buttonGroup1;
    public javax.swing.JComboBox<String> cmb_actions;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    public com.toedter.calendar.JSpinnerDateEditor jspn_del_date;
    public javax.swing.JSpinner jspnr_disc;
    private javax.swing.JLabel lbl_charge;
    public javax.swing.JLabel lbl_contact;
    public javax.swing.JLabel lbl_date1;
    public javax.swing.JLabel lbl_disc;
    public javax.swing.JLabel lbl_grand_tot;
    public javax.swing.JLabel lbl_list_title;
    public javax.swing.JLabel lbl_method;
    public javax.swing.JLabel lbl_name;
    public javax.swing.JLabel lbl_test_Name;
    public javax.swing.JLabel lbl_type;
    private javax.swing.JLabel lbl_withDisc;
    public javax.swing.JList<String> list_suggestion;
    public javax.swing.JRadioButton rbtn_cash;
    public javax.swing.JRadioButton rbtn_perc;
    private javax.swing.JTextField txt_disc;
    // End of variables declaration//GEN-END:variables

}
