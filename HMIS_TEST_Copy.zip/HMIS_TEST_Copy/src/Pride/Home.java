/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pride;

import static Pride.PMS_Launcher.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.sql.DriverManager;
import java.util.ArrayList;
import javafx.stage.WindowEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pddrgj3q
 */
public class Home extends javax.swing.JFrame {

    /**
     * Creates new form Home
     */
    int pX, pY;

    public Home() {
        initComponents();

        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        //   setResizable(false);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        //  set_Table_Action();
        set_Initial_State();
        set_Movable();
        get_Companies_Generic();
        view_Drugs("", "all");
    }

//    public void set_Table_Action() {
//
//        tbl_Result_Exhibition.addMouseListener(new java.awt.event.MouseAdapter() {
//            public void mouseClicked(java.awt.event.MouseEvent e) {
//                int col = tbl_Result_Exhibition.columnAtPoint(e.getPoint());
//                int row = tbl_Result_Exhibition.rowAtPoint(e.getPoint());
//                System.out.println("row: " + row + " col: " + col);
//                if (lbl_tble_title.getText().equals("Depositors") && (col == 5) && row > -1) {
//                    lbl_process_title.setText("Purchase Order For: " + tbl_Result_Exhibition.getValueAt(row, 0).toString() + ", " + tbl_Result_Exhibition.getValueAt(row, 2).toString());
//                    com_name = tbl_Result_Exhibition.getValueAt(row, 2).toString();
//                    //   System.out.println("id: " + ids.get(row));
//                    dep_id = ids.get(row);
//                    issue_Order();
//
//                }
//                if (lbl_tble_title.getText().equals("Companies") && (col == 2) && row > -1) {
//                    com_name = tbl_Result_Exhibition.getValueAt(row, 0).toString();
//                    lbl_process_title.setText("Purchase Order To: " + com_name);
//                    issue_Order();
//
//                }
//            }
//        }
//        );
//    }
    public void get_Companies_Generic() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            query = "SELECT DISTINCT company from drug_stock ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_drug_by_com.setModel(cmb_model);
            sugg.clear();
            query = "SELECT  DISTINCT generic from drug_stock ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
                cmb_model = new DefaultComboBoxModel(sugg.toArray());
                cmb_drug_by_gen.setModel(cmb_model);
            }
        } catch (Exception exp) {
            System.out.println("exception in get coms.. " + exp);
        }
    }

    public void set_Movable() {

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
    }

    public void set_Initial_State() {

        txt_conf_pass.setVisible(false);
        btn_update.setVisible(false);

        lbl_con_pass.setVisible(false);
        //  btn_show_hide1.setVisible(false);

    }

    public void follow_Type(String type) {
        if (type.equals("Admin")) {
            set_For_Admin();
        }
        if (type.equals("Pharmacist")) {
            set_For_Pharmacist();
        }
        if (type.equals("Salesman")) {
            set_For_Salesman();
        }
        if (type.equals("Manager")) {
            set_For_Manager();
        }
        btn_login_out.setText("Log Out");
    }

    public void drug_ByCompany(String name) {

        ids.clear();
        String[] coloumn = new String[5];
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Company";
        coloumn[3] = "Last Delivery";
        coloumn[4] = "Due Left";
        //  coloumn[5] = "Action";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("com_name");
            }
        } catch (Exception exp) {
            System.out.println("From by com " + exp);
        }

    }

    public void set_For_Admin() {

//        btn_create_new.setVisible(true);
//        System.out.println("found admin");
    }

    public void set_For_Salesman() {

    }

    public void set_For_Manager() {

    }

    public void set_For_Pharmacist() {

    }

    public void clear_Grand_Pnl() {
        lbl_process_title.setText("");
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_warning.setText("");
                if (i == 2202) {
                    lbl_mrp_warn.setText("");
                }

            }
        }).start();
        if (i == 2202) {
            lbl_mrp_warn.setText(str);
        } else {
            lbl_warning.setText(str);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_cancel_all = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        txt_u_name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        lbl_con_pass = new javax.swing.JLabel();
        txt_pass = new javax.swing.JTextField();
        txt_conf_pass = new javax.swing.JTextField();
        btn_login_out = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        lbl_warning = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        cmb_drug_by_com1 = new javax.swing.JComboBox<>();
        txt_search_content = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btn_new_drug = new javax.swing.JButton();
        btn_new_drug2 = new javax.swing.JButton();
        btn_new_acc = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btn_exit = new javax.swing.JButton();
        btn_min = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        jpnl_grand = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        lbl_reg_act = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_view_drug = new javax.swing.JButton();
        btn_view_dep = new javax.swing.JButton();
        btn_view_companies = new javax.swing.JButton();
        btn_new_drug6 = new javax.swing.JButton();
        btn_new_drug8 = new javax.swing.JButton();
        btn_new_drug9 = new javax.swing.JButton();
        btn_new_drug10 = new javax.swing.JButton();
        btn_HangingOrders = new javax.swing.JButton();
        btn_purchase = new javax.swing.JButton();
        btn_issue_order = new javax.swing.JButton();
        btn_new_drug12 = new javax.swing.JButton();
        btn_go_details = new javax.swing.JButton();
        btn_remove = new javax.swing.JButton();
        btn_view_drug1 = new javax.swing.JButton();
        btn_new_drug11 = new javax.swing.JButton();
        btn_HangingOrders1 = new javax.swing.JButton();
        txt_mrp = new javax.swing.JTextField();
        lbl_mrp_warn = new javax.swing.JLabel();
        lbl_tble_title = new javax.swing.JLabel();
        cmb_drug_by_com = new javax.swing.JComboBox<>();
        cmb_drug_by_gen = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lbl_process_title = new javax.swing.JLabel();

        btn_cancel_all.setBackground(new java.awt.Color(0, 0, 0));
        btn_cancel_all.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        btn_cancel_all.setForeground(new java.awt.Color(255, 204, 204));
        btn_cancel_all.setText("Cancel All");
        btn_cancel_all.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancel_all.setBorderPainted(false);
        btn_cancel_all.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_cancel_all.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_cancel_all.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_cancel_all.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_cancel_all.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancel_allActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(36, 45, 45));

        jPanel2.setBackground(new java.awt.Color(1, 13, 13));
        jPanel2.setMaximumSize(new java.awt.Dimension(1366, 174));
        jPanel2.setMinimumSize(new java.awt.Dimension(1366, 174));
        jPanel2.setPreferredSize(new java.awt.Dimension(1366, 174));

        jPanel3.setBackground(new java.awt.Color(0, 51, 51));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 3, true));
        jPanel3.setMaximumSize(new java.awt.Dimension(1365, 174));
        jPanel3.setMinimumSize(new java.awt.Dimension(1365, 174));
        jPanel3.setPreferredSize(new java.awt.Dimension(1365, 174));

        jPanel5.setBackground(new java.awt.Color(10, 27, 27));

        txt_u_name.setBackground(new java.awt.Color(204, 204, 255));
        txt_u_name.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(204, 204, 255));
        jLabel5.setText("Pass:");

        lbl_con_pass.setForeground(new java.awt.Color(204, 204, 255));
        lbl_con_pass.setText("confirm:");

        txt_pass.setBackground(new java.awt.Color(204, 204, 255));
        txt_pass.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        txt_conf_pass.setBackground(new java.awt.Color(204, 204, 255));
        txt_conf_pass.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btn_login_out.setBackground(new java.awt.Color(204, 204, 255));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_login_out.setText("In");
        btn_login_out.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(204, 204, 255));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_update.setText("Edit");
        btn_update.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lbl_warning.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_u_name)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btn_login_out, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_con_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_update)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txt_conf_pass)
                            .addComponent(txt_pass))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_con_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(10, 27, 27));
        jPanel6.setMaximumSize(new java.awt.Dimension(1092, 152));
        jPanel6.setMinimumSize(new java.awt.Dimension(1092, 152));
        jPanel6.setPreferredSize(new java.awt.Dimension(1092, 152));

        cmb_drug_by_com1.setBackground(new java.awt.Color(1, 23, 23));
        cmb_drug_by_com1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_drug_by_com1.setForeground(new java.awt.Color(204, 204, 255));
        cmb_drug_by_com1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmb_drug_by_com1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_by_com1ActionPerformed(evt);
            }
        });

        txt_search_content.setBackground(new java.awt.Color(1, 23, 23));
        txt_search_content.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_search_content.setForeground(new java.awt.Color(204, 204, 255));
        txt_search_content.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txt_search_content.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_contentActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(1, 23, 23));
        btn_search.setFont(new java.awt.Font("Malgun Gothic", 1, 12)); // NOI18N
        btn_search.setForeground(new java.awt.Color(204, 204, 255));
        btn_search.setText("Search");
        btn_search.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        jPanel9.setBackground(new java.awt.Color(0, 0, 0));
        jPanel9.setForeground(new java.awt.Color(255, 204, 153));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 204, 102));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Introduce To System");
        jLabel6.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 2, 0, new java.awt.Color(102, 51, 0)));

        btn_new_drug.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug.setForeground(new java.awt.Color(204, 255, 204));
        btn_new_drug.setText("New Drug");
        btn_new_drug.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_drug.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drugActionPerformed(evt);
            }
        });

        btn_new_drug2.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug2.setForeground(new java.awt.Color(204, 255, 204));
        btn_new_drug2.setText("New Depositor");
        btn_new_drug2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_drug2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug2.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug2.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug2.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug2ActionPerformed(evt);
            }
        });

        btn_new_acc.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_acc.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_acc.setForeground(new java.awt.Color(204, 255, 204));
        btn_new_acc.setText("New User");
        btn_new_acc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_acc.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_acc.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_acc.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_acc.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_accActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_new_drug, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_drug2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_acc, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_drug2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btn_new_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btn_new_drug, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(cmb_drug_by_com1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(493, 493, 493)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_drug_by_com1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(0, 102, 102)));
        jPanel4.setForeground(new java.awt.Color(255, 255, 204));

        btn_exit.setBackground(new java.awt.Color(0, 0, 0));
        btn_exit.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 204, 153));
        btn_exit.setText("Exit");
        btn_exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        btn_min.setBackground(new java.awt.Color(0, 0, 0));
        btn_min.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_min.setForeground(new java.awt.Color(255, 204, 153));
        btn_min.setText("min");
        btn_min.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_min.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_minActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_min, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_min, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 1152, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        jPanel7.setBackground(new java.awt.Color(10, 27, 27));
        jPanel7.setMaximumSize(new java.awt.Dimension(1384, 572));
        jPanel7.setMinimumSize(new java.awt.Dimension(1384, 572));
        jPanel7.setPreferredSize(new java.awt.Dimension(1384, 572));

        tbl_Result_Exhibition.setBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(204, 255, 204));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 102, 102));
        tbl_Result_Exhibition.setMaximumSize(new java.awt.Dimension(390, 538));
        tbl_Result_Exhibition.setMinimumSize(new java.awt.Dimension(390, 538));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setPreferredSize(new java.awt.Dimension(390, 538));
        tbl_Result_Exhibition.setRowHeight(23);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(204, 204, 255));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setShowVerticalLines(false);
        jScrollPane1.setViewportView(tbl_Result_Exhibition);

        jpnl_grand.setBackground(new java.awt.Color(10, 27, 27));
        jpnl_grand.setMaximumSize(new java.awt.Dimension(420, 535));
        jpnl_grand.setMinimumSize(new java.awt.Dimension(420, 535));
        jpnl_grand.setPreferredSize(new java.awt.Dimension(420, 535));

        javax.swing.GroupLayout jpnl_grandLayout = new javax.swing.GroupLayout(jpnl_grand);
        jpnl_grand.setLayout(jpnl_grandLayout);
        jpnl_grandLayout.setHorizontalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jpnl_grandLayout.setVerticalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(14, 26, 26));
        jPanel8.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 0, 1, new java.awt.Color(0, 102, 102)));
        jPanel8.setMaximumSize(new java.awt.Dimension(156, 568));
        jPanel8.setMinimumSize(new java.awt.Dimension(156, 568));

        lbl_reg_act.setBackground(new java.awt.Color(204, 255, 204));
        lbl_reg_act.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lbl_reg_act.setForeground(new java.awt.Color(255, 204, 102));
        lbl_reg_act.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_reg_act.setText("Regular Action");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 204, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Normal View");

        btn_view_drug.setBackground(new java.awt.Color(0, 0, 0));
        btn_view_drug.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_view_drug.setForeground(new java.awt.Color(255, 204, 204));
        btn_view_drug.setText("View Drugs");
        btn_view_drug.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_drug.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_view_drug.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_view_drug.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_view_drug.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_view_drug.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_drugActionPerformed(evt);
            }
        });

        btn_view_dep.setBackground(new java.awt.Color(0, 0, 0));
        btn_view_dep.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_view_dep.setForeground(new java.awt.Color(255, 204, 204));
        btn_view_dep.setText("Depositors");
        btn_view_dep.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_dep.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_view_dep.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_view_dep.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_view_dep.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_view_dep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_depActionPerformed(evt);
            }
        });

        btn_view_companies.setBackground(new java.awt.Color(0, 0, 0));
        btn_view_companies.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_view_companies.setForeground(new java.awt.Color(255, 204, 204));
        btn_view_companies.setText("Companies");
        btn_view_companies.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_companies.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_view_companies.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_view_companies.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_view_companies.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_view_companies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_companiesActionPerformed(evt);
            }
        });

        btn_new_drug6.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug6.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug6.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug6.setText("Sale Records");
        btn_new_drug6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug6.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug6.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug6.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug6.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug6ActionPerformed(evt);
            }
        });

        btn_new_drug8.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug8.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug8.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug8.setText("Order To Be Sent");
        btn_new_drug8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug8.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug8.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug8.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug8.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug8ActionPerformed(evt);
            }
        });

        btn_new_drug9.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug9.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug9.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug9.setText("Purchase via com");
        btn_new_drug9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug9.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug9.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug9.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug9.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug9ActionPerformed(evt);
            }
        });

        btn_new_drug10.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug10.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug10.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug10.setText("Record Sale");
        btn_new_drug10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug10.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug10.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug10.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug10.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug10ActionPerformed(evt);
            }
        });

        btn_HangingOrders.setBackground(new java.awt.Color(0, 0, 0));
        btn_HangingOrders.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_HangingOrders.setForeground(new java.awt.Color(255, 204, 204));
        btn_HangingOrders.setText("Hanging Orders");
        btn_HangingOrders.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_HangingOrders.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_HangingOrders.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_HangingOrdersActionPerformed(evt);
            }
        });

        btn_purchase.setBackground(new java.awt.Color(0, 0, 0));
        btn_purchase.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_purchase.setForeground(new java.awt.Color(255, 204, 204));
        btn_purchase.setText("Purchase Via dep.");
        btn_purchase.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_purchase.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_purchase.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_purchase.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_purchase.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_purchaseActionPerformed(evt);
            }
        });

        btn_issue_order.setBackground(new java.awt.Color(0, 0, 0));
        btn_issue_order.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_issue_order.setForeground(new java.awt.Color(255, 204, 204));
        btn_issue_order.setText("Record Order");
        btn_issue_order.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_issue_order.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_issue_order.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_issue_order.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_issue_order.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_issue_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_issue_orderActionPerformed(evt);
            }
        });

        btn_new_drug12.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug12.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug12.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug12.setText("Purch. From Order");
        btn_new_drug12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug12.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug12.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug12.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug12.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug12ActionPerformed(evt);
            }
        });

        btn_go_details.setBackground(new java.awt.Color(0, 0, 0));
        btn_go_details.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_go_details.setForeground(new java.awt.Color(255, 204, 204));
        btn_go_details.setText("View Profile/Detail");
        btn_go_details.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_go_details.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_go_detailsActionPerformed(evt);
            }
        });

        btn_remove.setBackground(new java.awt.Color(0, 0, 0));
        btn_remove.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_remove.setForeground(new java.awt.Color(255, 204, 204));
        btn_remove.setText("Remove");
        btn_remove.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_removeActionPerformed(evt);
            }
        });

        btn_view_drug1.setBackground(new java.awt.Color(0, 0, 0));
        btn_view_drug1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_view_drug1.setForeground(new java.awt.Color(255, 204, 204));
        btn_view_drug1.setText("Users");
        btn_view_drug1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_view_drug1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_view_drug1.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_view_drug1.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_view_drug1.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_view_drug1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_drug1ActionPerformed(evt);
            }
        });

        btn_new_drug11.setBackground(new java.awt.Color(0, 0, 0));
        btn_new_drug11.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_new_drug11.setForeground(new java.awt.Color(255, 204, 204));
        btn_new_drug11.setText("Withdraw Sale");
        btn_new_drug11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_new_drug11.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new_drug11.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_new_drug11.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_new_drug11.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_new_drug11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drug11ActionPerformed(evt);
            }
        });

        btn_HangingOrders1.setBackground(new java.awt.Color(0, 0, 0));
        btn_HangingOrders1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_HangingOrders1.setForeground(new java.awt.Color(255, 204, 204));
        btn_HangingOrders1.setText("Set Mrp.");
        btn_HangingOrders1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 1, true));
        btn_HangingOrders1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_HangingOrders1.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders1.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders1.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_HangingOrders1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_HangingOrders1ActionPerformed(evt);
            }
        });

        lbl_mrp_warn.setText("..............");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(btn_new_drug12, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_remove, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_go_details, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_HangingOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_drug9, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_drug10, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_reg_act, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_issue_order, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_view_drug, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_view_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_view_companies, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_drug6, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_new_drug8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_view_drug1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btn_new_drug11, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lbl_mrp_warn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_mrp, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_HangingOrders1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btn_go_details, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(btn_remove, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(lbl_reg_act, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(btn_new_drug10, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btn_new_drug9, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btn_issue_order, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btn_new_drug12, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_drug11, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btn_view_drug, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_companies, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_new_drug6, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_drug8, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_drug1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_HangingOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_mrp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_HangingOrders1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_mrp_warn)
                .addContainerGap())
        );

        lbl_tble_title.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lbl_tble_title.setForeground(new java.awt.Color(255, 204, 153));
        lbl_tble_title.setText(".................................................................");

        cmb_drug_by_com.setBackground(new java.awt.Color(2, 25, 25));
        cmb_drug_by_com.setForeground(new java.awt.Color(204, 255, 204));
        cmb_drug_by_com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_by_comActionPerformed(evt);
            }
        });

        cmb_drug_by_gen.setBackground(new java.awt.Color(2, 25, 25));
        cmb_drug_by_gen.setForeground(new java.awt.Color(204, 255, 204));
        cmb_drug_by_gen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_by_genActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(204, 255, 204));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 255));
        jLabel3.setText("Companies ");

        jLabel4.setBackground(new java.awt.Color(204, 255, 204));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 255));
        jLabel4.setText("Generics ");

        lbl_process_title.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        lbl_process_title.setForeground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(lbl_tble_title, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(0, 0, 0)
                        .addComponent(cmb_drug_by_com, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmb_drug_by_gen, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 779, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnl_grand, javax.swing.GroupLayout.DEFAULT_SIZE, 434, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lbl_process_title, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbl_tble_title, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cmb_drug_by_com, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmb_drug_by_gen, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lbl_process_title, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                            .addComponent(jpnl_grand, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE))))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        // TODO add your handling code here:
        //   pms_Home.clear_Grand_Pnl();
        System.exit(0);
//        setVisible(false);
//        pms_Home = null;
    }//GEN-LAST:event_btn_exitActionPerformed

    private void btn_minActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_minActionPerformed
        // TODO add your handling code here:
        setState(1);
    }//GEN-LAST:event_btn_minActionPerformed

    private void btn_cancel_allActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancel_allActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btn_cancel_allActionPerformed

    private void btn_new_drugActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drugActionPerformed
        // TODO add your handling code here:
        call_NewDrugPanel(0);
    }//GEN-LAST:event_btn_new_drugActionPerformed

    private void btn_new_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_accActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_acc = new New_Account(0, "add")));
        new_acc.setLocation(10, 5);
        jpnl_grand.setVisible(true);
        jpnl_grand.setBackground(new Color(15, 38, 38));
        lbl_process_title.setText("New User Account To Be Added");
    }//GEN-LAST:event_btn_new_accActionPerformed

    private void btn_new_drug2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug2ActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_dep = new New_Depositor("Add")));
        new_dep.setLocation(15, 15);
        jpnl_grand.setVisible(true);
        lbl_process_title.setText("");
    }//GEN-LAST:event_btn_new_drug2ActionPerformed

    public void view_Drugs(String where, String str_sign) {

        if (str_sign == "all") {
            query = "SELECT * FROM drug_stock";
        } else {
            query = "SELECT * FROM drug_stock WHERE " + where + " = '" + str_sign + "'";
        }
        System.out.println("\n\n" + query);
        String[] coloumn = new String[7];
        String[] data = new String[7];
        arr_show = new ArrayList<String[]>();
        drug_ids = new ArrayList<>();
        coloumn[0] = "Drug Name";
        coloumn[1] = "Group name";
        coloumn[2] = "ComPany";
        coloumn[3] = "Type";
        coloumn[4] = "Available Pcs";
        coloumn[5] = "MRP";
        coloumn[6] = "exp date";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();

            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("drug_name");
                data[1] = rs.getString("generic");
                data[2] = rs.getString("company");
                data[3] = rs.getString("type");
                data[5] = rs.getString("mrp");

                temp_id = rs.getInt("drug_id");

                temp_query = "SELECT exp_date  , left_amount  from stock_detail  where drug_id =" + temp_id;

                temp_rs = temp_st.executeQuery(temp_query);
                sign = false;
                data[6] = "";
                data[4] = "";
                while (temp_rs.next()) {
                    drug_ids.add(temp_id);
                    data[6] = temp_rs.getString(1);
                    data[4] = temp_rs.getString(2);
                    sign = true;
                    arr_show.add(data);
                    dm.addRow(arr_show.get(0));
                }
                if (sign == false) {
                    drug_ids.add(temp_id);
                    arr_show.add(data);
                    dm.addRow(arr_show.get(0));
                }
                temp_rs.close();
            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Drugs From Stock");
        tbl_Result_Exhibition.getColumnModel().getColumn(6).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(6).setMinWidth(70);

    }
    private void btn_view_drugActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_drugActionPerformed
        // TODO add your handling code here:
        view_Drugs("", "all");

        //  temp_query = "select * SUM(left_amount) FROM stock_detail WHERE drug_id= " + temp_id + " ";
        //  temp_query = "SELECT left_amount  FROM stock_detail WHERE drug_id= " + temp_id;
        // temp_query = "SELECT COUNT(left_amount) , SUM(left_amount) from stock_detail  where drug_id =" + temp_id;
    }//GEN-LAST:event_btn_view_drugActionPerformed

    private void btn_view_depActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_depActionPerformed
        // TODO add your handling code here:
        ids = new ArrayList<Integer>();
        String[] coloumn = new String[5];
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Company";
        coloumn[3] = "Last Delivery";
        coloumn[4] = "Due Left";
        //  coloumn[5] = "Action";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM depositors";

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("com_name");
                temp_id = Integer.parseInt(rs.getString("dep_id"));
                ids.add(temp_id);
                temp_query = "SELECT SUM(due) from purchase_event where dep_id =" + temp_id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[4] = temp_rs.getString(1);

                }

                temp_query = "SELECT  date from purchase_event WHERE dep_id = " + temp_id + " order by date desc limit 1 ";

                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString(1);
                }
                temp_rs.close();
                //   data[5] = " @ order delivery ";
                arr_show.add(data);
                dm.addRow(arr_show.get(0));

            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Depositors");

        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(140);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(140);
    }//GEN-LAST:event_btn_view_depActionPerformed

    private void btn_view_companiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_companiesActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[4];
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Company";
        coloumn[1] = "Drugs On Run";
        coloumn[2] = "Action";
        coloumn[3] = "Action";
        data[2] = "@ order ";
        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT distinct company from drug_stock";
            // query = "SELECT company ,  count(*)   from drug_stock GROUP BY company";
            rs = st.executeQuery(query);

            while (rs.next()) {
                data[0] = rs.getString(1);
//                temp_query = "SELECT COUNT(company)  FROM drug_stock WHERE company = '" + data[0] + "'";
//                temp_rs = st.executeQuery(temp_query);
//                while (temp_rs.next()) {
//                     data[1]= temp_rs.getString(1);
//                }
//
//                System.out.println(data[0] + "  " + data[1]);
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }

        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Companies");
    }//GEN-LAST:event_btn_view_companiesActionPerformed

    private void cmb_drug_by_comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_by_comActionPerformed
        // TODO add your handling code here:

        if (cmb_drug_by_com.getSelectedIndex() > -1) {
            com_name = cmb_drug_by_com.getSelectedItem().toString();
            System.out.println("  com name: " + com_name);
            view_Drugs("company", com_name);
        }
    }//GEN-LAST:event_cmb_drug_by_comActionPerformed

    private void cmb_drug_by_genActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_by_genActionPerformed
        // TODO add your handling code here:

        if (cmb_drug_by_com.getSelectedIndex() > -1) {

            drug_group = cmb_drug_by_gen.getSelectedItem().toString();
            System.out.println(drug_group);
            view_Drugs("generic", drug_group);

        }
    }//GEN-LAST:event_cmb_drug_by_genActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:

        if (btn_login_out.getText().equals("Log In")) {
            u_name = txt_u_name.getText();
            pass = txt_pass.getText();
            System.out.println(u_name + "   " + pass);
            try {

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);

                st = con.createStatement();
                query = "SELECT * FROM accounts ";

                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (u_name.equals(rs.getString("user_name")) && pass.equals(rs.getString("pass"))) {
                        using_acc_type = rs.getString("type");
                        sign = true;
                        break;
                    }
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
            if (sign == true) {
                follow_Type(using_acc_type);
            } else {
                status_In_Time("Missmatch !", 1500);
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_login_outActionPerformed

    private void cmb_drug_by_com1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_by_com1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_drug_by_com1ActionPerformed

    private void txt_search_contentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_contentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_contentActionPerformed

    private void btn_new_drug6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug6ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btn_new_drug6ActionPerformed

    private void btn_issue_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_issue_orderActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (row >= 0) {
            if (lbl_tble_title.getText().contains("Depositors")) {
                com_name = tbl_Result_Exhibition.getValueAt(row, 2).toString();
                lbl_process_title.setText("Purchase Order For: " + tbl_Result_Exhibition.getValueAt(row, 0).toString() + ", " + tbl_Result_Exhibition.getValueAt(row, 2).toString());
                dep_id = ids.get(row);
                view_Drugs("company", com_name);
                call_NewDrugPanel(1);
            } else if (lbl_tble_title.getText().contains("Companies")) {
                com_name = tbl_Result_Exhibition.getValueAt(row, 0).toString();
                dep_id = -1;
                lbl_process_title.setText("Purchase Order For: " + com_name);
                view_Drugs("company", com_name);
                call_NewDrugPanel(1);
            }
        }
    }//GEN-LAST:event_btn_issue_orderActionPerformed

    private void btn_new_drug8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_new_drug8ActionPerformed

    private void btn_new_drug9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug9ActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (row > -1) {
            if (lbl_tble_title.getText().equals("Companies")) {
                com_name = tbl_Result_Exhibition.getValueAt(row, 0).toString();
                dep_id = -1;
                lbl_process_title.setText("Purchase Attemt: from " + com_name);
                view_Drugs("company", com_name);
                call_NewDrugPanel(2);
            }
            btn_view_companiesActionPerformed(evt);
        }
    }//GEN-LAST:event_btn_new_drug9ActionPerformed

    private void btn_new_drug10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug10ActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (lbl_tble_title.getText().startsWith("Drugs")) {

            lbl_process_title.setText("Sale Attemt: ");

            call_NewDrugPanel(3);
        } else {
            btn_view_drugActionPerformed(evt);
        }
    }//GEN-LAST:event_btn_new_drug10ActionPerformed

    public void view_Hanging_Orders() {
        ids = new ArrayList<Integer>();
        String[] coloumn = new String[5];
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Company";
        coloumn[1] = "Creation Date";
        coloumn[2] = "Depositor";
        coloumn[3] = "dep. Contact";
        coloumn[4] = "Num Of Drugs";
        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM purchase_event where status = 'Ordered' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                pur_id = rs.getInt("pur_id");
                ids.add(pur_id);
                data[0] = rs.getString("company");
                data[1] = rs.getString("date");

                query = "SELECT count(*) from purchase_detail where pur_id =" + pur_id;
                temp_rs = temp_st.executeQuery(query);
                while (temp_rs.next()) {
                    data[4] = temp_rs.getString(1);
                    System.out.println(" result: " + temp_rs.getString(1));
                }
                temp_id = rs.getInt("dep_id");
                if (temp_id != -1) {
                    temp_query = "SELECT name , contact from depositors where dep_id =" + temp_id;
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        data[2] = temp_rs.getString(1);
                        data[3] = temp_rs.getString(2);
                    }
                } else {
                    data[2] = "No depositor";
                    data[3] = "---------";
                }
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Orders Not Recieved");
    }
    private void btn_HangingOrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_HangingOrdersActionPerformed
        // TODO add your handling code here:
        view_Hanging_Orders();
    }//GEN-LAST:event_btn_HangingOrdersActionPerformed

    public void call_NewDrugPanel(int call_sign) {
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_drug = new New_Drug(call_sign)));
        new_drug.setLocation(0, 0);
        jpnl_grand.setVisible(true);

    }
    private void btn_purchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_purchaseActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (row > -1 && lbl_tble_title.getText().contains("Depositors")) {
            com_name = tbl_Result_Exhibition.getValueAt(row, 2).toString();
            lbl_process_title.setText("Purchase Attemt: " + tbl_Result_Exhibition.getValueAt(row, 0).toString() + ", " + com_name);
            dep_id = ids.get(row);
            call_NewDrugPanel(2);
            view_Drugs("company", com_name);
        } else {
            btn_view_depActionPerformed(evt);
        }
    }//GEN-LAST:event_btn_purchaseActionPerformed

    private void btn_new_drug12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug12ActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (lbl_tble_title.getText().contains("Orders") && row > -1) {
            order_id = ids.get(row);
            purchaseFromOrder = new PurchaseFrom_Order(order_id, true);
        }
    }//GEN-LAST:event_btn_new_drug12ActionPerformed

    private void btn_go_detailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_go_detailsActionPerformed
        // TODO add your handling code here:
        sign = false;
        if (tbl_Result_Exhibition.getSelectedRow() < 0 || tbl_Result_Exhibition.getSelectedRows().length > 1) {
            sign = true;
        }
        if (sign == false && lbl_tble_title.getText().contains("Orders")) {
            order_id = tbl_Result_Exhibition.getSelectedRow();
            order_id = ids.get(order_id);
            purchaseFromOrder = new PurchaseFrom_Order(order_id, false);
        }
        if (sign == false && lbl_tble_title.getText().contains("Depositors")) {
            running_Profile = tbl_Result_Exhibition.getSelectedRow();
            running_Profile = ids.get(running_Profile);
            jpnl_grand.removeAll();
            jpnl_grand.setVisible(false);
            jpnl_grand.add((new_dep = new New_Depositor("View")));
            new_dep.setLocation(15, 15);
            jpnl_grand.setVisible(true);
            lbl_process_title.setText("");
        }
    }//GEN-LAST:event_btn_go_detailsActionPerformed

    private void btn_removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_removeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_removeActionPerformed

    private void btn_view_drug1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_drug1ActionPerformed
        String[] coloumn = new String[4];
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Email";
        coloumn[3] = "Type";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM users ";
            // query = "SELECT company ,  count(*)   from drug_stock GROUP BY company";
            rs = st.executeQuery(query);

            while (rs.next()) {
                data[0] = rs.getString("full_name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("email");
                data[3] = rs.getString("type");

                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }

        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Users");        // TODO add your handling code here:
    }//GEN-LAST:event_btn_view_drug1ActionPerformed

    private void btn_new_drug11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drug11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_new_drug11ActionPerformed

    private void btn_HangingOrders1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_HangingOrders1ActionPerformed
        // TODO add your handling code here:
        int row = tbl_Result_Exhibition.getSelectedRow();

        sign = false;
        try {
            mrp = Float.parseFloat(txt_mrp.getText());
        } catch (Exception exc) {
            sign = true;
            status_In_Time("invalid mrp", 2202);
            System.out.println(exc);
        }
        if (tbl_Result_Exhibition.getSelectedRows().length == 1 && row > -1 && lbl_tble_title.getText().startsWith("Drugs") && sign == false) {
            drug_id = drug_ids.get(row);
            System.out.println("id %% " + drug_id);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
                st = con.createStatement();
                query = "UPDATE drug_stock SET"
                        + " mrp = ? "
                        + "WHERE drug_id = " + drug_id + " ";
                pst = con.prepareStatement(query);
                pst.setFloat(1, mrp);
                pst.executeUpdate();
            } catch (Exception exp) {
                System.out.println(exp);
            }
        }
    }//GEN-LAST:event_btn_HangingOrders1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//            //  UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
//            //   UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (pms_Home = new Home()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_HangingOrders;
    public javax.swing.JButton btn_HangingOrders1;
    public javax.swing.JButton btn_cancel_all;
    public javax.swing.JButton btn_exit;
    public javax.swing.JButton btn_go_details;
    public javax.swing.JButton btn_issue_order;
    public javax.swing.JButton btn_login_out;
    public javax.swing.JButton btn_min;
    public javax.swing.JButton btn_new_acc;
    public javax.swing.JButton btn_new_drug;
    public javax.swing.JButton btn_new_drug10;
    public javax.swing.JButton btn_new_drug11;
    public javax.swing.JButton btn_new_drug12;
    public javax.swing.JButton btn_new_drug2;
    public javax.swing.JButton btn_new_drug6;
    public javax.swing.JButton btn_new_drug8;
    public javax.swing.JButton btn_new_drug9;
    public javax.swing.JButton btn_purchase;
    public javax.swing.JButton btn_remove;
    public javax.swing.JButton btn_search;
    public javax.swing.JButton btn_update;
    public javax.swing.JButton btn_view_companies;
    public javax.swing.JButton btn_view_dep;
    public javax.swing.JButton btn_view_drug;
    public javax.swing.JButton btn_view_drug1;
    public javax.swing.JComboBox<String> cmb_drug_by_com;
    public javax.swing.JComboBox<String> cmb_drug_by_com1;
    public javax.swing.JComboBox<String> cmb_drug_by_gen;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel4;
    public javax.swing.JLabel jLabel5;
    public javax.swing.JLabel jLabel6;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel4;
    public javax.swing.JPanel jPanel5;
    public javax.swing.JPanel jPanel6;
    public javax.swing.JPanel jPanel7;
    public javax.swing.JPanel jPanel8;
    public javax.swing.JPanel jPanel9;
    public javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JPanel jpnl_grand;
    public javax.swing.JLabel lbl_con_pass;
    public javax.swing.JLabel lbl_mrp_warn;
    public javax.swing.JLabel lbl_process_title;
    public javax.swing.JLabel lbl_reg_act;
    public javax.swing.JLabel lbl_tble_title;
    public javax.swing.JLabel lbl_warning;
    public javax.swing.JTable tbl_Result_Exhibition;
    public javax.swing.JTextField txt_conf_pass;
    public javax.swing.JTextField txt_mrp;
    public javax.swing.JTextField txt_pass;
    public javax.swing.JTextField txt_search_content;
    public javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables

    public void user_ActivityLogs(int user_id) {
        ids = new ArrayList<Integer>();
        String[] coloumn = new String[5];
        String[] data = new String[5];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "User";
        coloumn[1] = "Activity Type";
        coloumn[2] = "Date_Time";
        //  coloumn[5] = "Action";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM depositors";

            rs = st.executeQuery(query);
            while (rs.next()) {
            }
        } catch (Exception exc) {

        }

    }

}
