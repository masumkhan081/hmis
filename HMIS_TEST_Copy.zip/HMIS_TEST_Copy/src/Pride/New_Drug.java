/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pride;

import static Pride.PMS_Launcher.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.ListModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import oracle.jrockit.jfr.openmbean.JFRStatsType;

/**
 *
 * @author pddrgj3q
 */
public class New_Drug extends javax.swing.JPanel {

    /**
     * Creates new form New_Drug
     */
    static int count_done, count_total, count_running;
    int metric;
    static boolean temp;
    String date1, date2;
    static JFrame jfr;
    public DefaultListModel jlist_model;
    static String str[];
    static java.awt.event.ActionEvent evt;
    static ArrayList<String[]> purchase_order;
    int pX, pY;
    static int saleDrug_ID;
    private int purchasing_dep;

    public New_Drug() {

    }

    public New_Drug(int metric) {
        this.metric = metric;
        initComponents();
        setVisible(true);
        setSize(417, 530);
        jspn_date1.setEditor(new JSpinner.DateEditor(jspn_date1, "dd/MM/yy"));
        jspn_date1.setDate(new Date());
        jspn_date2.setEditor(new JSpinner.DateEditor(jspn_date2, "dd/MM/yy"));
        jspn_date2.setDate(new Date());
        Float value = new Float(50.28817271727);
        Float step = new Float(5.29182);

        date_Format = new SimpleDateFormat("dd/MM/yy");
        jlist_model = new DefaultListModel();
        purchase_order = new ArrayList<>();
        //   set_Movable();
        if (metric == 1) {
            Order_();
        }
        if (metric == 0) {
            introduce_New_Drug();
        }
        if (metric == 2) {
            purchasing_dep = dep_id;
            record_Purchase();
        }
        if (metric == 3) {
            record_Sale();
        }
    }

    public void record_Sale() {
        cmb_actions.setVisible(false);
        count_done = 0;
        count_running = 1;
        lbl_date2.setVisible(false);
        jspn_date2.setVisible(false);
        txt_email.setVisible(false);
        lbl_date1.setText("exp. date");
        lbl_bill.setText("bill:");
        txt_com_name.setEditable(false);
        txt_drug_name.setEditable(false);
        txt_group_name.setEditable(false);
    }

//    public static void main(String args[]) {
//        jfr = new JFrame();
//        jfr.setSize(420, 560);
//        jfr.setLocationRelativeTo(null);
//        jfr.add((new_drug = new New_Drug(1)));
//        new_drug.setLocation(10, 10);
//        //    jfr.setAlwaysOnTop(true);
//        jfr.setUndecorated(true);
//        jfr.setDefaultCloseOperation(0);
//        jfr.setVisible(true);
////     set_Movable();
//    }
    public void record_Purchase() {
        cmb_actions.setVisible(false);
        count_done = 0;
        grad_tot = 0;
        count_running = 1;
        cmb_type.setEditable(false);
        txt_com_name.setEnabled(false);
        txt_drug_name.setEnabled(false);
        txt_group_name.setEnabled(false);
        txt_com_name.setText(com_name);
        rbtn_cash.setSelected(false);
        txt_mrp.setEditable(false);
        txt_email.setVisible(false);
        lbl_mrp.setText("      ");
        lbl_date1.setText("exp. date");
        lbl_date2.setVisible(false);
        jspn_date2.setVisible(false);
    }

    public void introduce_New_Drug() {
        count_done = 0;
        count_running = 1;
        for (int i = 0; i < jPanel1.getComponents().length; i++) {
            jPanel1.getComponents()[i].setVisible(false);
        }
        for (int i = 0; i < jPanel3.getComponents().length; i++) {
            jPanel3.getComponents()[i].setVisible(false);
        }
        for (int i = 0; i < jPanel4.getComponents().length; i++) {
            jPanel4.getComponents()[i].setVisible(false);
        }
        lbl_mrp.setText("       ");
        btn_new.setVisible(false);
        cmb_actions.setVisible(false);

        btn_select_tbl.setVisible(false);
        lbl_grand_tot.setVisible(false);
        txt_email.setVisible(false);

    }

    public void Order_() {
        count_done = 0;
        count_running = 1;
        txt_com_name.setText(com_name);
        txt_drug_name.setEnabled(false);
        cmb_type.setEnabled(false);
        txt_group_name.setEnabled(false);
        txt_com_name.setEnabled(false);
        txt_bill.setVisible(false);
        lbl_bill.setVisible(false);
        lbl_mrp.setVisible(false);
        lbl_bill.setText("pur bill");

        btn_DONE.setText("Go");
        lbl_counter.setText("new/" + count_done);
        for (int i = 0; i < jPanel4.getComponents().length; i++) {
            jPanel4.getComponents()[i].setVisible(false);
        }
        for (int i = 0; i < jPanel3.getComponents().length; i++) {
            jPanel3.getComponents()[i].setVisible(false);
        }
        jspnr_quant.setVisible(true);
        lbl_quant.setVisible(true);
        lbl_grand_tot.setVisible(false);
    }

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_msg.setText("");
                if (i == 2501) {
                    btn_exitActionPerformed(evt);
                }
            }
        }).start();
        lbl_msg.setText(str);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_drug_name = new javax.swing.JTextField();
        txt_group_name = new javax.swing.JTextField();
        txt_com_name = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        lbl_msg = new javax.swing.JLabel();
        cmb_actions = new javax.swing.JComboBox<>();
        btn_DONE = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        list_suggestion = new javax.swing.JList<>();
        lbl_warn = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txt_email = new javax.swing.JTextField();
        lbl_grand_tot = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_calculator = new javax.swing.JButton();
        lbl_mrp = new javax.swing.JLabel();
        lbl_type = new javax.swing.JLabel();
        cmb_type = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        lbl_quant = new javax.swing.JLabel();
        jspnr_quant = new javax.swing.JSpinner();
        lbl_bill = new javax.swing.JLabel();
        txt_bill = new javax.swing.JTextField();
        rbtn_cash = new javax.swing.JRadioButton();
        txt_mrp = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        lbl_date1 = new javax.swing.JLabel();
        jspn_date1 = new com.toedter.calendar.JSpinnerDateEditor();
        lbl_date2 = new javax.swing.JLabel();
        jspn_date2 = new com.toedter.calendar.JSpinnerDateEditor();
        lbl_dick = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btn_exclude = new javax.swing.JButton();
        btn_next = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        btn_back = new javax.swing.JButton();
        btn_done = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        btn_cancel_all = new javax.swing.JButton();
        lbl_counter = new javax.swing.JLabel();
        btn_view = new javax.swing.JButton();
        btn_select_tbl = new javax.swing.JButton();
        btn_new = new javax.swing.JButton();
        btn_exit = new javax.swing.JButton();

        setBackground(new java.awt.Color(1, 13, 13));
        setMaximumSize(new java.awt.Dimension(405, 530));
        setMinimumSize(new java.awt.Dimension(405, 530));
        setPreferredSize(new java.awt.Dimension(405, 530));

        txt_drug_name.setBackground(new java.awt.Color(1, 13, 13));
        txt_drug_name.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        txt_drug_name.setForeground(new java.awt.Color(255, 204, 102));
        txt_drug_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_drug_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        txt_drug_name.setMaximumSize(new java.awt.Dimension(315, 42));
        txt_drug_name.setMinimumSize(new java.awt.Dimension(315, 42));
        txt_drug_name.setPreferredSize(new java.awt.Dimension(315, 42));

        txt_group_name.setBackground(new java.awt.Color(1, 13, 13));
        txt_group_name.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        txt_group_name.setForeground(new java.awt.Color(255, 204, 102));
        txt_group_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_group_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Genre :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        txt_group_name.setMaximumSize(new java.awt.Dimension(315, 42));
        txt_group_name.setMinimumSize(new java.awt.Dimension(315, 42));
        txt_group_name.setPreferredSize(new java.awt.Dimension(315, 42));
        txt_group_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_group_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_group_nameFocusLost(evt);
            }
        });
        txt_group_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_group_nameActionPerformed(evt);
            }
        });

        txt_com_name.setBackground(new java.awt.Color(1, 13, 13));
        txt_com_name.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        txt_com_name.setForeground(new java.awt.Color(255, 204, 102));
        txt_com_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_com_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Company :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        txt_com_name.setMaximumSize(new java.awt.Dimension(315, 42));
        txt_com_name.setMinimumSize(new java.awt.Dimension(315, 42));
        txt_com_name.setPreferredSize(new java.awt.Dimension(315, 42));
        txt_com_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_com_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_com_nameFocusLost(evt);
            }
        });

        jPanel5.setBackground(new java.awt.Color(18, 7, 7));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel5.setMinimumSize(new java.awt.Dimension(405, 0));

        lbl_msg.setBackground(new java.awt.Color(153, 51, 0));
        lbl_msg.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_msg.setForeground(new java.awt.Color(255, 204, 102));
        lbl_msg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_msg.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        cmb_actions.setBackground(new java.awt.Color(12, 23, 23));
        cmb_actions.setForeground(new java.awt.Color(255, 204, 102));
        cmb_actions.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Order via email", "Just Save", "Order To Be", "Print Order" }));
        cmb_actions.setSelectedIndex(-1);
        cmb_actions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_actionsActionPerformed(evt);
            }
        });

        btn_DONE.setBackground(new java.awt.Color(0, 0, 0));
        btn_DONE.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btn_DONE.setForeground(new java.awt.Color(255, 204, 102));
        btn_DONE.setText("Complete");
        btn_DONE.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_DONE.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btn_DONE.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        btn_DONE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DONEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(cmb_actions, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_DONE, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_actions, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_DONE))
                .addGap(0, 0, 0))
        );

        list_suggestion.setBackground(new java.awt.Color(1, 16, 16));
        list_suggestion.setBorder(new javax.swing.border.MatteBorder(null));
        list_suggestion.setForeground(new java.awt.Color(204, 255, 204));
        list_suggestion.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                list_suggestionValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(list_suggestion);

        lbl_warn.setForeground(new java.awt.Color(255, 204, 204));
        lbl_warn.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jPanel1.setBackground(new java.awt.Color(1, 13, 13));
        jPanel1.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel1.setMinimumSize(new java.awt.Dimension(405, 0));

        txt_email.setBackground(new java.awt.Color(13, 23, 23));
        txt_email.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        txt_email.setForeground(new java.awt.Color(255, 153, 102));
        txt_email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_email.setText("email..");
        txt_email.setMaximumSize(new java.awt.Dimension(275, 24));
        txt_email.setMinimumSize(new java.awt.Dimension(270, 22));
        txt_email.setPreferredSize(new java.awt.Dimension(270, 22));
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_emailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });

        lbl_grand_tot.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbl_grand_tot.setForeground(new java.awt.Color(204, 204, 255));
        lbl_grand_tot.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "grand total", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 204, 255))); // NOI18N
        lbl_grand_tot.setMaximumSize(new java.awt.Dimension(155, 22));
        lbl_grand_tot.setMinimumSize(new java.awt.Dimension(155, 22));
        lbl_grand_tot.setPreferredSize(new java.awt.Dimension(155, 22));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_grand_tot, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_grand_tot, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_email, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel2.setMinimumSize(new java.awt.Dimension(405, 0));

        btn_calculator.setBackground(new java.awt.Color(0, 4, 4));
        btn_calculator.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btn_calculator.setForeground(new java.awt.Color(255, 255, 204));
        btn_calculator.setText("Calculator");
        btn_calculator.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_calculator.setContentAreaFilled(false);
        btn_calculator.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_calculator.setMaximumSize(new java.awt.Dimension(72, 19));
        btn_calculator.setMinimumSize(new java.awt.Dimension(72, 19));
        btn_calculator.setPreferredSize(new java.awt.Dimension(72, 19));
        btn_calculator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_calculatorActionPerformed(evt);
            }
        });

        lbl_mrp.setForeground(new java.awt.Color(255, 255, 204));
        lbl_mrp.setText(" mrp:");

        lbl_type.setForeground(new java.awt.Color(204, 204, 255));
        lbl_type.setText("Type >");

        cmb_type.setBackground(new java.awt.Color(2, 22, 22));
        cmb_type.setForeground(new java.awt.Color(204, 255, 153));
        cmb_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tablet", "Syrup", "etc1", "etc2" }));
        cmb_type.setSelectedIndex(-1);
        cmb_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_typeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(lbl_type, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(cmb_type, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_mrp, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_calculator, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(53, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_mrp, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_type, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_calculator, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_type, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jPanel3.setBackground(new java.awt.Color(1, 13, 13));
        jPanel3.setPreferredSize(new java.awt.Dimension(366, 50));

        lbl_quant.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_quant.setForeground(new java.awt.Color(204, 204, 255));
        lbl_quant.setText("Quantity (PCs):");

        jspnr_quant.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 19)); // NOI18N
        jspnr_quant.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspnr_quant.setMaximumSize(new java.awt.Dimension(78, 24));
        jspnr_quant.setMinimumSize(new java.awt.Dimension(78, 24));
        jspnr_quant.setPreferredSize(new java.awt.Dimension(78, 24));
        jspnr_quant.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jspnr_quantStateChanged(evt);
            }
        });

        lbl_bill.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_bill.setForeground(new java.awt.Color(202, 202, 241));
        lbl_bill.setText("Purchase bill");

        txt_bill.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        txt_bill.setForeground(new java.awt.Color(153, 51, 0));
        txt_bill.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 2, 0, new java.awt.Color(0, 153, 153)));
        txt_bill.setMaximumSize(new java.awt.Dimension(78, 24));
        txt_bill.setMinimumSize(new java.awt.Dimension(78, 24));
        txt_bill.setPreferredSize(new java.awt.Dimension(78, 24));
        txt_bill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_billActionPerformed(evt);
            }
        });

        rbtn_cash.setBackground(new java.awt.Color(1, 13, 13));
        rbtn_cash.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        rbtn_cash.setForeground(new java.awt.Color(255, 204, 153));
        rbtn_cash.setText("/=");
        rbtn_cash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtn_cashActionPerformed(evt);
            }
        });

        txt_mrp.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        txt_mrp.setForeground(new java.awt.Color(153, 51, 0));
        txt_mrp.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_mrp.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 2, 0, new java.awt.Color(0, 153, 153)));
        txt_mrp.setMaximumSize(new java.awt.Dimension(78, 24));
        txt_mrp.setMinimumSize(new java.awt.Dimension(78, 24));
        txt_mrp.setPreferredSize(new java.awt.Dimension(78, 24));
        txt_mrp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_mrpActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_quant, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                    .addComponent(jspnr_quant, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_bill, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_bill, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(rbtn_cash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_mrp, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE))
                .addGap(64, 64, 64))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl_bill, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rbtn_cash, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_quant, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_bill, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_mrp, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jspnr_quant, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jPanel4.setBackground(new java.awt.Color(0, 51, 51));
        jPanel4.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel4.setMinimumSize(new java.awt.Dimension(405, 0));

        lbl_date1.setBackground(new java.awt.Color(0, 51, 51));
        lbl_date1.setForeground(new java.awt.Color(204, 204, 255));
        lbl_date1.setText("Pur. Date");

        jspn_date1.setBackground(new java.awt.Color(15, 38, 38));
        jspn_date1.setBorder(null);
        jspn_date1.setForeground(new java.awt.Color(255, 204, 102));
        jspn_date1.setModel(new javax.swing.SpinnerDateModel());
        jspn_date1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        lbl_date2.setBackground(new java.awt.Color(0, 51, 51));
        lbl_date2.setForeground(new java.awt.Color(204, 204, 255));
        lbl_date2.setText("Exp. Date");

        jspn_date2.setBackground(new java.awt.Color(15, 38, 38));
        jspn_date2.setBorder(null);
        jspn_date2.setForeground(new java.awt.Color(255, 204, 102));
        jspn_date2.setModel(new javax.swing.SpinnerDateModel());
        jspn_date2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        lbl_dick.setBackground(new java.awt.Color(0, 0, 0));
        lbl_dick.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_dick.setForeground(new java.awt.Color(255, 255, 255));
        lbl_dick.setText("      ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_date1)
                .addGap(0, 0, 0)
                .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_date2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jspn_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_dick, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jspn_date1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jspn_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_dick))
                .addGap(0, 0, 0))
        );

        jPanel6.setBackground(new java.awt.Color(0, 51, 51));
        jPanel6.setMaximumSize(new java.awt.Dimension(405, 32767));
        jPanel6.setMinimumSize(new java.awt.Dimension(405, 0));

        btn_exclude.setBackground(new java.awt.Color(0, 0, 0));
        btn_exclude.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exclude.setForeground(new java.awt.Color(204, 255, 153));
        btn_exclude.setText("Exclude This One");
        btn_exclude.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exclude.setContentAreaFilled(false);
        btn_exclude.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_excludeActionPerformed(evt);
            }
        });

        btn_next.setBackground(new java.awt.Color(0, 0, 0));
        btn_next.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_next.setForeground(new java.awt.Color(204, 255, 153));
        btn_next.setText("Next");
        btn_next.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_next.setContentAreaFilled(false);
        btn_next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nextActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(0, 0, 0));
        btn_clear.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(204, 255, 153));
        btn_clear.setText("Clear");
        btn_clear.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_clear.setContentAreaFilled(false);
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        btn_back.setBackground(new java.awt.Color(0, 0, 0));
        btn_back.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_back.setForeground(new java.awt.Color(204, 255, 153));
        btn_back.setText("Back");
        btn_back.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_back.setContentAreaFilled(false);
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });

        btn_done.setBackground(new java.awt.Color(0, 0, 0));
        btn_done.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_done.setForeground(new java.awt.Color(204, 255, 153));
        btn_done.setText("Done");
        btn_done.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_done.setContentAreaFilled(false);
        btn_done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_doneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(btn_exclude)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_next, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_back, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btn_back, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_next, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(btn_exclude, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel7.setBackground(new java.awt.Color(1, 17, 17));
        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_cancel_all.setBackground(new java.awt.Color(0, 0, 0));
        btn_cancel_all.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btn_cancel_all.setForeground(new java.awt.Color(255, 204, 204));
        btn_cancel_all.setText("Cancel All");
        btn_cancel_all.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancel_all.setBorderPainted(false);
        btn_cancel_all.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_cancel_all.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_cancel_all.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_cancel_all.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_cancel_all.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancel_allActionPerformed(evt);
            }
        });

        lbl_counter.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbl_counter.setForeground(new java.awt.Color(204, 153, 255));
        lbl_counter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_counter.setMaximumSize(new java.awt.Dimension(80, 19));
        lbl_counter.setMinimumSize(new java.awt.Dimension(80, 19));
        lbl_counter.setPreferredSize(new java.awt.Dimension(80, 19));

        btn_view.setBackground(new java.awt.Color(0, 0, 0));
        btn_view.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btn_view.setForeground(new java.awt.Color(255, 204, 204));
        btn_view.setText("View Listed");
        btn_view.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_view.setBorderPainted(false);
        btn_view.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_view.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_view.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_view.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewActionPerformed(evt);
            }
        });

        btn_select_tbl.setBackground(new java.awt.Color(0, 0, 0));
        btn_select_tbl.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btn_select_tbl.setForeground(new java.awt.Color(255, 204, 204));
        btn_select_tbl.setText("Get Selected");
        btn_select_tbl.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_select_tbl.setBorderPainted(false);
        btn_select_tbl.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_select_tbl.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_select_tbl.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_select_tbl.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_select_tbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_select_tblActionPerformed(evt);
            }
        });

        btn_new.setBackground(new java.awt.Color(0, 0, 0));
        btn_new.setFont(new java.awt.Font("Arial Unicode MS", 0, 12)); // NOI18N
        btn_new.setForeground(new java.awt.Color(255, 204, 204));
        btn_new.setText("new drug");
        btn_new.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new.setBorderPainted(false);
        btn_new.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_new.setMaximumSize(new java.awt.Dimension(80, 19));
        btn_new.setMinimumSize(new java.awt.Dimension(80, 19));
        btn_new.setPreferredSize(new java.awt.Dimension(80, 19));
        btn_new.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_newActionPerformed(evt);
            }
        });

        btn_exit.setBackground(new java.awt.Color(102, 51, 0));
        btn_exit.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 204, 153));
        btn_exit.setText("Exit");
        btn_exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lbl_counter, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_cancel_all, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_view, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_select_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_new, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addComponent(btn_exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_cancel_all, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_counter, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_view, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(btn_select_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(btn_new, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_group_name, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_com_name, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(lbl_warn)
                .addGap(56, 56, 56))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_group_name, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_com_name, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_warn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(10, 10, 10)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txt_group_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_group_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_group_nameActionPerformed

    public void set_Suggestions() {
        sugg = new ArrayList<>();
        try {
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            query = "SELECT DISTINCT " + db_clmn_sugg + "  FROM drug_stock";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
        } catch (Exception exp) {
            System.out.println(exp);
        }
        jlist_model.clear();
        for (int i = 0; i < sugg.size(); i++) {
            jlist_model.add(i, sugg.get(i));
        }
        list_suggestion.setModel(jlist_model);

    }

    private void txt_group_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_group_nameFocusGained
        // TODO add your handling code here:

        db_clmn_sugg = "generic";
        set_Suggestions();

    }//GEN-LAST:event_txt_group_nameFocusGained

    private void txt_com_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_com_nameFocusGained
        // TODO add your handling code here:

        db_clmn_sugg = "company";
        set_Suggestions();

    }//GEN-LAST:event_txt_com_nameFocusGained

    private void list_suggestionValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_list_suggestionValueChanged
        // TODO add your handling code here:

        if (list_suggestion.getSelectedIndex() > -1) {
            selected_sugg = list_suggestion.getSelectedValue();

            if (db_clmn_sugg.equals("company")) {
                txt_com_name.setText(selected_sugg);
            }
            if (db_clmn_sugg.equals("generic")) {
                txt_group_name.setText(selected_sugg);
            }
        }

    }//GEN-LAST:event_list_suggestionValueChanged

    private void txt_billActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_billActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_billActionPerformed

    private void btn_doneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_doneActionPerformed
        // TODO add your handling code here:
        sign = false;
        drug_type = "";
        if (cmb_type.getSelectedIndex() != -1) {
            drug_type = cmb_type.getSelectedItem().toString();
        }
        quant = (int) jspnr_quant.getValue();
        drug_group = txt_group_name.getText();
        drug_name = txt_drug_name.getText();
        com_name = txt_com_name.getText();
        if (metric == 3) {

            System.out.println("q: " + quantity + "  ava: " + available);
            if (quant < 1) {
                sign = true;
                status_In_Time("quantity !", 2000);
            }
            if (quant > available) {
                sign = true;
                status_In_Time("Exceeds availabe !", 2000);
            }
            try {
                pur_bill = Integer.parseInt(txt_bill.getText());
            } catch (Exception exp) {
                sign = true;
                status_In_Time("Invalid Bill", 2000);
            }
            if (sign == false) {
                grad_tot += pur_bill;
                str = new String[5];
                str[0] = String.valueOf(drug_id);
                str[1] = String.valueOf(quant);
                str[2] = String.valueOf(pur_bill);
                str[3] = date_Format.format(jspn_date1.getDate());
                str[4] = String.valueOf(available);
                lbl_grand_tot.setText(String.valueOf(grad_tot));
            }
        }
        if (metric == 2) {
            if (drug_name.isEmpty()) {
                sign = true;
                status_In_Time("Select Drug", 2000);
            }
            try {
                pur_bill = Integer.parseInt(txt_bill.getText());
            } catch (Exception exp) {
                sign = true;
                status_In_Time("Invalid Bill", 2000);
            }
            if (rbtn_cash.isSelected()) {
                try {
                    mrp = Float.parseFloat(txt_mrp.getText());
                } catch (Exception pe) {
                    sign = true;
                    status_In_Time("Invalid mrp", 2000);
                }
            }
            if (pur_bill < 1 || quant < 0) {
                sign = true;
                status_In_Time(" !!!!!! ", 2000);
            }
            if (date_Format.format(jspn_date1.getDate()).equals(date_Format.format(new Date())) && sign == false) {
                System.out.println(date_Format.format(new Date()) + "  =? " + date_Format.format(jspn_date1.getDate()));
                sign = true;
                status_In_Time("exp date", 2000);
            }
            if (sign == false) {
                grad_tot += pur_bill;
                str = new String[8];
                str[0] = String.valueOf(drug_id);
                str[1] = String.valueOf(quant);
                str[2] = String.valueOf(pur_bill);
                str[3] = date_Format.format(jspn_date1.getDate());
                str[4] = drug_name;
                str[5] = drug_group;
                str[6] = drug_type;
                str[7] = com_name;
                lbl_grand_tot.setText(String.valueOf(grad_tot));
//                System.out.println(str[0] + " > " + str[1] + " > " + str[2] + " > " + str[3]);
            }
        }
        if (metric == 0) {
            if (drug_group.isEmpty() || com_name.isEmpty() || drug_name.isEmpty() || drug_type.isEmpty()) {
                status_In_Time("Incomplete", 2200);
                sign = true;
            }
            if (sign == false) {
                str = new String[4];
                str[0] = drug_name;
                str[1] = drug_group;
                str[2] = drug_type;
                str[3] = com_name;
            }
        }
        //                                                IF IT IS SENDING OR SAVING ORDER
        if (metric == 1) {
            if (quant < 1) {
                sign = true;
                status_In_Time("Not Yet", 2100);
            }
            if (sign == false) {
                str = new String[5];
                str[0] = String.valueOf(drug_id);
                str[1] = drug_name;
                str[2] = drug_group;
                str[3] = drug_type;
                str[4] = String.valueOf(quant);
            }
        }
        //                                                  IF IT IS FOR PURCHASE
        if (sign == false) {
            System.out.println("  btn_done > done:  " + count_done + "  run: " + count_running);
            if (count_running <= count_done) {
                purchase_order.remove(count_running - 1);
                purchase_order.add(count_running - 1, str);
                btn_viewActionPerformed(evt);
                btn_nextActionPerformed(evt);
            } else {
                purchase_order.add(count_done, str);
                count_done += 1;
                count_running += 1;
                lbl_counter.setText("new/" + count_done);
                btn_viewActionPerformed(evt);
            }

            btn_clearActionPerformed(evt);
            set_listedView();
        }
    }//GEN-LAST:event_btn_doneActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:
        if (count_running > 1) {
            count_running -= 1;
            set_BY_count_running();
            lbl_counter.setText(count_running + "/" + count_done);
        }
    }//GEN-LAST:event_btn_backActionPerformed

    public void set_BY_count_running() {
        System.out.println("done: " + count_done + "  run: " + count_running);
        if (metric == 0) {
            txt_drug_name.setText(purchase_order.get(count_running - 1)[0]);
            txt_group_name.setText(purchase_order.get(count_running - 1)[1]);
            cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[2]);
            txt_com_name.setText(purchase_order.get(count_running - 1)[3]);
        }
        if (metric == 1) {
            txt_drug_name.setText(purchase_order.get(count_running - 1)[1]);
            txt_group_name.setText(purchase_order.get(count_running - 1)[2]);
            cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[3]);
            jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[4]));
        }
        if (metric == 2) {
            txt_drug_name.setText(purchase_order.get(count_running - 1)[4]);
            txt_group_name.setText(purchase_order.get(count_running - 1)[5]);
            cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[6]);
            txt_com_name.setText(purchase_order.get(count_running - 1)[7]);
            jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[1]));
            try {
                jspn_date1.setDate(date_Format.parse(purchase_order.get(count_running - 1)[3]));
            } catch (Exception ex) {
                System.out.println(ex);
            }
            txt_bill.setText(purchase_order.get(count_running - 1)[2]);
        }
        if (count_running <= count_done) {
            btn_select_tbl.setEnabled(false);
        }

    }

    private void btn_excludeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_excludeActionPerformed
        // TODO add your handling code here:

        if (count_running <= count_done) {
            purchase_order.remove(count_running - 1);
            if (lbl_grand_tot.isVisible()) {
                lbl_grand_tot.setText("" + (grad_tot - Integer.parseInt(purchase_order.get(count_running - 1)[2])));
            }
            if (count_running == count_done) {
                count_done -= 1;
                lbl_counter.setText("new/" + count_done);
                System.out.println("this if 1 run: " + count_running);
            }
            if (count_running < count_done) {
                count_done -= 1;
                count_running = count_done + 1;
                System.out.println("this if 2 run: " + count_running);
                lbl_counter.setText("new" + "/" + count_done);
            }
            btn_clearActionPerformed(evt);
        }
    }//GEN-LAST:event_btn_excludeActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        // TODO add your handling code here:

        txt_drug_name.setText("");
        txt_group_name.setText("");
        jspnr_quant.setValue(0);
        txt_bill.setText("");
        cmb_type.setSelectedIndex(-1);
        // System.out.println("before " + date_Format.format(jspn_date1.getDate()));
        // jspn_date1.setDate(new Date());
        jspn_date1.setDate(new Date());
        //  System.out.println("new date set up " + date_Format.format(jspn_date1.getDate()));
        if (metric == 0) {
            txt_com_name.setText("");
        }

        jlist_model.clear();
        list_suggestion.setModel(jlist_model);

    }//GEN-LAST:event_btn_clearActionPerformed

    private void cmb_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_typeActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_cmb_typeActionPerformed

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        // TODO add your handling code here:
//        try {
//            if (evt.getSource() == dup_newDug.btn_exit) {
//                if (jr.isVisible()) {
//                    jr.setVisible(false);
//                    jr.dispose();
//                    jr = null;
//
//                }
//            }
//        } catch (NullPointerException npe) {
//            System.out.println(" btn_exit: " + npe);
//        }
//        if (evt.getSource() == new_drug.btn_exit) {
        pms_Home.clear_Grand_Pnl();
        // System.exit(0);
//        }

    }//GEN-LAST:event_btn_exitActionPerformed

    private void btn_cancel_allActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancel_allActionPerformed
        // TODO add your handling code here:
        btn_clearActionPerformed(evt);
        purchase_order.clear();
        lbl_counter.setText("");
        try {
            jspn_date1.setDate(date_Format.parse("12/12/12"));
        } catch (Exception ex) {
            System.out.println(ex);
        }
        System.out.println(jspn_date1.getDate());
        System.out.println(date_Format.format(jspn_date1.getDate()));
    }//GEN-LAST:event_btn_cancel_allActionPerformed

    public void set_listedView() {

        sugg = new ArrayList<>();
        for (int i = 0; i < count_done; i++) {
            sugg.add(i, purchase_order.get(i)[0] + "  , " + purchase_order.get(i)[3] + "PCs");
        }
        jlist_model.clear();
        for (int i = 0; i < sugg.size(); i++) {
            jlist_model.add(i, sugg.get(i));
            System.out.println(sugg.get(i) + "        **** .");
        }
        list_suggestion.setModel(jlist_model);
    }
    private void btn_viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewActionPerformed
        // TODO add your handling code here:
        set_listedView();
    }//GEN-LAST:event_btn_viewActionPerformed

    private void btn_nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nextActionPerformed
        // TODO add your handling code here:

        if (metric == 1) {
            if (count_running == count_done) {
                count_running += 1;
                lbl_counter.setText("new/" + count_done);
                btn_select_tbl.setEnabled(true);
                btn_clearActionPerformed(evt);
            }
            if (count_running < count_done) {
                count_running += 1;
                lbl_counter.setText(count_running + "/" + count_done);
                txt_drug_name.setText(purchase_order.get(count_running - 1)[1]);
                txt_group_name.setText(purchase_order.get(count_running - 1)[2]);
                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[3]);
                jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[4]));
            }
        }
        if (metric == 0) {
            if (count_running == count_done) {
                count_running += 1;
                lbl_counter.setText("new/" + count_done);
                btn_clearActionPerformed(evt);
            }
            if (count_running < count_done) {
                count_running += 1;
                lbl_counter.setText(count_running + "/" + count_done);
                txt_drug_name.setText(purchase_order.get(count_running - 1)[0]);
                txt_group_name.setText(purchase_order.get(count_running - 1)[1]);
                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[2]);
                txt_com_name.setText(purchase_order.get(count_running - 1)[3]);
            }
        }
        if (metric == 2) {
            if (count_running == count_done) {
                count_running += 1;
                lbl_counter.setText("new/" + count_done);
                btn_clearActionPerformed(evt);
            }
            if (count_running < count_done) {
                count_running += 1;
                lbl_counter.setText(count_running + "/" + count_done);
                txt_drug_name.setText(purchase_order.get(count_running - 1)[4]);
                txt_group_name.setText(purchase_order.get(count_running - 1)[5]);
                cmb_type.setSelectedItem(purchase_order.get(count_running - 1)[6]);
                txt_com_name.setText(purchase_order.get(count_running - 1)[7]);
                jspnr_quant.setValue(Integer.parseInt(purchase_order.get(count_running - 1)[1]));
                try {
                    jspn_date1.setDate(date_Format.parse(purchase_order.get(count_running - 1)[3]));
                } catch (Exception exp) {
                    System.out.println(exp);
                }
                txt_bill.setText(purchase_order.get(count_running - 1)[2]);
            }
            System.out.println("next > done: " + count_done + "  run: " + count_running);
        }
    }//GEN-LAST:event_btn_nextActionPerformed

    private void btn_select_tblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_select_tblActionPerformed
        // TODO add your handling code here:
        int row = pms_Home.tbl_Result_Exhibition.getSelectedRow();
        sign = false;

        if (row > -1 && pms_Home.lbl_tble_title.getText().startsWith("Drugs")) {
            drug_name = pms_Home.tbl_Result_Exhibition.getValueAt(row, 0).toString();
            drug_group = pms_Home.tbl_Result_Exhibition.getValueAt(row, 1).toString();
            com_name = pms_Home.tbl_Result_Exhibition.getValueAt(row, 2).toString();
            if (metric == 1) {
                temp = false;
                for (int i = 0; i < purchase_order.size(); i++) {
                    if (purchase_order.get(i)[1].contains(pms_Home.tbl_Result_Exhibition.getValueAt(row, 0).toString())) {
                        sign = true;
                        status_In_Time("Already Listed", 2300);
                        break;
                    }
                }
                if (sign == false && txt_com_name.getText().equals(com_name)) {
                    temp = true;
                    drug_id = drug_ids.get(row);
                    txt_drug_name.setText(drug_name);
                    txt_group_name.setText(drug_group);
                    cmb_type.setSelectedItem(pms_Home.tbl_Result_Exhibition.getValueAt(row, 3));
                }
                if (temp == false && sign == false) {
                    status_In_Time("Company Missmatch!", 2400);
                }
            }
            if (metric == 2) {
                temp = false;
                for (int i = 0; i < purchase_order.size(); i++) {
                    if (purchase_order.get(i)[4].contains(pms_Home.tbl_Result_Exhibition.getValueAt(row, 0).toString())) {
                        sign = true;
                        status_In_Time("Already Listed", 2300);
                        break;
                    }
                }
                if (sign == false && txt_com_name.getText().equals(com_name)) {
                    temp = true;
                    drug_id = drug_ids.get(row);
                    txt_drug_name.setText(drug_name);
                    txt_group_name.setText(drug_group);
                    cmb_type.setSelectedItem(pms_Home.tbl_Result_Exhibition.getValueAt(row, 3));
                }
                if (!txt_com_name.getText().equals(com_name)) {
                    status_In_Time("Company Missmatch!", 2400);
                }
                try {
                    query = "select mrp from drug_stock where drug_id=" + ids.get(row);
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        mrp = rs.getFloat(1);
                        rbtn_cash.setText("update mrp");
                        txt_mrp.setText("" + mrp);
                    }
                } catch (Exception s) {
                    System.out.println(s);
                }
            }
            if (metric == 3) {
                saleDrug_ID = drug_ids.get(row);
                drug_id = drug_ids.get(row);
                cmb_type.setSelectedItem(pms_Home.tbl_Result_Exhibition.getValueAt(row, 3));
                txt_com_name.setText(pms_Home.tbl_Result_Exhibition.getValueAt(row, 2).toString());
                txt_drug_name.setText(pms_Home.tbl_Result_Exhibition.getValueAt(row, 0).toString());
                txt_group_name.setText(pms_Home.tbl_Result_Exhibition.getValueAt(row, 1).toString());
                try {
                    available = Integer.parseInt(pms_Home.tbl_Result_Exhibition.getValueAt(row, 4).toString());
                    System.out.println("available: " + available);
                    jspn_date1.setDate(date_Format.parse(pms_Home.tbl_Result_Exhibition.getValueAt(row, 6).toString()));
                    lbl_mrp.setText(pms_Home.tbl_Result_Exhibition.getValueAt(row, 5).toString());
                } catch (Exception ex) {
                    System.out.println("btn_select " + ex);
                }
            }

        }
    }//GEN-LAST:event_btn_select_tblActionPerformed

    private void txt_emailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusGained
        // TODO add your handling code here:
        if (txt_email.getText().equals("email..")) {
            txt_email.setText("");
        }
    }//GEN-LAST:event_txt_emailFocusGained

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        // TODO add your handling code here:
        if (txt_email.getText().equals("")) {
            txt_email.setText("email..");
        }
    }//GEN-LAST:event_txt_emailFocusLost

    public void save_NewDrugs(java.awt.event.ActionEvent evt) {
        drug_id = 1;
        sign = false;
        try {
            pst = con.prepareStatement("insert into drug_stock  values(?,?,?,?,?,?,?)");
            for (int i = 0; i < purchase_order.size(); i++) {

                temp_query = "SELECT drug_id  FROM drug_stock  ORDER BY drug_id  DESC LIMIT 1;";
                temp_rs = st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    drug_id = temp_rs.getInt(1) + 1;
                }

                pst.setInt(1, drug_id);
                pst.setString(2, purchase_order.get(i)[0]);
                pst.setString(3, purchase_order.get(i)[1]);
                pst.setString(4, purchase_order.get(i)[2]);
                pst.setString(5, purchase_order.get(i)[3]);
                pst.setString(6, quantity);
                pst.setFloat(7, new Float("0.0"));
                pst.executeUpdate();
                sign = true;
            }
            if (sign == true) {
                pms_Home.get_Companies_Generic();
                btn_cancel_allActionPerformed(evt);
                status_In_Time("Saved", 1700);
                count_done = 0;
                count_running = 1;
                purchase_order.clear();
            }

        } catch (Exception exp) {
            System.out.println("save_NewDrugs    " + exp);
        }

    }

    private void btn_DONEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DONEActionPerformed
        // TODO add your handling code here:
        sign = false;
        if (count_done == 0) {
            status_In_Time("It's not", 2000);
        } else {
            if (metric == 0) {
                save_NewDrugs(evt);
            }
            if (metric == 1) {
                if (cmb_actions.getSelectedIndex() == 1) {
                    just_SaveOrder();
                }
            }
            if (metric == 3) {
                save_SaleRecord();
                System.out.println("passed method call");
            }
            if (metric == 2) {
                if (btn_DONE.getText().equals("Complete")) {
                    lbl_dick.setText(" <<");
                    jspn_date1.setDate(new Date());
                    lbl_date1.setText("Purchase Date: ");
                    btn_DONE.setText("Save");
                    jPanel6.setVisible(false);
                    jPanel3.setVisible(false);
//                 for(int i=0;i<jPanel6.getComponents().length;i++){
//                     jPanel6.getComponent(i).setVisible(false);
//                 }
                    sign = true;
                }
                if (btn_DONE.getText().equals("Save") && sign == false) {
                    save_PurchaseRecord();
                }
            }
        }
    }//GEN-LAST:event_btn_DONEActionPerformed

    public void save_SaleRecord() {
        int new_Sale_Id = 1;
        int left_amount = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();

            query = "SELECT sale_id  FROM  sales ORDER BY sale_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                new_Sale_Id = rs.getInt(1) + 1;
            }
            System.out.println("new sale id: " + new_Sale_Id);
            pst = con.prepareStatement("insert into sales values(?,?)");
            pst.setInt(1, new_Sale_Id);
            pst.setString(2, date_Format.format(new Date()));
//            pst.setInt(3, dep_id);
//            pst.setString(4, cmb_actions.getSelectedItem().toString());
//            pst.setString(5, date_Format.format(new Date()));
//            pst.setString(6, date1);
            pst.executeUpdate();

            pst = con.prepareStatement("insert into sale_detail values(?,?,?,?)");
            for (int i = 0; i < purchase_order.size(); i++) {
                left_amount = 0;
                pst.setInt(1, new_Sale_Id);
                pst.setInt(2, Integer.parseInt(purchase_order.get(i)[0]));
                pst.setInt(3, Integer.parseInt(purchase_order.get(i)[1]));
                pst.setInt(4, Integer.parseInt(purchase_order.get(i)[2]));
                pst.executeUpdate();
                left_amount = Integer.parseInt(purchase_order.get(i)[4]) - Integer.parseInt(purchase_order.get(i)[1]);
                System.out.println("## " + Integer.parseInt(purchase_order.get(i)[4]) + " -- " + Integer.parseInt(purchase_order.get(i)[1]) + " = " + left_amount);
                // query = "SELECT from stock_detail WHERE drug_id= '" + "  ";
                query = "UPDATE stock_detail SET left_amount = " + left_amount + " WHERE  drug_id= " + Integer.parseInt(purchase_order.get(i)[0]) + " AND exp_date='" + purchase_order.get(i)[3] + "' ";
                st.execute(query);
            }

//            query = "UPDATE sale_detail SET  drug_id= 4 WHERE sale_id=1";
//            st.execute(query);
            System.out.println("reached the end!");
            con.close();
            st.close();

        } catch (Exception ex) {
            System.out.println("ha ha> " + ex);
        }
        pms_Home.clear_Grand_Pnl();

    }

    public void just_SaveOrder() {
        int new_order_ID = 1;
        date1 = "";
        int due = 0;
        if (cmb_actions.getSelectedIndex() == 0) {
            date1 = date_Format.format(jspn_date1.getDate()) + " To " + date_Format.format(jspn_date2.getDate());;
        }

        if (count_done != 0) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
                st = con.createStatement();
                query = "SELECT pur_id  FROM purchase_event ORDER BY pur_id  DESC LIMIT 1;";
                rs = st.executeQuery(query);
                pur_id = 1;
                while (rs.next()) {
                    pur_id = rs.getInt(1) + 1;
                }
                pst = con.prepareStatement("insert into purchase_event values(?,?,?,?,?,?)");
                pst.setInt(1, pur_id);
                pst.setInt(2, dep_id);
                pst.setString(3, com_name);
                pst.setString(4, date1);
                pst.setString(5, "Ordered");
                pst.setInt(6, due);
                pst.executeUpdate();
                pst = con.prepareStatement("insert into purchase_detail values(?,?,?,?)");
                for (int i = 0; i < purchase_order.size(); i++) {
                    pst.setInt(1, pur_id);
                    pst.setInt(2, Integer.parseInt(purchase_order.get(i)[0]));
                    pst.setInt(3, Integer.parseInt(purchase_order.get(i)[4]));
                    pst.setInt(4, 0);
                    pst.executeUpdate();
                    status_In_Time("Saved", 2501);
                }
                con.close();
                st.close();
                pms_Home.get_Companies_Generic();
            } catch (Exception ex) {
                System.out.println("bbb> " + ex.getMessage());
            }
        }
    }

    public void save_PurchaseRecord() {
        int new_purchaseEvent = 1;
        int due = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();

            query = "SELECT pur_id  FROM purchase_event  ORDER BY pur_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                new_purchaseEvent = rs.getInt(1) + 1;
            }
            pst = con.prepareStatement("insert into purchase_event values(?,?,?,?,?,?)");
            pst.setInt(1, new_purchaseEvent);
            pst.setInt(2, dep_id);
            pst.setInt(3, -1);
            pst.setString(4, com_name);
            pst.setString(5, date_Format.format(jspn_date1.getDate()));
            pst.setInt(6, due);
            pst.executeUpdate();

            pst = con.prepareStatement("insert into purchase_detail values(?,?,?,?)");
            for (int i = 0; i < purchase_order.size(); i++) {
                pst.setInt(1, new_purchaseEvent);
                pst.setInt(2, Integer.parseInt(purchase_order.get(i)[0]));
                pst.setInt(3, Integer.parseInt(purchase_order.get(i)[1]));
                pst.setInt(4, Integer.parseInt(purchase_order.get(i)[2]));
                pst.executeUpdate();
            }
            System.out.println(purchase_order.get(0)[0] + " " + purchase_order.get(0)[1] + " " + purchase_order.get(0)[2] + " ");
            pst = con.prepareStatement("insert into stock_detail values(?,?,?,?)");
            for (int i = 0; i < purchase_order.size(); i++) {
                pst.setInt(1, Integer.parseInt(purchase_order.get(i)[0]));
                pst.setInt(2, new_purchaseEvent);
                pst.setInt(3, Integer.parseInt(purchase_order.get(i)[1]));
                pst.setString(4, purchase_order.get(i)[3]);
                pst.executeUpdate();
            }
//            con.close();
//            st.close();
            System.exit(0);
            pms_Home.get_Companies_Generic();
        } catch (Exception ex) {
            System.out.println("bbb ????? > " + ex);
        }
    }

    private void btn_calculatorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_calculatorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_calculatorActionPerformed

    private void btn_newActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_newActionPerformed
        // TODO add your handling code here:

        jspn_date1.setDate(new Date());
        System.out.println(date_Format.format(jspn_date1.getDate()));
        //  System.out.println(jspn_date1.getDateFormatString());
//        try {
//            if (jr.isVisible()) {
//                System.out.println("in if");
//            }
//        } catch (NullPointerException npe) {
//            jr = new JFrame();
//            jr.add((dup_newDug = new New_Drug(0)));
//            dup_newDug.jspnr_quant.setVisible(false);
//            jr.setUndecorated(true);
//
//            jr.setAlwaysOnTop(true);
//            jr.setLocation(200, 200);
//            jr.setVisible(true);
//            dup_newDug.jPanel5.setLocation(0, 400);
//            jr.setSize(400, 360);
//            System.out.println("in catch of btn_new");
//        }
    }//GEN-LAST:event_btn_newActionPerformed

    private void cmb_actionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_actionsActionPerformed
        // TODO add your handling code here:
        if (cmb_actions.getSelectedIndex() == 0) {
            for (int i = 0; i < jPanel4.getComponents().length; i++) {
                jPanel4.getComponents()[i].setVisible(true);
                lbl_date1.setText("deliver expectation from: ");
            }
        }
    }//GEN-LAST:event_cmb_actionsActionPerformed

    private void txt_group_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_group_nameFocusLost
        // TODO add your handling code here:
        jlist_model.clear();
    }//GEN-LAST:event_txt_group_nameFocusLost

    private void txt_com_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_com_nameFocusLost
        // TODO add your handling code here:
        jlist_model.clear();
    }//GEN-LAST:event_txt_com_nameFocusLost

    private void jspnr_quantStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jspnr_quantStateChanged
        // TODO add your handling code here:

        System.out.println(jspnr_quant.getValue());
    }//GEN-LAST:event_jspnr_quantStateChanged

    private void rbtn_cashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtn_cashActionPerformed
        // TODO add your handling code here:
        if (rbtn_cash.isSelected()) {
            txt_mrp.setEditable(true);
        } else {
            txt_mrp.setEditable(false);
        }
    }//GEN-LAST:event_rbtn_cashActionPerformed

    private void txt_mrpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_mrpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_mrpActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_DONE;
    public javax.swing.JButton btn_back;
    public javax.swing.JButton btn_calculator;
    public javax.swing.JButton btn_cancel_all;
    public javax.swing.JButton btn_clear;
    public javax.swing.JButton btn_done;
    public javax.swing.JButton btn_exclude;
    public javax.swing.JButton btn_exit;
    public javax.swing.JButton btn_new;
    public javax.swing.JButton btn_next;
    public javax.swing.JButton btn_select_tbl;
    public javax.swing.JButton btn_view;
    public javax.swing.JComboBox<String> cmb_actions;
    public javax.swing.JComboBox<String> cmb_type;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel4;
    public javax.swing.JPanel jPanel5;
    public javax.swing.JPanel jPanel6;
    public javax.swing.JPanel jPanel7;
    public javax.swing.JScrollPane jScrollPane2;
    public com.toedter.calendar.JSpinnerDateEditor jspn_date1;
    public com.toedter.calendar.JSpinnerDateEditor jspn_date2;
    public javax.swing.JSpinner jspnr_quant;
    public javax.swing.JLabel lbl_bill;
    public javax.swing.JLabel lbl_counter;
    public javax.swing.JLabel lbl_date1;
    public javax.swing.JLabel lbl_date2;
    public javax.swing.JLabel lbl_dick;
    public javax.swing.JLabel lbl_grand_tot;
    public javax.swing.JLabel lbl_mrp;
    public javax.swing.JLabel lbl_msg;
    public javax.swing.JLabel lbl_quant;
    public javax.swing.JLabel lbl_type;
    public javax.swing.JLabel lbl_warn;
    public javax.swing.JList<String> list_suggestion;
    public javax.swing.JRadioButton rbtn_cash;
    public javax.swing.JTextField txt_bill;
    public javax.swing.JTextField txt_com_name;
    public javax.swing.JTextField txt_drug_name;
    public javax.swing.JTextField txt_email;
    public javax.swing.JTextField txt_group_name;
    public javax.swing.JTextField txt_mrp;
    // End of variables declaration//GEN-END:variables

    public void set_Movable() {

        jfr.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        jfr.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                jfr.setLocation(jfr.getLocation().x + me.getX() - pX,
                        jfr.getLocation().y + me.getY() - pY);
            }
        });
    }

}
