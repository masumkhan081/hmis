package Pride;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author pddrgj3q
 */
public class PMS_Launcher {

    static JFrame jr;

    static New_Account new_acc;
    static Home pms_Home;
    static New_Depositor new_dep;
    static New_Drug new_drug;
    static New_Drug dup_newDug;
    static New_Sale new_sale;
    static PurchaseFrom_Order purchaseFromOrder;
    static String email, f_name, u_name, pass, contact, using_acc_type, new_acc_type, com_name, selected_sugg,
            drug_group, db_clmn_sugg, drug_name, drug_type, quantity, run_action;
    static int quant, dep_id, drug_id, sale_id, order_id, pur_id, pur_bill, grad_tot, available, running_Profile;
    static float mrp;
    static ArrayList<String> sugg;
    static ArrayList<String[]> arr_show;
    static ArrayList<Integer> ids = new ArrayList<>();
    static ArrayList<Integer> drug_ids = new ArrayList<>();
    static DefaultComboBoxModel cmb_model;
    static DateFormat date_Format;
    static SimpleDateFormat smpl_DateFormat;
    static java.awt.event.ActionEvent evt;
    static Connection con = null;
    static Statement st = null;
    static Statement temp_st = null;
    static ResultSet rs;
    static ResultSet temp_rs;
    static String query;
    static String temp_query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String db_Name = "HMIS";
    static String db_UserName = "root";
    static String db_Password = "";
    static boolean sign;
    static int temp_id;
    static DefaultListModel model;
    static SuggestionList suggestion;
    static ArrayList<String> Listed_sugg;

    public PMS_Launcher() {
        if (is_DB_Ready() == false) {
            make_UP_DB();
        }
    }

    public static void main(String[] args) {
        PMS_Launcher obj = new PMS_Launcher();
    }

    public void make_UP_DB() {
        try {

//            query = "CREATE DATABASE " + db_Name;
//            st = con.createStatement();
//            st.executeUpdate(query);
//            st.close();

            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            query = "CREATE TABLE drug_stock ("
                    + "drug_id int NOT NULL AUTO_INCREMENT,"
                    + "drug_name VARCHAR(50), "
                    + "generic VARCHAR(30),"
                    + "type VARCHAR(30),"
                    + "company VARCHAR(20),"
                    + "quantity_unit VARCHAR(15) ,"
                    + "mrp FLOAT(7,2) ,"
                    + "PRIMARY KEY (drug_id))";
            st.executeUpdate(query);

            query = "CREATE TABLE stock_detail ("
                    + "drug_id int,"
                    + "left_amount int,"
                    + "exp_date VARCHAR(20))";
            st.executeUpdate(query);

            query = "CREATE TABLE purchase_event ("
                    + "pur_id int NOT NULL AUTO_INCREMENT,"
                    + "dep_id INT NULL, "
                    + "company VARCHAR(20),"
                    + "date VARCHAR(20),"
                    + "status VARCHAR(20),"
                    + "due INT,"
                    + "PRIMARY KEY (pur_id))";
            st.executeUpdate(query);

            query = "CREATE TABLE purchase_detail ("
                    + "pur_id int ,"
                    + "drug_id INT ,"
                    + "quantity INT,"
                    + "total INT )";
            st.executeUpdate(query);

            query = "CREATE TABLE depositors("
                    + "dep_id int NOT NULL AUTO_INCREMENT,"
                    + "name VARCHAR(55),"
                    + "contact VARCHAR(45),"
                    + "email VARCHAR(45),"
                    + "com_name VARCHAR(55),"
                    + "PRIMARY KEY (dep_id))";
            st.executeUpdate(query);

            query = "CREATE TABLE sales("
                    + "sale_id int NOT NULL AUTO_INCREMENT,"
                    + "date_time  VARCHAR(25),"
                    + "PRIMARY KEY (sale_id))";
            st.executeUpdate(query);

            query = "CREATE TABLE sale_detail("
                    + "sale_id int ,"
                    + "drug_id int ,"
                    + "quantity int,"
                    + "bill int)";
            st.executeUpdate(query);

            query = "CREATE TABLE users ("
                    + "user_id int  NOT NULL AUTO_INCREMENT,"
                    + "full_name VARCHAR(50),"
                    + "user_name VARCHAR(20),"
                    + "contact VARCHAR(20),"
                    + "email VARCHAR(20),"
                    + "type VARCHAR(20),"
                    + "pass VARCHAR(20),"
                    + "PRIMARY KEY (user_id))";
            st.executeUpdate(query);

            query = "CREATE TABLE acvity_log ("
                    + "job_id int,"
                    + "user_id int,"
                    + "activity_description VARCHAR(25),"
                    + "date_time VARCHAR(25))";
            st.executeUpdate(query);

        } catch (Exception exp) {
            System.out.println("make_UP > " + exp);
        }
    }

    public boolean is_DB_Ready() {
        sign = false;
        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(url, db_UserName, db_Password);

            if (con == null) {
                System.out.println("###  Connection Came Out With Null");
            }
            rs = con.getMetaData().getCatalogs();
            sign = false;
            while (rs.next()) {
                //   System.out.println(rs.getString(1));
                if (db_Name.equals(rs.getString(1))) {
                    sign = true;
                    System.out.println("the database " + db_Name + " exists");
                    break;
                }
            }
        } catch (Exception exp) {
            System.out.println("from is db ready" + exp);
        }
        return sign;
    }

}
