package Reception;

import com.itextpdf.kernel.pdf.filters.DoNothingFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author Masum Khan
 */
public class File_Chooser extends javax.swing.JFrame implements ActionListener {
    
    static String file_Path;
    static int file_Type_Sign = 0;
    static String path;
    static int i = 0, j = 0;
    static int image_sign;
    
    public File_Chooser() {
        
        image_sign = i;
        initComponents();
         setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        fileChooser.addActionListener(this);
//        FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg");
//        file_Chooser_Frame.setFileFilter(filter);
        // file_Chooser_Frame.setFileSystemView(new Fil);
        fileChooser.setControlButtonsAreShown(true);
        
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //  fileChooser.showOpenDialog(null);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae) {
        
        if (ae.getActionCommand().equals("CancelSelection")) {
            
            System.out.println("Cancel");
            setVisible(false);
        }
        if (ae.getActionCommand().equals("ApproveSelection")) {
            
            try {
                path = fileChooser.getSelectedFile().getCanonicalPath();
                
                System.out.println(path);
                ReceptionModule.getPath_Save(path);
                setVisible(false);
            } catch (Exception ex) {
                System.out.println("reporting exp >> " + ex.getMessage());
            }
            System.out.println("pre " + image_sign);
//            if (image_sign == 0) {
//                nurse.set_Image(path);
//                dispose();
//            }
//            if (image_sign == 1) {
//                System.out.println(image_sign);
//                new_doc.set_Image(path);
//                dispose();
//            }
//            if (image_sign == 2) {
//                System.out.println(image_sign);
//                member_form.set_Image(path);
//                dispose();
//            }
        }

//                            pre.setBinaryStream(2, (InputStream) fin, (int) imgfile.length());
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTimeChooserDemo1 = new lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo();
        birthdayEvaluator1 = new com.toedter.calendar.demo.BirthdayEvaluator();
        birthdayEvaluator2 = new com.toedter.calendar.demo.BirthdayEvaluator();
        imageUtils1 = new com.lavantech.gui.comp.ImageUtils();
        fileChooser = new javax.swing.JFileChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));

        fileChooser.setApproveButtonText("open");
        fileChooser.setBackground(new java.awt.Color(153, 153, 255));
        fileChooser.setCurrentDirectory(new java.io.File("C:\\Users\\Masum Khan\\Desktop"));
        fileChooser.setFont(new java.awt.Font("MingLiU_HKSCS-ExtB", 1, 13)); // NOI18N
        fileChooser.setForeground(new java.awt.Color(51, 51, 51));
        fileChooser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileChooserActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fileChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(fileChooser, javax.swing.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fileChooserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileChooserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fileChooserActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator1;
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator2;
    private javax.swing.JFileChooser fileChooser;
    private com.lavantech.gui.comp.ImageUtils imageUtils1;
    private lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo jTimeChooserDemo1;
    // End of variables declaration//GEN-END:variables

}
