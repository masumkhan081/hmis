package Reception;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.Barcode128;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javafx.stage.FileChooser;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JSpinner;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import javax.swing.JSpinner.DateEditor;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author pddrgj3q
 */
public class ReceptionModule extends javax.swing.JFrame implements ActionListener {

    static ViewDocSchedule view_schedule;
    static BedDetail beddetail;
    static TestDetail testdetail;
    static DefaultComboBoxModel cmb_model;
    static DefaultListModel jlist_model;
    static ReceptionModule reception;
    static int doc_id, pat_id, app_id, bed_id, num_seat, id, bed_vacancy, case_id, pX, pY;
    static Connection con = null;
    static Statement st = null;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static ResultSet temp_rs;
    static Statement temp_st = null;
    static String temp_query;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "HMIS";
    static String db_userName = "root";
    static String db_password = "";
    static ArrayList<String> sugg;
    static SimpleDateFormat simpleDateFormat;
    static DateFormat date_Format;
    public ButtonGroup btn_g;
    static String name, email, contact, nid, dob, doj, p_add, c_add, gender, desg, age, dept_name, receipt_Code, pres, family, bed_type, pat_type, dept;
    public boolean changes, old_patient, sign, pat_selection, doc_selection, bed_selection;
    private int module_user_ID;
    static JFileChooser fileChooser;
    String module_use_pass, module_user_name;
    static String printToBePDFName;
    ArrayList<String[]> pat_Name_Contacts;
    static ArrayList<Integer> ids;
    static java.awt.event.ActionEvent evt;

    public ReceptionModule() {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        //   setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        btn_g = new ButtonGroup();
        btn_g.add(R_btn_male);
        btn_g.add(R_btn_fem);
        btn_g.add(R_btn_other);
        jspn_dob.setEditor(new JSpinner.DateEditor(jspn_dob, "dd/MM/yy"));
        jspn_dob.setDate(new Date());
        date_Format = new SimpleDateFormat("dd/MM/yy");
        jspn_app_date.setValue(new Date(System.currentTimeMillis()));
        ((JSpinner.DateEditor) jspn_app_date.getEditor()).getFormat().applyPattern("dd.MM.yy HH:mm");

        btn_sel_exis_pat.setEnabled(false);
        lbl_any_update.setVisible(false);
        r_btn_take_chngs.setVisible(false);

        ids = new ArrayList<>();
        bed_selection = false;
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
        setConnection();
        get_Patients();
        set_Department_Names();
        set_Test_Types();
        set_bed_types();
        set_bedBy_Depts();
        set_Service_Type();
        // set_Frame_to_Initial(false);

        DocumentListener documentListener = new DocumentListener() {
            public void changedUpdate(DocumentEvent documentEvent) {

                btn_searchActionPerformed(evt);
            }

            public void insertUpdate(DocumentEvent documentEvent) {
                btn_searchActionPerformed(evt);
            }

            public void removeUpdate(DocumentEvent documentEvent) {
                btn_searchActionPerformed(evt);
            }
        };
        txt_search_content.getDocument().addDocumentListener(documentListener);

        getPath_Save("");

    }

    public void setConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
        } catch (Exception exp) {
            System.out.println(exp);
        }
    }

    public void get_Patients() {
        //mnbv
        String str[];
        pat_Name_Contacts = new ArrayList<>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT DISTINCT pat_id FROM patients";
            rs = st.executeQuery(query);
            while (rs.next()) {
                str = new String[3];
                id = rs.getInt("pat_id");
                System.out.println("id:  ? " + id);
                str[0] = String.valueOf(id);
                temp_query = "SELECT name, contact FROM patients WHERE pat_id ='" + id + "'";
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    str[1] = temp_rs.getString("name");
                    str[2] = temp_rs.getString("contact");
                }
                pat_Name_Contacts.add(str);
                System.out.println(str[0] + "   ?? " + str[1]);
            }
        } catch (Exception exp) {
            System.out.println(exp + " get_Patients");
        }

    }

    public void set_Frame_to_Initial(boolean bool) {

        //  cmb_search_By.setEnabled(bool);
        txt_search_content.setEnabled(bool);
        btn_search.setEnabled(bool);
        btn_update.setVisible(bool);
        txt_conf_pass.setVisible(bool);
        btn_Confirm_app.setEnabled(bool);
        btn_can_att.setEnabled(bool);

        Component[] com = jpnl_functions.getComponents();
        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }

        com = jpnl_appointment.getComponents();

        for (int a = 0; a < com.length; a++) {
            com[a].setEnabled(bool);
        }
        if (bool == false) {
            txt_conf_pass.setVisible(bool);
            btn_update.setVisible(bool);
        }
        if (bool == true) {
            txt_u_name.setVisible(false);
            txt_pass.setVisible(false);
            btn_login_out.setText("Out");
            btn_update.setVisible(true);
        }

    }

    public void set_Service_Type() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT DISTINCT type from services ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_SerByType.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_SerByType.setSelectedIndex(-1);
    }

    public void set_bedBy_Depts() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT DISTINCT dept from beds ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_bed_by_dept.setModel(cmb_model);
            cmb_pat_by_dept.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_bed_by_dept.setSelectedIndex(-1);
    }

    public void set_Test_Types() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT DISTINCT type from med_tests ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_test_type.setModel(cmb_model);

            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_test_type.setSelectedIndex(-1);

    }

    public void acknowledgement_Or_Warning(String warning_Msg, int time) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (time == 1540) {
                    lbl_last.setText(warning_Msg);
                }
                if (warning_Msg.equals("Doctor Selection!")) {

                    lbl_last.setText("");
                }
                if (time == 1100) {
                    txt_search_content.setBackground(new Color(26, 54, 54));
                    txt_search_content.setText("");
                }

                if (time == 1350) {
                    lbl_msg.setText("");
                }
                if (time == 1300 || time == 1600) {
                    lbl_last.setText("");
                }
                if (time == 1400) {
                    lbl_last.setText("");
                }

            }
        }).start();

        if (time == 1540) {
            lbl_last.setText(warning_Msg);
        }
        if (warning_Msg.equals("Doctor Selection!")) {
            lbl_last.setText(warning_Msg);
        }
        if (time == 1100) {
            txt_search_content.setBackground(Color.RED);
            txt_search_content.setText("contact no !");
        }
        if (time == 1300 || time == 1600) {
            lbl_last.setText(warning_Msg);
        }
        if (time == 1350) {
            lbl_msg.setText(warning_Msg);
        }
        if (time == 1400) {
            lbl_last.setText(warning_Msg);
        }
    }

    public void set_Department_Names() {
        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT DISTINCT dept from doctors ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_doc_by_dept.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_doc_by_dept.setSelectedIndex(-1);
    }

    public void set_Warning(String warning_Msg, int time) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (time == 1650) {
                    lbl_missmtch.setText("");
                }

                lbl_warning.setText("");
            }
        }).start();

        if (time == 1650) {
            lbl_missmtch.setText(warning_Msg);
        } else {
            lbl_warning.setText(warning_Msg);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lbl_doc_confirmation = new javax.swing.JLabel();
        lbl_pat_confirmation = new javax.swing.JLabel();
        lbl_last = new javax.swing.JLabel();
        jpnl_appointment = new javax.swing.JPanel();
        R_btn_male = new javax.swing.JRadioButton();
        R_btn_fem = new javax.swing.JRadioButton();
        txt_pat_name = new javax.swing.JTextField();
        txt_contact = new javax.swing.JTextField();
        txt_email = new javax.swing.JTextField();
        txt_fam_mem = new javax.swing.JTextField();
        txt_add = new javax.swing.JTextField();
        R_btn_other = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        txt_nid = new javax.swing.JTextField();
        btn_clear = new javax.swing.JButton();
        btn_save_pat_per = new javax.swing.JButton();
        lbl_msg = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btn_get_sel_doc = new javax.swing.JButton();
        btn_sel_exis_pat = new javax.swing.JButton();
        chk_old_pat = new javax.swing.JCheckBox();
        r_btn_take_chngs = new javax.swing.JRadioButton();
        lbl_any_update = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jspn_app_date = new com.toedter.calendar.JSpinnerDateEditor();
        chk_payment = new javax.swing.JRadioButton();
        txt_ammount = new javax.swing.JTextField();
        jspn_dob = new com.toedter.calendar.JSpinnerDateEditor();
        btn_can_att = new javax.swing.JButton();
        btn_Confirm_app = new javax.swing.JButton();
        jpnl_functions = new javax.swing.JPanel();
        btn_app_to_be = new javax.swing.JButton();
        cmb_doc_by_dept = new javax.swing.JComboBox<>();
        btn_show_sch = new javax.swing.JButton();
        btn_Services = new javax.swing.JButton();
        btn_run_in_pat = new javax.swing.JButton();
        btn_bed_status = new javax.swing.JButton();
        btn_doctors = new javax.swing.JButton();
        btn_view_ser_detail = new javax.swing.JButton();
        btn_tests = new javax.swing.JButton();
        cmb_bed_by_type = new javax.swing.JComboBox<>();
        btn_bed_detail = new javax.swing.JButton();
        btn_testDetail = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        cmb_test_type = new javax.swing.JComboBox<>();
        cmb_SerByType = new javax.swing.JComboBox<>();
        cmb_pat_by_dept = new javax.swing.JComboBox<>();
        cmb_bed_by_dept = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        exit = new javax.swing.JButton();
        btn_minn = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        btn_update = new javax.swing.JButton();
        btn_login_out = new javax.swing.JButton();
        lbl_missmtch = new javax.swing.JLabel();
        txt_conf_pass = new javax.swing.JTextField();
        txt_pass = new javax.swing.JTextField();
        txt_u_name = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        txt_search_content = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        lbl_warning = new javax.swing.JLabel();
        chk_pat_name = new javax.swing.JCheckBox();
        chk_pat_con = new javax.swing.JCheckBox();
        jPanel7 = new javax.swing.JPanel();
        lbl_tbl_title = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        btn_print_appList = new javax.swing.JButton();

        jButton5.setText("jButton5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setMaximumSize(new java.awt.Dimension(1351, 715));
        jPanel1.setMinimumSize(new java.awt.Dimension(1351, 715));
        jPanel1.setPreferredSize(new java.awt.Dimension(1351, 715));

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));

        lbl_doc_confirmation.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_doc_confirmation.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_doc_confirmation.setMaximumSize(new java.awt.Dimension(238, 16));
        lbl_doc_confirmation.setMinimumSize(new java.awt.Dimension(238, 16));
        lbl_doc_confirmation.setPreferredSize(new java.awt.Dimension(238, 16));

        lbl_pat_confirmation.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_pat_confirmation.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_pat_confirmation.setMaximumSize(new java.awt.Dimension(238, 16));
        lbl_pat_confirmation.setMinimumSize(new java.awt.Dimension(238, 16));
        lbl_pat_confirmation.setPreferredSize(new java.awt.Dimension(238, 16));

        lbl_last.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_last.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_last.setMaximumSize(new java.awt.Dimension(238, 16));
        lbl_last.setMinimumSize(new java.awt.Dimension(238, 16));
        lbl_last.setPreferredSize(new java.awt.Dimension(238, 16));

        jpnl_appointment.setBackground(new java.awt.Color(204, 255, 204));
        jpnl_appointment.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Patient Personal", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("DejaVu Sans", 1, 12))); // NOI18N

        R_btn_male.setBackground(new java.awt.Color(204, 255, 204));
        R_btn_male.setFont(new java.awt.Font("Yu Mincho", 1, 14)); // NOI18N
        R_btn_male.setText("Male");
        R_btn_male.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        R_btn_fem.setBackground(new java.awt.Color(204, 255, 204));
        R_btn_fem.setFont(new java.awt.Font("Yu Mincho", 1, 14)); // NOI18N
        R_btn_fem.setText("Female");
        R_btn_fem.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txt_pat_name.setBackground(new java.awt.Color(204, 255, 204));
        txt_pat_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_pat_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_pat_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Patient Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        txt_pat_name.setMaximumSize(new java.awt.Dimension(350, 42));
        txt_pat_name.setMinimumSize(new java.awt.Dimension(350, 42));
        txt_pat_name.setPreferredSize(new java.awt.Dimension(350, 42));

        txt_contact.setBackground(new java.awt.Color(204, 255, 204));
        txt_contact.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_contact.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_contact.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Contact:", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        txt_contact.setMaximumSize(new java.awt.Dimension(350, 42));
        txt_contact.setMinimumSize(new java.awt.Dimension(350, 42));
        txt_contact.setPreferredSize(new java.awt.Dimension(350, 42));

        txt_email.setBackground(new java.awt.Color(204, 255, 204));
        txt_email.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_email.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Email:", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        txt_email.setMaximumSize(new java.awt.Dimension(350, 42));
        txt_email.setMinimumSize(new java.awt.Dimension(350, 42));
        txt_email.setPreferredSize(new java.awt.Dimension(350, 42));

        txt_fam_mem.setBackground(new java.awt.Color(204, 255, 204));
        txt_fam_mem.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_fam_mem.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_fam_mem.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Father/Husband", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        txt_add.setBackground(new java.awt.Color(204, 255, 204));
        txt_add.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_add.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_add.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Address:", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        txt_add.setMaximumSize(new java.awt.Dimension(350, 42));
        txt_add.setMinimumSize(new java.awt.Dimension(350, 42));
        txt_add.setPreferredSize(new java.awt.Dimension(350, 42));
        txt_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_addActionPerformed(evt);
            }
        });

        R_btn_other.setBackground(new java.awt.Color(204, 255, 204));
        R_btn_other.setFont(new java.awt.Font("Yu Mincho", 1, 14)); // NOI18N
        R_btn_other.setText("Others");
        R_btn_other.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("DOB:");

        txt_nid.setBackground(new java.awt.Color(204, 255, 204));
        txt_nid.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txt_nid.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_nid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)));

        btn_clear.setBackground(new java.awt.Color(204, 204, 255));
        btn_clear.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn_clear.setText("Clear");
        btn_clear.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0)));
        btn_clear.setContentAreaFilled(false);
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        btn_save_pat_per.setBackground(new java.awt.Color(204, 255, 153));
        btn_save_pat_per.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn_save_pat_per.setText("Take The Patient ");
        btn_save_pat_per.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_save_pat_per.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_save_pat_perActionPerformed(evt);
            }
        });

        lbl_msg.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        lbl_msg.setForeground(new java.awt.Color(51, 0, 0));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel4.setText("NID:");

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));

        btn_get_sel_doc.setBackground(new java.awt.Color(204, 255, 153));
        btn_get_sel_doc.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_get_sel_doc.setText("Get Selected Doc");
        btn_get_sel_doc.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_get_sel_doc.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btn_get_sel_doc.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_get_sel_doc.setMaximumSize(new java.awt.Dimension(165, 24));
        btn_get_sel_doc.setMinimumSize(new java.awt.Dimension(165, 24));
        btn_get_sel_doc.setPreferredSize(new java.awt.Dimension(165, 24));
        btn_get_sel_doc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_get_sel_docActionPerformed(evt);
            }
        });

        btn_sel_exis_pat.setBackground(new java.awt.Color(204, 255, 153));
        btn_sel_exis_pat.setFont(new java.awt.Font("Source Sans Pro Black", 1, 12)); // NOI18N
        btn_sel_exis_pat.setText("Selected Existing Patient");
        btn_sel_exis_pat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        btn_sel_exis_pat.setMaximumSize(new java.awt.Dimension(165, 24));
        btn_sel_exis_pat.setMinimumSize(new java.awt.Dimension(165, 24));
        btn_sel_exis_pat.setPreferredSize(new java.awt.Dimension(165, 24));
        btn_sel_exis_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sel_exis_patActionPerformed(evt);
            }
        });

        chk_old_pat.setBackground(new java.awt.Color(204, 255, 204));
        chk_old_pat.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        chk_old_pat.setText("Old Patient");
        chk_old_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_old_patActionPerformed(evt);
            }
        });

        r_btn_take_chngs.setBackground(new java.awt.Color(204, 255, 204));
        r_btn_take_chngs.setText("Take changes");
        r_btn_take_chngs.setMaximumSize(new java.awt.Dimension(120, 13));
        r_btn_take_chngs.setMinimumSize(new java.awt.Dimension(120, 13));
        r_btn_take_chngs.setPreferredSize(new java.awt.Dimension(120, 13));
        r_btn_take_chngs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                r_btn_take_chngsActionPerformed(evt);
            }
        });

        lbl_any_update.setText("any update ?");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lbl_any_update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(r_btn_take_chngs, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(chk_old_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_sel_exis_pat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_get_sel_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(btn_get_sel_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(chk_old_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_sel_exis_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(r_btn_take_chngs, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_any_update, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("App Date:");

        jspn_app_date.setBackground(new java.awt.Color(15, 38, 38));
        jspn_app_date.setBorder(null);
        jspn_app_date.setForeground(new java.awt.Color(255, 204, 102));
        jspn_app_date.setModel(new javax.swing.SpinnerDateModel());
        jspn_app_date.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jspn_app_date.setMaximumSize(new java.awt.Dimension(126, 16));

        chk_payment.setBackground(new java.awt.Color(204, 255, 204));
        chk_payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_paymentActionPerformed(evt);
            }
        });

        txt_ammount.setEditable(false);
        txt_ammount.setBackground(new java.awt.Color(204, 255, 204));
        txt_ammount.setFont(new java.awt.Font("Meiryo", 0, 13)); // NOI18N
        txt_ammount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_ammount.setText("payment");
        txt_ammount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_ammount.setMaximumSize(new java.awt.Dimension(90, 29));
        txt_ammount.setMinimumSize(new java.awt.Dimension(90, 29));
        txt_ammount.setPreferredSize(new java.awt.Dimension(90, 29));
        txt_ammount.setSelectionColor(new java.awt.Color(51, 0, 0));
        txt_ammount.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_ammountFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_ammountFocusLost(evt);
            }
        });
        txt_ammount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ammountActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(chk_payment, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txt_ammount, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jspn_app_date, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jspn_app_date, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_ammount, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chk_payment, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jspn_dob.setBackground(new java.awt.Color(15, 38, 38));
        jspn_dob.setBorder(null);
        jspn_dob.setForeground(new java.awt.Color(255, 204, 102));
        jspn_dob.setModel(new javax.swing.SpinnerDateModel());
        jspn_dob.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jspn_dob.setMaximumSize(new java.awt.Dimension(126, 16));

        javax.swing.GroupLayout jpnl_appointmentLayout = new javax.swing.GroupLayout(jpnl_appointment);
        jpnl_appointment.setLayout(jpnl_appointmentLayout);
        jpnl_appointmentLayout.setHorizontalGroup(
            jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_appointmentLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_appointmentLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jspn_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(10, 10, 10)))
                        .addGap(111, 111, 111)
                        .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_save_pat_per, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_fam_mem, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(R_btn_male, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(R_btn_other, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(R_btn_fem, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_appointmentLayout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(128, 128, 128))
                                    .addComponent(txt_nid)
                                    .addComponent(lbl_msg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_email, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_contact, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_add, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jpnl_appointmentLayout.setVerticalGroup(
            jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_appointmentLayout.createSequentialGroup()
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(txt_pat_name, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(txt_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(txt_add, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_fam_mem, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addComponent(R_btn_male, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(R_btn_fem, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txt_nid, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(3, 3, 3)
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(R_btn_other, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jpnl_appointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(btn_save_pat_per, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnl_appointmentLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jspn_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        btn_can_att.setBackground(new java.awt.Color(4, 21, 21));
        btn_can_att.setFont(new java.awt.Font("DokChampa", 1, 12)); // NOI18N
        btn_can_att.setForeground(new java.awt.Color(255, 204, 102));
        btn_can_att.setText("Cancel Attempt");
        btn_can_att.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_can_att.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_can_attActionPerformed(evt);
            }
        });

        btn_Confirm_app.setBackground(new java.awt.Color(5, 27, 27));
        btn_Confirm_app.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_Confirm_app.setForeground(new java.awt.Color(255, 204, 102));
        btn_Confirm_app.setText("Confirm App & Print Receipt");
        btn_Confirm_app.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Confirm_app.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btn_Confirm_app.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btn_Confirm_app.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Confirm_appActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btn_Confirm_app))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lbl_pat_confirmation, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl_last, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl_doc_confirmation, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                                .addComponent(btn_can_att, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jpnl_appointment, javax.swing.GroupLayout.PREFERRED_SIZE, 419, Short.MAX_VALUE))
                .addGap(8, 8, 8))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btn_can_att)
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbl_doc_confirmation, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(lbl_pat_confirmation, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(lbl_last, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(btn_Confirm_app, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnl_appointment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jpnl_functions.setBackground(new java.awt.Color(3, 16, 16));
        jpnl_functions.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 3, new java.awt.Color(0, 102, 102)));

        btn_app_to_be.setBackground(new java.awt.Color(204, 255, 204));
        btn_app_to_be.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_app_to_be.setForeground(new java.awt.Color(204, 255, 204));
        btn_app_to_be.setText("App.. To Be");
        btn_app_to_be.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_app_to_be.setContentAreaFilled(false);
        btn_app_to_be.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btn_app_to_be.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_app_to_beActionPerformed(evt);
            }
        });

        cmb_doc_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_doc_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_doc_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_doc_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept.", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_doc_by_dept.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_doc_by_dept.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_doc_by_dept.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_doc_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_doc_by_deptActionPerformed(evt);
            }
        });

        btn_show_sch.setBackground(new java.awt.Color(204, 255, 204));
        btn_show_sch.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_show_sch.setForeground(new java.awt.Color(204, 255, 204));
        btn_show_sch.setText("Detail & Schedule");
        btn_show_sch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_show_sch.setContentAreaFilled(false);
        btn_show_sch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_show_schActionPerformed(evt);
            }
        });

        btn_Services.setBackground(new java.awt.Color(204, 255, 204));
        btn_Services.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        btn_Services.setForeground(new java.awt.Color(204, 255, 204));
        btn_Services.setText("Medi. Services ");
        btn_Services.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_Services.setContentAreaFilled(false);
        btn_Services.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ServicesActionPerformed(evt);
            }
        });

        btn_run_in_pat.setBackground(new java.awt.Color(204, 255, 204));
        btn_run_in_pat.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_run_in_pat.setForeground(new java.awt.Color(204, 255, 204));
        btn_run_in_pat.setText("Running In Patients");
        btn_run_in_pat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_run_in_pat.setContentAreaFilled(false);
        btn_run_in_pat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_run_in_patActionPerformed(evt);
            }
        });

        btn_bed_status.setBackground(new java.awt.Color(2, 21, 21));
        btn_bed_status.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_bed_status.setForeground(new java.awt.Color(204, 255, 204));
        btn_bed_status.setText("Beds And Cabins");
        btn_bed_status.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_bed_status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bed_statusActionPerformed(evt);
            }
        });

        btn_doctors.setBackground(new java.awt.Color(204, 255, 204));
        btn_doctors.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_doctors.setForeground(new java.awt.Color(204, 255, 204));
        btn_doctors.setText("Doctors");
        btn_doctors.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_doctors.setContentAreaFilled(false);
        btn_doctors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_doctorsActionPerformed(evt);
            }
        });

        btn_view_ser_detail.setBackground(new java.awt.Color(204, 255, 204));
        btn_view_ser_detail.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        btn_view_ser_detail.setForeground(new java.awt.Color(204, 255, 204));
        btn_view_ser_detail.setText("Service Detail");
        btn_view_ser_detail.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_view_ser_detail.setContentAreaFilled(false);
        btn_view_ser_detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_ser_detailActionPerformed(evt);
            }
        });

        btn_tests.setBackground(new java.awt.Color(204, 255, 204));
        btn_tests.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        btn_tests.setForeground(new java.awt.Color(204, 255, 204));
        btn_tests.setText("pathology tests");
        btn_tests.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_tests.setContentAreaFilled(false);
        btn_tests.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_testsActionPerformed(evt);
            }
        });

        cmb_bed_by_type.setBackground(new java.awt.Color(2, 25, 25));
        cmb_bed_by_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_bed_by_type.setForeground(new java.awt.Color(204, 255, 204));
        cmb_bed_by_type.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_bed_by_type.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_type.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_type.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_bed_by_typeActionPerformed(evt);
            }
        });

        btn_bed_detail.setBackground(new java.awt.Color(2, 21, 21));
        btn_bed_detail.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_bed_detail.setForeground(new java.awt.Color(204, 255, 204));
        btn_bed_detail.setText("Bed Detail ");
        btn_bed_detail.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_bed_detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bed_detailActionPerformed(evt);
            }
        });

        btn_testDetail.setBackground(new java.awt.Color(2, 21, 21));
        btn_testDetail.setFont(new java.awt.Font("Carlito", 1, 14)); // NOI18N
        btn_testDetail.setForeground(new java.awt.Color(204, 255, 204));
        btn_testDetail.setText("Test Detail");
        btn_testDetail.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        btn_testDetail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_testDetailActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(2, 21, 21));
        jButton6.setFont(new java.awt.Font("Carlito", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(204, 255, 204));
        jButton6.setText("Running Tests");
        jButton6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));

        cmb_test_type.setBackground(new java.awt.Color(2, 25, 25));
        cmb_test_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_test_type.setForeground(new java.awt.Color(204, 255, 204));
        cmb_test_type.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_test_type.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_test_type.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_test_type.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_test_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_test_typeActionPerformed(evt);
            }
        });

        cmb_SerByType.setBackground(new java.awt.Color(2, 25, 25));
        cmb_SerByType.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_SerByType.setForeground(new java.awt.Color(204, 255, 204));
        cmb_SerByType.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "by type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_SerByType.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_SerByType.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_SerByType.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_SerByType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_SerByTypeActionPerformed(evt);
            }
        });

        cmb_pat_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_pat_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_pat_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_pat_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept.", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_pat_by_dept.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_pat_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_pat_by_deptActionPerformed(evt);
            }
        });

        cmb_bed_by_dept.setBackground(new java.awt.Color(2, 25, 25));
        cmb_bed_by_dept.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_bed_by_dept.setForeground(new java.awt.Color(204, 255, 204));
        cmb_bed_by_dept.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "by dept", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(204, 255, 204))); // NOI18N
        cmb_bed_by_dept.setMaximumSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_dept.setMinimumSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_dept.setPreferredSize(new java.awt.Dimension(135, 27));
        cmb_bed_by_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_bed_by_deptActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpnl_functionsLayout = new javax.swing.GroupLayout(jpnl_functions);
        jpnl_functions.setLayout(jpnl_functionsLayout);
        jpnl_functionsLayout.setHorizontalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnl_functionsLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_view_ser_detail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_show_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_doctors, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_Services, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_app_to_be, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_bed_status, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmb_SerByType, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_tests, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_run_in_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpnl_functionsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(cmb_bed_by_type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btn_bed_detail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpnl_functionsLayout.createSequentialGroup()
                                .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cmb_bed_by_dept, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmb_doc_by_dept, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmb_pat_by_dept, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpnl_functionsLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_testDetail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmb_test_type, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(21, 21, 21))
        );
        jpnl_functionsLayout.setVerticalGroup(
            jpnl_functionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_functionsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_doctors, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_doc_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(btn_show_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(btn_bed_status, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_bed_by_type, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_bed_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(btn_bed_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_run_in_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_pat_by_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(btn_app_to_be, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(btn_Services, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_SerByType, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(btn_view_ser_detail, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(btn_tests, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(cmb_test_type, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(btn_testDetail, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(32, 12, 2));
        jPanel4.setBorder(new javax.swing.border.MatteBorder(null));
        jPanel4.setForeground(new java.awt.Color(153, 153, 255));
        jPanel4.setMaximumSize(new java.awt.Dimension(1313, 20));
        jPanel4.setMinimumSize(new java.awt.Dimension(1313, 20));
        jPanel4.setPreferredSize(new java.awt.Dimension(1313, 20));

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 255));
        jLabel3.setText("Receiption  Module");

        exit.setBackground(new java.awt.Color(102, 51, 0));
        exit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        exit.setForeground(new java.awt.Color(255, 255, 204));
        exit.setText("Exit");
        exit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        exit.setPreferredSize(new java.awt.Dimension(30, 18));
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        btn_minn.setBackground(new java.awt.Color(102, 51, 0));
        btn_minn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_minn.setForeground(new java.awt.Color(255, 255, 204));
        btn_minn.setText("Min");
        btn_minn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_minn.setPreferredSize(new java.awt.Dimension(30, 18));
        btn_minn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_minnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_minn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn_minn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel6.setBackground(new java.awt.Color(204, 255, 204));
        jPanel6.setMaximumSize(new java.awt.Dimension(854, 61));
        jPanel6.setMinimumSize(new java.awt.Dimension(854, 61));
        jPanel6.setPreferredSize(new java.awt.Dimension(854, 61));

        btn_update.setBackground(new java.awt.Color(204, 255, 204));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_update.setText("Edit");
        btn_update.setActionCommand("Log  Out");
        btn_update.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_update.setContentAreaFilled(false);
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        btn_login_out.setBackground(new java.awt.Color(204, 255, 204));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_login_out.setText("In");
        btn_login_out.setActionCommand("Log  Out");
        btn_login_out.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        lbl_missmtch.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_missmtch.setForeground(new java.awt.Color(153, 51, 0));
        lbl_missmtch.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txt_conf_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_conf_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_conf_pass.setText("confirm pass");
        txt_conf_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_conf_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_conf_passFocusLost(evt);
            }
        });

        txt_pass.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_pass.setText("pass..");
        txt_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_passFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passFocusLost(evt);
            }
        });

        txt_u_name.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });
        txt_u_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_u_nameActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(204, 255, 204));

        txt_search_content.setBackground(new java.awt.Color(204, 255, 204));
        txt_search_content.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_search_content.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_search_content.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_search_content.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_contentActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(1, 34, 34));
        btn_search.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        btn_search.setForeground(new java.awt.Color(204, 204, 255));
        btn_search.setText("Search");
        btn_search.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        lbl_warning.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        chk_pat_name.setBackground(new java.awt.Color(204, 255, 204));
        chk_pat_name.setText("Patient Name");
        chk_pat_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_pat_nameActionPerformed(evt);
            }
        });

        chk_pat_con.setBackground(new java.awt.Color(204, 255, 204));
        chk_pat_con.setText("Patient Contact");
        chk_pat_con.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_pat_conActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(507, 507, 507)
                .addComponent(lbl_warning, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
                .addGap(78, 78, 78))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(chk_pat_name, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                    .addComponent(chk_pat_con, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(chk_pat_name)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chk_pat_con)
                    .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                            .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_missmtch, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_missmtch, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel7.setBackground(new java.awt.Color(4, 25, 25));
        jPanel7.setForeground(new java.awt.Color(255, 255, 153));

        lbl_tbl_title.setBackground(new java.awt.Color(204, 204, 255));
        lbl_tbl_title.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        lbl_tbl_title.setForeground(new java.awt.Color(204, 255, 204));
        lbl_tbl_title.setText("Table title");
        lbl_tbl_title.setMaximumSize(new java.awt.Dimension(662, 17));
        lbl_tbl_title.setMinimumSize(new java.awt.Dimension(662, 17));
        lbl_tbl_title.setPreferredSize(new java.awt.Dimension(662, 17));

        tbl_Result_Exhibition.setBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(255, 255, 153));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 51, 51));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setRowHeight(25);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(204, 255, 153));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(153, 51, 0));
        jScrollPane1.setViewportView(tbl_Result_Exhibition);

        btn_print_appList.setBackground(new java.awt.Color(4, 21, 21));
        btn_print_appList.setFont(new java.awt.Font("DokChampa", 1, 12)); // NOI18N
        btn_print_appList.setForeground(new java.awt.Color(255, 204, 102));
        btn_print_appList.setText("Print Appointment List");
        btn_print_appList.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btn_print_appList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_print_appListActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 754, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_print_appList, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_print_appList))
                .addGap(0, 0, 0)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 914, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jpnl_functions, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 1352, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpnl_functions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1352, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 700, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_search_contentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_contentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_contentActionPerformed
    public void view_RunningPatients(String q) {
        query = q;
        ResultSet temp_rs;
        ids = new ArrayList();
        String[] coloumn = new String[6];
        String[] data = new String[6];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "Pat Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Adm. Date";
        coloumn[3] = "Room num";
        coloumn[4] = "Floor";
        coloumn[5] = "Type";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                case_id = rs.getInt("case_id");
                System.out.println("case id: " + case_id);
                pat_id = rs.getInt("pat_id");
                System.out.println("pat id: " + pat_id);
                ids.add(pat_id);
                temp_query = "SELECT * FROM patients WHERE pat_id = " + pat_id + " ";
                temp_st = con.createStatement();
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[0] = temp_rs.getString("name");
                    data[1] = temp_rs.getString("contact");
                    System.out.println(data[0] + " >< " + data[1]);
                }
                temp_query = "SELECT * FROM bed_booking WHERE case_id = " + case_id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    bed_id = temp_rs.getInt("bed_id");
                    data[2] = temp_rs.getString("booking_time");
                    System.out.println("");
                }
                temp_query = "SELECT * FROM beds WHERE bed_id = " + bed_id;

                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString("room_num");
                    data[4] = temp_rs.getString("floor");
                    data[5] = temp_rs.getString("type");
                    System.out.println(data[5]);
                    arr.add(data);
                    dtm.addRow(arr.get(0));
                }

            }
        } catch (Exception ex) {
            System.out.println("from running pat:   " + ex);
        }
        lbl_tbl_title.setText("Running Patients (Admitted)");

    }
    private void btn_run_in_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_run_in_patActionPerformed
        // TODO add your handling code here:
        view_RunningPatients("SELECT * FROM in_pat_cases WHERE status = '" + "running'");
    }//GEN-LAST:event_btn_run_in_patActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        // TODO add your handling code here: 
        txt_add.setText("");
        txt_nid.setText("");
        txt_contact.setText("");
        txt_email.setText("");
        txt_fam_mem.setText("");
        txt_pat_name.setText("");
        btn_g.clearSelection();
        btn_save_pat_per.setEnabled(false);
        txt_ammount.setText("payment");
        r_btn_take_chngs.setVisible(false);
        lbl_any_update.setVisible(false);
        chk_old_pat.setSelected(false);
        btn_sel_exis_pat.setEnabled(false);
        old_patient = false;
        chk_payment.setSelected(false);
        chk_old_pat.setEnabled(true);
        chk_paymentActionPerformed(evt);
    }//GEN-LAST:event_btn_clearActionPerformed

    private void btn_sel_exis_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sel_exis_patActionPerformed
        // TODO add your handling code here:
        sign = false;
        old_patient = false;
        if (!lbl_tbl_title.getText().startsWith("Patients")) {
            sign = true;
            // method of patient in table
            acknowledgement_Or_Warning("Patient Selection !", 1400);
        }
        if (sign == false && tbl_Result_Exhibition.getSelectedRows().length > 1) {
            sign = true;
            acknowledgement_Or_Warning("Select one Patient ", 1400);
        }
        if (sign == false && tbl_Result_Exhibition.getSelectedRow() < 0) {
            acknowledgement_Or_Warning("Select A Patient ", 1400);
            sign = true;
        }
        System.out.println("still safe ");
        if (sign == false) {
            int ind = tbl_Result_Exhibition.getSelectedRow();
            pat_id = ids.get(ind);
            try {
                query = "SELECT * FROM patients WHERE pat_id = " + pat_id + " ";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    txt_pat_name.setText(rs.getString("name"));
                    txt_contact.setText(rs.getString("contact"));
                    txt_email.setText(rs.getString("email"));
                    txt_add.setText(rs.getString("address"));
                    txt_nid.setText(rs.getString("nid"));
                    txt_fam_mem.setText(rs.getString("family"));
                    old_patient = true;
                    changes = false;
                }
                lbl_any_update.setVisible(true);
                r_btn_take_chngs.setVisible(true);
            } catch (Exception ex) {
                System.out.println("oh ! dump ass " + ex);
            }
        }
    }//GEN-LAST:event_btn_sel_exis_patActionPerformed

    private void btn_Confirm_appActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Confirm_appActionPerformed
        // TODO add your handling code here:
        sign = false;
        int serial = 0;
        String payment_status = "_No";
        doj = "";
        int amount = 0;
        if (lbl_pat_confirmation.getText().contains("?") || lbl_doc_confirmation.getText().contains("?")) {
            sign = true;
            acknowledgement_Or_Warning("  info missing ! >> ", 1400);
        }
        if (sign == false) {
            try {
                doj = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(jspn_app_date.getDate());
                System.out.println("we get:  " + doj);
            } catch (NullPointerException npe) {
                sign = true;
                acknowledgement_Or_Warning(" appointment date !", 1400);
            }
        }
        if (sign == false && chk_payment.isSelected()) {
            try {
                amount = Integer.parseInt(txt_ammount.getText());
                payment_status = "_Yes";
            } catch (Exception e) {
                sign = true;
                payment_status = "_No";
                acknowledgement_Or_Warning("integer amount", 1400);
            }
        }
        if (sign == false) {
            System.out.println("old pat status: " + old_patient + "   change: " + changes);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                if (old_patient == false) {
                    insert_New_Patient();
                }
                if (changes == true) {
                    System.out.println("got changes");
                    update_Existing_Patient();
                }
                app_id = 1;
                query = "SELECT app_id  FROM  appointments ORDER BY app_id  DESC LIMIT 1;";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    app_id = rs.getInt(1) + 1;
                    System.out.println("latest app id: " + app_id + "  " + doc_id + "  " + pat_id);
                }
                pst = con.prepareStatement("insert into appointments values(?,?,?,?,?,?,?)");
                pst.setInt(1, app_id);
                pst.setInt(2, doc_id);
                InputStream is = null;
                pst.setInt(3, pat_id);
                pst.setString(4, doj);
                pst.setString(5, "Not Done");
                pst.setBlob(6, is);
                pst.setInt(7, amount);
                pst.executeUpdate();
                receipt_Code = pat_id + "TO" + doc_id + "#" + doj;
                System.out.println("Receipt Code:  " + receipt_Code);
            } catch (Exception npe) {
                System.out.println("in execution >>>>" + npe);
            }

            btn_clearActionPerformed(evt);
            btn_can_attActionPerformed(evt);
            btn_save_pat_per.setEnabled(true);
            get_Patients();

        }
    }//GEN-LAST:event_btn_Confirm_appActionPerformed
    public void update_Existing_Patient() {
        try {
            st = con.createStatement();
            query = "UPDATE patients SET"
                    + " pat_id = ? ,"
                    + " name =? ,"
                    + " email = ? ,"
                    + " contact = ? ,"
                    + " nid = ?,"
                    + " address = ? ,"
                    + " family = ? ,"
                    + " gender = ?, "
                    + " blood_group = ?, "
                    + " dob = ?"
                    + " WHERE pat_id = " + pat_id + " ";
            pst = con.prepareStatement(query);
            pst.setInt(1, pat_id);
            pst.setString(2, name);
            pst.setString(3, email);
            pst.setString(4, contact);
            pst.setString(5, nid);
            pst.setString(6, c_add);
            pst.setString(7, family);
            pst.setString(8, gender);
            pst.setString(9, "");
            pst.setString(10, age);
            pst.executeUpdate();
        } catch (Exception exp) {
            System.out.println("from update_patient  " + exp);
        }
    }

    public void insert_New_Patient() {
        try {
            pat_id = 1;
            query = "SELECT pat_id  FROM  patients ORDER BY pat_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                pat_id = rs.getInt(1) + 1;
                System.out.println("latest pat id: " + pat_id);

            }
            pst = con.prepareStatement("insert into patients values(?,?,?,?,?,?,?,?,?,?)");
            pst.setInt(1, pat_id);
            pst.setString(2, name);
            pst.setString(3, email);
            pst.setString(4, contact);
            pst.setString(5, nid);
            pst.setString(6, c_add);
            pst.setString(7, family);
            pst.setString(8, gender);
            pst.setString(9, "");
            pst.setString(10, age);
            pst.executeUpdate();
        } catch (Exception exp) {
            System.out.println("from insert_NewPatient   " + exp);
        }
    }
    private void cmb_doc_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_doc_by_deptActionPerformed
        // TODO add your handling code here:
        if (cmb_doc_by_dept.getSelectedIndex() > -1) {
            dept_name = cmb_doc_by_dept.getSelectedItem().toString();
            System.out.println("  com name: " + dept_name);
            view_doctors(dept_name);
        }
    }//GEN-LAST:event_cmb_doc_by_deptActionPerformed

    private void btn_show_schActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_show_schActionPerformed
        // TODO add your handling code here:
        sign = false;
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (!lbl_tbl_title.getText().startsWith("Doctors")) {
            sign = true;
            btn_doctorsActionPerformed(evt);
        }
        if (sign == false && row != -1) {
            id = ids.get(row);
            try {
                if (view_schedule == null) {
                    System.out.println("got null");
                    view_schedule = new ViewDocSchedule(id);
                }
                if (view_schedule.isVisible()) {
                    view_schedule.setVisible(true);
                    view_schedule.setAlwaysOnTop(true);
                }
            } catch (NullPointerException npe) {
                System.out.println(npe);
                view_schedule = new ViewDocSchedule(id);
            }
        }
    }//GEN-LAST:event_btn_show_schActionPerformed

    private void btn_get_sel_docActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_get_sel_docActionPerformed
        // TODO add your handling code here:

        sign = false;
        if (!lbl_tbl_title.getText().contains("Doctors")) {
            btn_doctorsActionPerformed(evt);
            sign = true;
        }
        if (sign == false) {
            if (tbl_Result_Exhibition.getSelectedRow() < 0) {
                acknowledgement_Or_Warning("Doctor = ?", 1600);
                sign = true;
            }
            if (sign == false) {
                int ind = tbl_Result_Exhibition.getSelectedRow();
                lbl_doc_confirmation.setText("Doctor: " + tbl_Result_Exhibition.getValueAt(ind, 0).toString());
                if (lbl_pat_confirmation.getText().isEmpty()) {
                    lbl_pat_confirmation.setText("Patient info = ?");
                }
                doc_id = ids.get(ind);
                tbl_Result_Exhibition.clearSelection();
            }
        }
    }//GEN-LAST:event_btn_get_sel_docActionPerformed
    public void view_doctors(String where) {

        if (where.equals("all")) {
            query = "SELECT * FROM doctors";
        } else {
            query = "SELECT * FROM doctors where dept = '" + where + "'";
        }
        ids = new ArrayList<>();
        String[] coloumn = new String[3];
        String[] data = new String[3];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Name";
        coloumn[1] = "Department";
        coloumn[2] = "Degrees";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                ids.add(Integer.parseInt(rs.getString("doc_id")));
                data[0] = rs.getString("name");
                System.out.println(data[0]);
                data[1] = rs.getString("dept");
                data[2] = rs.getString("degrees");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Doctors  (" + where + " )");
    }
    private void btn_doctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_doctorsActionPerformed
        // TODO add your handling code here:
        view_doctors("all");
    }//GEN-LAST:event_btn_doctorsActionPerformed

    public void make_Off_() {
        chk_old_pat.setEnabled(false);
        btn_sel_exis_pat.setEnabled(false);
        r_btn_take_chngs.setVisible(false);
        lbl_any_update.setVisible(false);
    }
    private void btn_save_pat_perActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_save_pat_perActionPerformed
        // TODO add your handling code here:
        changes = false;
        sign = false;
        pat_type = "";
        age = new SimpleDateFormat("dd/MM/yyyy").format(jspn_dob.getDate());
        family = txt_fam_mem.getText();
        email = txt_email.getText();
        name = txt_pat_name.getText();
        contact = txt_contact.getText();
        c_add = txt_add.getText();
        nid = txt_nid.getText();
        if (R_btn_fem.isSelected()) {
            gender = "female";
        }
        if (R_btn_male.isSelected()) {
            gender = "male";
        }
        if (R_btn_other.isSelected()) {
            gender = "other";
        }
        if (chk_old_pat.isSelected() && old_patient == false) {
            acknowledgement_Or_Warning("No old Patient Selected", 1300);
            sign = true;
        }
        if ((name.isEmpty() || contact.isEmpty()) && sign == false) {
            sign = true;
            acknowledgement_Or_Warning("Info Missing!", 1350);
        }
        if (sign == false) {
            if (r_btn_take_chngs.isSelected()) {
                changes = true;
            }
            make_Off_();
            lbl_pat_confirmation.setText("Patient info captured");
            if (old_patient == true) {
                lbl_pat_confirmation.setText("Old patient selected");
            }
            if (lbl_doc_confirmation.getText().isEmpty()) {
                lbl_doc_confirmation.setText("Doctor = ?");
            }
        }
    }//GEN-LAST:event_btn_save_pat_perActionPerformed

    private void btn_can_attActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_can_attActionPerformed
        // TODO add your handling code here:
        btn_clearActionPerformed(evt);
        chk_old_pat.setEnabled(true);
        lbl_doc_confirmation.setText("");
        lbl_pat_confirmation.setText("");
        lbl_last.setText("");
        txt_ammount.setText("payment");
        btn_save_pat_per.setEnabled(true);
        bed_selection = false;

    }//GEN-LAST:event_btn_can_attActionPerformed

    private void txt_ammountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ammountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ammountActionPerformed

    private void chk_old_patActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_old_patActionPerformed
        // TODO add your handling code here:
        if (chk_old_pat.isSelected()) {
            btn_sel_exis_pat.setEnabled(true);

        } else {
            lbl_any_update.setVisible(false);
            r_btn_take_chngs.setVisible(false);
            btn_sel_exis_pat.setEnabled(false);
        }

    }//GEN-LAST:event_chk_old_patActionPerformed

    private void r_btn_take_chngsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_r_btn_take_chngsActionPerformed
        // TODO add your handling code here:
        changes = true;

    }//GEN-LAST:event_r_btn_take_chngsActionPerformed
    public int get_Distance(String cont, String name) {

        int i, j, x, edit;
        String str1 = cont;
        String str2 = name;
        int len1 = str1.length();
        int len2 = str2.length();
        int arr[][] = new int[len1 + 1][len2 + 1];
        x = 0;
        i = 0;
        for (j = 0; j < len2; j++) {
            arr[i][j] = x;
            x++;
        }
        edit = 0;
        x = 0;
        j = 0;
        for (i = 0; i < len1; i++) {
            arr[i][j] = x;
            x++;
        }
        for (i = 0; i < str1.length(); i++) {
            for (j = 0; j < str2.length(); j++) {
                edit = 1;
                if (str1.charAt(i) == str2.charAt(j)) {
                    edit = 0;
                }
                arr[i + 1][j + 1] = Math.min(Math.min(arr[i][j] + edit, arr[i][j + 1] + 1), arr[i + 1][j] + 1);
                edit = arr[i + 1][j + 1];
            }
        }
//        for (i = 0; i < len1; i++) {
//            System.out.println("");
//            for (j = 0; j < len2; j++) {
//                System.out.print(" " + arr[i][j]);
//            }
//        }
        System.out.println("Minimum Distance: " + edit);
        return edit;
    }
    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        // TODO add your handling code here:
        sign = false;
        String content = "";
        content = txt_search_content.getText();

        if (chk_pat_name.isSelected() && content.length() > 4) {

            int distanses[][] = new int[pat_Name_Contacts.size()][2];
            int dist;
            for (int i = 0; i < pat_Name_Contacts.size(); i++) {
                dist = get_Distance(content, pat_Name_Contacts.get(i)[1]);
                System.out.println("dist @ " + dist + "   " + pat_Name_Contacts.get(i)[1]);
                distanses[i][0] = i;
                distanses[i][1] = dist;
            }
            int temp;
            for (int i = 0; i < distanses.length; i++) {
                for (int j = i + 1; j < distanses.length; j++) {
                    if (distanses[i][1] > distanses[j][1]) {
                        temp = distanses[i][1];
                        distanses[i][1] = distanses[j][1];
                        distanses[j][1] = temp;
                        temp = distanses[i][0];
                        distanses[i][0] = distanses[j][0];
                        distanses[j][0] = temp;
                    }
                }
            }
            String[] coloumn = new String[3];
            String[] data = new String[3];
            ArrayList<Object[]> arr_show = new ArrayList<Object[]>();
            ids = new ArrayList<>();
            coloumn[0] = "Full Name";
            coloumn[1] = "Contact";
            coloumn[2] = "Address";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dm);

            for (int i = 0; i < distanses.length; i++) {
                id = Integer.parseInt(pat_Name_Contacts.get(distanses[i][0])[0]);
                System.out.println("id name > " + id + "  : " + pat_Name_Contacts.get(distanses[i][0])[1]);
                try {
//                    Class.forName("com.mysql.jdbc.Driver");
//                    con = DriverManager.getConnection(url + dbName, db_userName, db_password);
//                    st = con.createStatement();
                    query = "SELECT * FROM patients WHERE pat_id =" + id;
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        data[0] = rs.getString("name");
                        data[1] = rs.getString("contact");
                        data[2] = rs.getString("address");
                        ids.add(rs.getInt("pat_id"));
                        arr_show.add(data);
                        dm.addRow(arr_show.get(0));
                        arr_show.clear();
                    }
                    lbl_tbl_title.setText("Patients (Resulted)");
                } catch (Exception ex) {
                    System.out.println(" btn_searchActionPerformed :" + ex);
                }
            }

        } else if (chk_pat_con.isSelected() && content.length() > 0) {

            String[] coloumn = new String[3];
            String[] data = new String[3];
            ArrayList<Object[]> arr_show = new ArrayList<Object[]>();
            ids = new ArrayList<>();
            coloumn[0] = "Full Name";
            coloumn[1] = "Contact";
            coloumn[2] = "Address";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dm);
            System.out.println("size  :" + pat_Name_Contacts.size());
            for (int i = 0; i < pat_Name_Contacts.size(); i++) {
                id = Integer.parseInt(pat_Name_Contacts.get(i)[0]);
                System.out.println(content + "  >>>%  " + pat_Name_Contacts.get(i)[2]);
                if (pat_Name_Contacts.get(i)[2].startsWith(content)) {
                    try {
//                        Class.forName("com.mysql.jdbc.Driver");
//                        con = DriverManager.getConnection(url + dbName, db_userName, db_password);
//                        st = con.createStatement();
                        query = "SELECT * FROM patients WHERE pat_id =" + id;
                        rs = st.executeQuery(query);
                        while (rs.next()) {
                            data[0] = rs.getString("name");
                            data[1] = rs.getString("contact");
                            data[2] = rs.getString("address");
                            ids.add(rs.getInt("pat_id"));
                            arr_show.add(data);
                            dm.addRow(arr_show.get(0));

                        }
                        arr_show.clear();
                        lbl_tbl_title.setText("Patients: (Resulted)");
                    } catch (Exception ex) {
                        System.out.println(" btn_searchActionPerformed :" + ex);
                    }
                }
            }
        }
    }//GEN-LAST:event_btn_searchActionPerformed

    public void view_Beds(String q) {
        query = q;
        ids = new ArrayList<>();
        String[] coloumn = new String[7];
        String[] data = new String[7];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        coloumn[0] = "Room Num";
        coloumn[1] = "Status";
        coloumn[2] = "Type";
        coloumn[3] = "Floor";
        coloumn[4] = "Vacancy";
        coloumn[5] = "Department";
        coloumn[6] = "Charge/= ";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("bed_id"));
                data[0] = rs.getString("room_num");
                data[1] = rs.getString("status");
                data[2] = rs.getString("type");
                data[3] = rs.getString("floor");
                data[4] = rs.getString("vacancy");
                data[5] = rs.getString("dept");
                data[6] = rs.getString("charge");

                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Beds And Status");

    }
    private void btn_bed_statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bed_statusActionPerformed
        // TODO add your handling code here:
        view_Beds("SELECT * FROM beds");
    }//GEN-LAST:event_btn_bed_statusActionPerformed

    private void btn_ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ServicesActionPerformed
        // TODO add your handling code here:
        String[] coloumn = new String[4];
        String[] data = new String[4];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();

        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Type";
        coloumn[3] = "Charge";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM services";
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString("service_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("charge");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Services");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(70);
    }//GEN-LAST:event_btn_ServicesActionPerformed

    private void btn_app_to_beActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_app_to_beActionPerformed
        // TODO add your handling code here:
        sign = false;
        if (!lbl_tbl_title.getText().contains(("Doctors"))) {
            sign = true;
            btn_doctorsActionPerformed(evt);
        }
        System.out.println(tbl_Result_Exhibition.getSelectedRow());
        if (sign == false && tbl_Result_Exhibition.getSelectedRow() < 0) {
            sign = true;
        }
        if (sign == false) {
            ResultSet temp_rs;
            ArrayList<Object[]> arr = new ArrayList<Object[]>();
            String[] coloumn = new String[4];
            String[] data = new String[4];
            coloumn[0] = "Date";
            coloumn[1] = "Pat Name";
            coloumn[2] = "Contact";
            coloumn[3] = "Bill";
            //   coloumn[4] = "Serial"; 
            System.out.println("still safe ");

            doc_id = ids.get((int) tbl_Result_Exhibition.getSelectedRow());
            name = tbl_Result_Exhibition.getValueAt(tbl_Result_Exhibition.getSelectedRow(), 0).toString();
            System.out.println("doc nme:  >> " + name);
            DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dtm);
            try {
                query = "SELECT * FROM appointments WHERE doc_id = " + doc_id + " AND status = '" + "Not Done" + "' ";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    app_id = rs.getInt("app_id");
                    data[0] = rs.getString("date");
                    data[3] = rs.getString("bill");
                    pat_id = rs.getInt("pat_id");
                    query = "SELECT * FROM patients WHERE pat_id = " + pat_id + " ";
                    st = con.createStatement();
                    temp_rs = st.executeQuery(query);
                    while (temp_rs.next()) {
                        data[1] = temp_rs.getString("name");
                        data[2] = temp_rs.getString("contact");
                    }
                    arr.add(data);
                    dtm.addRow(arr.get(0));
                }
            } catch (Exception ex) {
                System.out.println("oh ! dump ass " + ex);
            }
            lbl_tbl_title.setText("Appointments ( " + name + " )");

        }
    }//GEN-LAST:event_btn_app_to_beActionPerformed

    private void chk_paymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_paymentActionPerformed
        // TODO add your handling code here:
        if (chk_payment.isSelected()) {
            txt_ammount.setEditable(true);
            txt_ammount.setText("");
        }
        if (!chk_payment.isSelected()) {
            txt_ammount.setEditable(false);
            txt_ammount.setText("payment");
        }
    }//GEN-LAST:event_chk_paymentActionPerformed

    private void btn_view_ser_detailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_ser_detailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_view_ser_detailActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void txt_u_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_u_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_u_nameActionPerformed

    private void txt_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusGained
        // TODO add your handling code here:
        if (txt_pass.getText().equals("pass..")) {
            txt_pass.setText("");
        }
    }//GEN-LAST:event_txt_passFocusGained

    private void txt_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusLost
        // TODO add your handling code here:
        if (txt_pass.getText().equals("")) {
            txt_pass.setText("pass..");
        }
    }//GEN-LAST:event_txt_passFocusLost

    private void txt_conf_passFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusGained
        // TODO add your handling code here:
        btn_update.setText("Update");

        if (txt_conf_pass.getText().equals("confirm pass")) {
            txt_conf_pass.setText("");
        }
    }//GEN-LAST:event_txt_conf_passFocusGained

    private void txt_conf_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_conf_passFocusLost
        if (txt_conf_pass.getText().equals("")) {
            txt_conf_pass.setText("confirm pass");
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txt_conf_passFocusLost

    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:
        if (btn_login_out.getText().equals("In")) {
            module_user_name = txt_u_name.getText();
            module_use_pass = txt_pass.getText();
            System.out.println(module_user_name + "  ?  " + module_use_pass);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "SELECT * FROM accounts WHERE user_name = '" + module_user_name + "' AND pass = '" + module_use_pass + "'";
                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (rs.getString("module").equals("Receiption")) {
                        sign = true;
                        module_user_ID = rs.getInt("user_id");
                        set_Frame_to_Initial(sign);
                    }
                }
                if (sign == false) {
                    set_Warning("Missmatch !", 1650);
                }
            } catch (Exception exp) {
                System.out.println(exp);
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_login_outActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
        set_Warning("OpsLeft coding !", 1650);
//        String pass2 = "";
//        if (btn_update.getText().equals("Edit")) {
//            txt_u_name.setVisible(true);
//            txt_pass.setVisible(true);
//            txt_conf_pass.setVisible(true);
//            btn_cancel.setVisible(true);
//        }
//        if (btn_update.getText().equals("Update")) {
//
//            if ((email = txt_u_name.getText()).isEmpty() || (db_password = txt_pass.getText()).isEmpty() || (pass2 = txt_conf_pass.getText()).isEmpty()) {
//                acknowledgement_Or_Warning("you kidding !", 1500);
//            }
//
//        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_testsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_testsActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<Object[]> arr = new ArrayList<Object[]>();
        //   ArrayList<Object[]> a = new ArrayList<Object[]>();
        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Type";
        coloumn[3] = "Charge";
        coloumn[3] = "Testing Method";
        DefaultTableModel dtm = new DefaultTableModel(coloumn, 0);
        ids = new ArrayList<>();
        tbl_Result_Exhibition.setModel(dtm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM med_tests";
            rs = st.executeQuery(query);
            while (rs.next()) {
                ids.add(rs.getInt("test_id"));
                data[0] = rs.getString("test_id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("type");
                data[3] = rs.getString("charge");
                data[4] = rs.getString("testing_method");
                arr.add(data);
                dtm.addRow(arr.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        lbl_tbl_title.setText("Diagnostic Imaging Tests");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(70);
    }//GEN-LAST:event_btn_testsActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        reception = null;
        //  System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    private void btn_minnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_minnActionPerformed
        // TODO add your handling code here:
        setState(1);
    }//GEN-LAST:event_btn_minnActionPerformed
    public void set_bed_types() {

        sugg = new ArrayList<String>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT DISTINCT type from beds ;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                sugg.add(rs.getString(1));
            }
            cmb_model = new DefaultComboBoxModel(sugg.toArray());
            cmb_bed_by_type.setModel(cmb_model);
            sugg.clear();
        } catch (Exception ex) {
            System.out.println("exp in set_Dept_Names" + ex);
        }
        cmb_bed_by_type.setSelectedIndex(-1);

    }
    private void cmb_bed_by_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_bed_by_typeActionPerformed
        // TODO add your handling code here: 
        String bed_Type = "";
        if (cmb_bed_by_type.getSelectedIndex() > -1) {
            bed_Type = cmb_bed_by_type.getSelectedItem().toString();
            view_Beds("SELECT * FROM beds WHERE type = '" + bed_Type + "'");
        }
    }//GEN-LAST:event_cmb_bed_by_typeActionPerformed

    private void btn_bed_detailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bed_detailActionPerformed
        // TODO add your handling code here:
        sign = false;
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (!lbl_tbl_title.getText().startsWith("Beds")) {
            sign = true;
            view_Beds("SELECT * FROM beds");
        }
        if (sign == false && row != -1) {
            id = ids.get(row);
            try {
                if (beddetail == null) {
                    System.out.println("got null");
                    beddetail = new BedDetail(id);
                }
                if (beddetail.isVisible()) {
                    beddetail.setVisible(true);
                    beddetail.setAlwaysOnTop(true);
                }
            } catch (NullPointerException npe) {
                System.out.println(npe);
                beddetail = new BedDetail(id);
            }
        }
    }//GEN-LAST:event_btn_bed_detailActionPerformed

    private void cmb_test_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_test_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_test_typeActionPerformed

    private void cmb_SerByTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_SerByTypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_SerByTypeActionPerformed

    private void cmb_pat_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_pat_by_deptActionPerformed
        // TODO add your handling code here:

        if (cmb_pat_by_dept.getSelectedIndex() > -1) {
            dept = cmb_pat_by_dept.getSelectedItem().toString();
            view_RunningPatients("SELECT * FROM in_pat_cases WHERE status = '" + "running" + "' AND dept = '" + dept + "'");
        }
    }//GEN-LAST:event_cmb_pat_by_deptActionPerformed

    private void txt_ammountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_ammountFocusGained
        // TODO add your handling code here:
        if (txt_ammount.getText().equals("payment")) {
            txt_ammount.setText("");
        }
    }//GEN-LAST:event_txt_ammountFocusGained

    private void txt_ammountFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_ammountFocusLost
        // TODO add your handling code here:
        if (txt_ammount.getText().equals("")) {
            txt_ammount.setText("payment");
        }
    }//GEN-LAST:event_txt_ammountFocusLost

    private void cmb_bed_by_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_bed_by_deptActionPerformed
        // TODO add your handling code here:
        String bed_dept = "";
        if (cmb_bed_by_dept.getSelectedIndex() > -1) {
            bed_dept = cmb_bed_by_dept.getSelectedItem().toString();
            view_Beds("SELECT * FROM beds WHERE dept = '" + bed_dept + "'");
        }
    }//GEN-LAST:event_cmb_bed_by_deptActionPerformed

    private void btn_testDetailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_testDetailActionPerformed
        // TODO add your handling code here:
        sign = false;
        int row = tbl_Result_Exhibition.getSelectedRow();
        if (!lbl_tbl_title.getText().contains("Tests")) {
            sign = true;
            btn_testsActionPerformed(evt);
        }
        if (sign == false && row != -1) {
            id = ids.get(row);
            try {
                if (testdetail == null) {
                    System.out.println("got null");
                    testdetail = new TestDetail(id);
                }
                if (testdetail.isVisible()) {
                    testdetail.setVisible(true);
                    testdetail.setAlwaysOnTop(true);
                }
            } catch (NullPointerException npe) {
                System.out.println(npe);
                testdetail = new TestDetail(id);
            }
        }

    }//GEN-LAST:event_btn_testDetailActionPerformed

    private void txt_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_addActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_addActionPerformed

    private void btn_print_appListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_print_appListActionPerformed
        // TODO add your handling code here:
        sign = false;
        if (!lbl_tbl_title.getText().contains(("Doctors"))) {
            sign = true;
            btn_doctorsActionPerformed(evt);
        }
        System.out.println("row:  " + tbl_Result_Exhibition.getSelectedRow());
        if (sign == false && tbl_Result_Exhibition.getSelectedRow() < 0) {
            sign = true;
        }
        if (sign == false) {
            doc_id = ids.get(tbl_Result_Exhibition.getSelectedRow());
            System.out.println("doc id: " + doc_id);
            File_Chooser ch = new File_Chooser();

        }

//        fileChooser = new JFileChooser("Set output Folder");
//        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
//        fileChooser.showOpenDialog(null);
//        fileChooser.setVisible(true);
//        fileChooser.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                System.out.println("Action");
//                if (e.getActionCommand().equals("ApproveSelection")) {
//                    try {
//                        String path = fileChooser.getSelectedFile().getCanonicalPath();
//
//                        System.out.println(path);
//                    } catch (Exception ex) {
//                        System.out.println("reporting exp >> " + ex.getMessage());
//                    }
//                }
//                if (e.getActionCommand().equals("CancelSelection")) {
//                    System.out.println("Cancel");
//                }
//            }
//        });
        // Choose ch = new Choose();

    }//GEN-LAST:event_btn_print_appListActionPerformed

    private void chk_pat_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_pat_nameActionPerformed
        // TODO add your handling code here:
        if (chk_pat_name.isSelected()) {
            chk_pat_con.setSelected(false);
        }
    }//GEN-LAST:event_chk_pat_nameActionPerformed

    private void chk_pat_conActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_pat_conActionPerformed
        // TODO add your handling code here:
        if (chk_pat_con.isSelected()) {
            chk_pat_name.setSelected(false);
        }
    }//GEN-LAST:event_chk_pat_conActionPerformed

    static void getPath_Save(String path) {

        try {
            doc_id = 1;

            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\app_To_Be.pdf"));
            com.itextpdf.text.Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
            document.open();

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            temp_st = con.createStatement();

            query = "SELECT * FROM appointments WHERE doc_id = " + doc_id + " AND status = '" + "Not Done" + "' ";
            rs = st.executeQuery(query);
            int count = 0;
            String fullString = "";
            while (rs.next()) {
                count++;
                pat_id = rs.getInt("pat_id");
                dob = rs.getString("date");

                temp_query = "SELECT name , contact , address FROM patients WHERE pat_id = " + pat_id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    fullString = "";
                    name = temp_rs.getString("name");
                    contact = temp_rs.getString("contact");
                    c_add = temp_rs.getString("address");
                    fullString = "     " + count + ".  " + name + ",  " + c_add + ",  " + contact + "\n\n";
                    document.add(new Paragraph(fullString));
                    document.add(Chunk.NEWLINE);
                }
            }

            //Chunk chunk = new Chunk(fullString, font);
            // document.add(chunk);
            document.close();

//            Document document = new Document(new Rectangle(PageSize.A0));
//            path.replaceAll("", "");
//            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path + "\\" + printToBePDFName + ".pdf"));
//
//            //   PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\Barcodes\\" + bar + ".pdf"));
//            document.open();
//            document.add(new Paragraph("Ha Ha Ha &&&&&&&&&&"));
//            document.addHeader("fdb", "dbdfndfndfndfnd");
//
//            document.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(B_Reception.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(B_Reception.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(B_Reception.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(B_Reception.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        try {
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
//        } catch (Exception ex) {
//
//        }
        //</editor-fold>

        /* Create and display the form */
        //   UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (reception = new ReceptionModule()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton R_btn_fem;
    private javax.swing.JRadioButton R_btn_male;
    private javax.swing.JRadioButton R_btn_other;
    private javax.swing.JButton btn_Confirm_app;
    private javax.swing.JButton btn_Services;
    private javax.swing.JButton btn_app_to_be;
    private javax.swing.JButton btn_bed_detail;
    private javax.swing.JButton btn_bed_status;
    private javax.swing.JButton btn_can_att;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_doctors;
    private javax.swing.JButton btn_get_sel_doc;
    private javax.swing.JButton btn_login_out;
    private javax.swing.JButton btn_minn;
    private javax.swing.JButton btn_print_appList;
    private javax.swing.JButton btn_run_in_pat;
    private javax.swing.JButton btn_save_pat_per;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_sel_exis_pat;
    private javax.swing.JButton btn_show_sch;
    private javax.swing.JButton btn_testDetail;
    private javax.swing.JButton btn_tests;
    private javax.swing.JButton btn_update;
    private javax.swing.JButton btn_view_ser_detail;
    private javax.swing.JCheckBox chk_old_pat;
    private javax.swing.JCheckBox chk_pat_con;
    private javax.swing.JCheckBox chk_pat_name;
    private javax.swing.JRadioButton chk_payment;
    private javax.swing.JComboBox<String> cmb_SerByType;
    private javax.swing.JComboBox<String> cmb_bed_by_dept;
    private javax.swing.JComboBox<String> cmb_bed_by_type;
    private javax.swing.JComboBox<String> cmb_doc_by_dept;
    private javax.swing.JComboBox<String> cmb_pat_by_dept;
    private javax.swing.JComboBox<String> cmb_test_type;
    private javax.swing.JButton exit;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jpnl_appointment;
    private javax.swing.JPanel jpnl_functions;
    private com.toedter.calendar.JSpinnerDateEditor jspn_app_date;
    private com.toedter.calendar.JSpinnerDateEditor jspn_dob;
    private javax.swing.JLabel lbl_any_update;
    private javax.swing.JLabel lbl_doc_confirmation;
    private javax.swing.JLabel lbl_last;
    private javax.swing.JLabel lbl_missmtch;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JLabel lbl_pat_confirmation;
    private javax.swing.JLabel lbl_tbl_title;
    private javax.swing.JLabel lbl_warning;
    private javax.swing.JRadioButton r_btn_take_chngs;
    private javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_add;
    private javax.swing.JTextField txt_ammount;
    private javax.swing.JTextField txt_conf_pass;
    private javax.swing.JTextField txt_contact;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_fam_mem;
    private javax.swing.JTextField txt_nid;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextField txt_pat_name;
    private javax.swing.JTextField txt_search_content;
    private javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent ae) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
