/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reception;

import static Reception.ReceptionModule.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author pddrgj3q
 */
public class ViewDocSchedule extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form new_Patient
     */
    public int doc_IDForSch;
    public boolean sign = false;
    public int pX, pY;

    public ViewDocSchedule(int id) {

        initComponents();
 
        doc_IDForSch = id;
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        jLabel3.setText(new Date().toString());
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
        if (doc_IDForSch != 0) {
            set_schedule();
        }
    }

    public void set_schedule() {
        //    doc_id=1;
        sign = false;
        System.out.println("id? " + doc_IDForSch);
        String schedule = "";
        jlist_model = new DefaultListModel();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();
            query = "SELECT * FROM doctors WHERE doc_id = " + doc_IDForSch;
            rs = st.executeQuery(query);
            while (rs.next()) {
                schedule = rs.getString("doc_schedule");
                System.out.println("ssssssssssssss ?" + schedule);
                jlist_model.add(0, "Name : " + rs.getString("name"));
                jlist_model.add(1, "Contact: " + rs.getString("contact"));
                jlist_model.add(2, "Department: " + rs.getString("dept"));
                jlist_model.add(3, "Specialist: " + rs.getString("degrees"));
                if (schedule == null) {
                    jlist_model.add(4, "Schedule: Absent");
                    sign = true;
                }
                jlist_doc_pro.setModel(jlist_model);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        if (sign == false) {

            String str[];
            String slot[] = new String[3];

            String day_of_today = new SimpleDateFormat("EE").format(new Date()).toLowerCase();
            str = schedule.split("!");

            for (int x = 0; x < str.length; x++) {

                System.out.println(str[x]);
                if (str[x].isEmpty()) {
                    continue;
                }

                if (str[x].contains("tue")) {

                    str[x] = str[x].replace("tue", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_4_s_1.setText(slot[0]);
                            lbl_4_s_2.setText(slot[1]);
                            lbl_4_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_4_s_1.setText(str[x]);
                    }
                    continue;
                }
                if (str[x].contains("sat")) {

                    str[x] = str[x].replace("sat", "");

                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_1_s_1.setText(slot[0]);
                            lbl_1_s_2.setText(slot[1]);
                            lbl_1_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {

                        lbl_1_s_1.setText(str[x]);
                    }
                    continue;
                }

                if (str[x].contains("sun")) {

                    str[x] = str[x].replace("sun", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_2_s_1.setText(slot[0]);
                            lbl_2_s_2.setText(slot[1]);
                            lbl_2_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_2_s_1.setText(str[x]);
                    }
                    continue;
                }
                if (str[x].contains("mon")) {

                    str[x] = str[x].replace("mon", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_3_s_1.setText(slot[0]);
                            lbl_3_s_2.setText(slot[1]);
                            lbl_3_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_3_s_1.setText(str[x]);
                    }
                    continue;
                }
                if (str[x].contains("wed")) {

                    str[x] = str[x].replace("wed", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_5_s_1.setText(slot[0]);
                            lbl_5_s_2.setText(slot[1]);
                            lbl_5_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_5_s_1.setText(str[x]);
                    }
                    continue;
                }

                if (str[x].contains("thu")) {

                    str[x] = str[x].replace("thu", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_6_s_1.setText(slot[0]);
                            lbl_6_s_2.setText(slot[1]);
                            lbl_6_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_6_s_1.setText(str[x]);
                    }
                    continue;
                }
                if (str[x].contains("fri")) {

                    str[x] = str[x].replace("fri", "");
                    if (str[x].contains("&")) {
                        slot = str[x].split("&");
                        try {
                            lbl_7_s_1.setText(slot[0]);
                            lbl_7_s_2.setText(slot[1]);
                            lbl_7_s_3.setText(slot[2]);
                        } catch (ArrayIndexOutOfBoundsException ae) {

                        }
                    } else {
                        lbl_7_s_1.setText(str[x]);
                    }
                    continue;
                }
            }

            if (day_of_today.equals("sat")) {
                jpnl_1.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("sun")) {
                jpnl_2.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("mon")) {
                jpnl_3.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("tue")) {
                jpnl_4.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("wed")) {
                jpnl_5.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("thu")) {
                jpnl_6.setBackground(new Color(0, 102, 102));
            }
            if (day_of_today.equals("fri")) {
                jpnl_7.setBackground(new Color(0, 102, 102));
            }
        }
    }

    public void actionPerformed(ActionEvent ae) {

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel = new javax.swing.JPanel();
        jpnl_1 = new javax.swing.JPanel();
        lbl_1_date = new javax.swing.JLabel();
        lbl_1_s_3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lbl_1_s_2 = new javax.swing.JLabel();
        lbl_1_s_1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jpnl_2 = new javax.swing.JPanel();
        lbl_2_date = new javax.swing.JLabel();
        lbl_2_s_3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lbl_2_s_2 = new javax.swing.JLabel();
        lbl_2_s_1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jpnl_7 = new javax.swing.JPanel();
        lbl_7_s_1 = new javax.swing.JLabel();
        lbl_7_s_2 = new javax.swing.JLabel();
        lbl_7_s_3 = new javax.swing.JLabel();
        lbl_7_date = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jpnl_4 = new javax.swing.JPanel();
        lbl_4_date = new javax.swing.JLabel();
        lbl_4_s_3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lbl_4_s_2 = new javax.swing.JLabel();
        lbl_4_s_1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jpnl_5 = new javax.swing.JPanel();
        lbl_5_date = new javax.swing.JLabel();
        lbl_5_s_3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lbl_5_s_2 = new javax.swing.JLabel();
        lbl_5_s_1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jpnl_3 = new javax.swing.JPanel();
        lbl_3_date = new javax.swing.JLabel();
        lbl_3_s_3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lbl_3_s_2 = new javax.swing.JLabel();
        lbl_3_s_1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jpnl_6 = new javax.swing.JPanel();
        lbl_6_date = new javax.swing.JLabel();
        lbl_6_s_3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lbl_6_s_2 = new javax.swing.JLabel();
        lbl_6_s_1 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jlist_doc_pro = new javax.swing.JList<>();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel.setBackground(new java.awt.Color(1, 23, 23));

        jpnl_1.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_1.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_1.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_1.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_1_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_1_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_1_date.setText("Saturday:");
        lbl_1_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_1_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_1_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_1_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_1_s_3.setText("empty");
        lbl_1_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_1_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_1_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_1_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 153));

        lbl_1_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_1_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_1_s_2.setText("empty");
        lbl_1_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_1_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_1_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_1_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_1_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_1_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_1_s_1.setText("empty");
        lbl_1_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_1_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_1_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_1_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_1Layout = new javax.swing.GroupLayout(jpnl_1);
        jpnl_1.setLayout(jpnl_1Layout);
        jpnl_1Layout.setHorizontalGroup(
            jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_1Layout.createSequentialGroup()
                        .addComponent(lbl_1_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_1_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_1_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_1_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jpnl_1Layout.setVerticalGroup(
            jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_1Layout.createSequentialGroup()
                .addGroup(jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_1_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_1_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_1_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_1_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_2.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_2.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_2.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_2.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_2_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_2_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_2_date.setText("Sunday:");
        lbl_2_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_2_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_2_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_2_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_2_s_3.setText("empty");
        lbl_2_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_2_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_2_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_2_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 153));

        lbl_2_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_2_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_2_s_2.setText("empty");
        lbl_2_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_2_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_2_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_2_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_2_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_2_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_2_s_1.setText("empty");
        lbl_2_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_2_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_2_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_2_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_2Layout = new javax.swing.GroupLayout(jpnl_2);
        jpnl_2.setLayout(jpnl_2Layout);
        jpnl_2Layout.setHorizontalGroup(
            jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_2Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_2Layout.createSequentialGroup()
                        .addComponent(lbl_2_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_2_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_2_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_2_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jpnl_2Layout.setVerticalGroup(
            jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_2Layout.createSequentialGroup()
                .addGroup(jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_2Layout.createSequentialGroup()
                        .addComponent(lbl_2_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jpnl_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_2_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_2_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_2_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_7.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_7.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_7.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_7.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_7.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_7_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_7_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_7_s_1.setText("empty");
        lbl_7_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_7_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_7_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_7_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_7_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_7_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_7_s_2.setText("empty");
        lbl_7_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_7_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_7_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_7_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_7_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_7_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_7_s_3.setText("empty");
        lbl_7_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_7_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_7_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_7_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        lbl_7_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_7_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_7_date.setText("Friday:");
        lbl_7_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_7_date.setMinimumSize(new java.awt.Dimension(200, 22));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 153));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_7Layout = new javax.swing.GroupLayout(jpnl_7);
        jpnl_7.setLayout(jpnl_7Layout);
        jpnl_7Layout.setHorizontalGroup(
            jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_7Layout.createSequentialGroup()
                        .addComponent(lbl_7_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_7_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_7_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_7_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnl_7Layout.setVerticalGroup(
            jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_7Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_7_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_7_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_7_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_7_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_4.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_4.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_4.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_4.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_4_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_4_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_4_date.setText("Tuesday: ");
        lbl_4_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_4_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_4_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_4_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_4_s_3.setText("empty");
        lbl_4_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_4_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_4_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_4_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 153));

        lbl_4_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_4_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_4_s_2.setText("empty");
        lbl_4_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_4_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_4_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_4_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_4_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_4_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_4_s_1.setText("empty");
        lbl_4_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_4_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_4_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_4_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_4Layout = new javax.swing.GroupLayout(jpnl_4);
        jpnl_4.setLayout(jpnl_4Layout);
        jpnl_4Layout.setHorizontalGroup(
            jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_4Layout.createSequentialGroup()
                        .addComponent(lbl_4_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_4_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_4_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_4_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jpnl_4Layout.setVerticalGroup(
            jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_4Layout.createSequentialGroup()
                .addGroup(jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_4_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_4_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_4_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_4_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_5.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_5.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_5.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_5.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_5.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_5_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_5_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_5_date.setText("Wednesday");
        lbl_5_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_5_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_5_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_5_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_5_s_3.setText("empty");
        lbl_5_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_5_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_5_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_5_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 153));

        lbl_5_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_5_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_5_s_2.setText("empty");
        lbl_5_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_5_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_5_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_5_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_5_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_5_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_5_s_1.setText("empty");
        lbl_5_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_5_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_5_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_5_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_5Layout = new javax.swing.GroupLayout(jpnl_5);
        jpnl_5.setLayout(jpnl_5Layout);
        jpnl_5Layout.setHorizontalGroup(
            jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_5Layout.createSequentialGroup()
                        .addComponent(lbl_5_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_5_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_5_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_5_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jpnl_5Layout.setVerticalGroup(
            jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_5Layout.createSequentialGroup()
                .addGroup(jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_5_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_5_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_5_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_5_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_3.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_3.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_3.setMaximumSize(new java.awt.Dimension(420, 84));
        jpnl_3.setMinimumSize(new java.awt.Dimension(420, 84));

        lbl_3_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_3_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_3_date.setText("Monday:");
        lbl_3_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_3_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_3_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_3_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_3_s_3.setText("empty");
        lbl_3_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_3_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_3_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_3_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 153));

        lbl_3_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_3_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_3_s_2.setText("empty");
        lbl_3_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_3_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_3_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_3_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_3_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_3_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_3_s_1.setText("empty");
        lbl_3_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_3_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_3_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_3_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_3Layout = new javax.swing.GroupLayout(jpnl_3);
        jpnl_3.setLayout(jpnl_3Layout);
        jpnl_3Layout.setHorizontalGroup(
            jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_3Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_3Layout.createSequentialGroup()
                        .addComponent(lbl_3_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_3_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_3_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_3_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jpnl_3Layout.setVerticalGroup(
            jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_3Layout.createSequentialGroup()
                .addGroup(jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_3_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_3_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_3_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_3_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jpnl_6.setBackground(new java.awt.Color(19, 43, 43));
        jpnl_6.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jpnl_6.setForeground(new java.awt.Color(21, 41, 41));
        jpnl_6.setMaximumSize(new java.awt.Dimension(444, 89));
        jpnl_6.setMinimumSize(new java.awt.Dimension(444, 89));

        lbl_6_date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbl_6_date.setForeground(new java.awt.Color(255, 204, 102));
        lbl_6_date.setText("Thursday:");
        lbl_6_date.setMaximumSize(new java.awt.Dimension(200, 22));
        lbl_6_date.setMinimumSize(new java.awt.Dimension(200, 22));

        lbl_6_s_3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_6_s_3.setForeground(new java.awt.Color(255, 204, 102));
        lbl_6_s_3.setText("empty");
        lbl_6_s_3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_6_s_3.setMaximumSize(new java.awt.Dimension(120, 30));
        lbl_6_s_3.setMinimumSize(new java.awt.Dimension(120, 30));
        lbl_6_s_3.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 153));

        lbl_6_s_2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_6_s_2.setForeground(new java.awt.Color(255, 204, 102));
        lbl_6_s_2.setText("empty");
        lbl_6_s_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_6_s_2.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_6_s_2.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_6_s_2.setPreferredSize(new java.awt.Dimension(129, 32));

        lbl_6_s_1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_6_s_1.setForeground(new java.awt.Color(255, 204, 102));
        lbl_6_s_1.setText("empty");
        lbl_6_s_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Slot 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N
        lbl_6_s_1.setMaximumSize(new java.awt.Dimension(129, 32));
        lbl_6_s_1.setMinimumSize(new java.awt.Dimension(129, 32));
        lbl_6_s_1.setPreferredSize(new java.awt.Dimension(129, 32));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jpnl_6Layout = new javax.swing.GroupLayout(jpnl_6);
        jpnl_6.setLayout(jpnl_6Layout);
        jpnl_6Layout.setHorizontalGroup(
            jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_6Layout.createSequentialGroup()
                        .addComponent(lbl_6_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(lbl_6_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_6_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_6_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jpnl_6Layout.setVerticalGroup(
            jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_6Layout.createSequentialGroup()
                .addGroup(jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_6_date, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnl_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_6_s_3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_6_s_2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_6_s_1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        jlist_doc_pro.setBackground(new java.awt.Color(1, 23, 23));
        jlist_doc_pro.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jlist_doc_pro.setForeground(new java.awt.Color(255, 255, 153));
        jScrollPane1.setViewportView(jlist_doc_pro);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 255, 153));
        jLabel3.setText("Schedule Details");

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton2.setForeground(new java.awt.Color(204, 204, 255));
        jButton2.setText("Close");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jpnl_5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jpnl_4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jpnl_6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jpnl_7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 0, 0))
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jpnl_4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addComponent(jpnl_5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelLayout.createSequentialGroup()
                        .addComponent(jpnl_1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnl_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnl_7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        view_schedule = null;
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
//        try {
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
//        } catch (Exception ex) {
//
//        }
//        try {
//            UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
//        } catch (Exception e) {
//        }

//            // If Nimbus is not available, you can set the GUI to another look and feel.
//        }
//        try {
//            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (Exception e) {
//            // If Nimbus is not available, you can set the GUI to another look and feel.
//        }
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");
//        } catch (UnsupportedLookAndFeelException e) {
//            // handle exception
//        } catch (ClassNotFoundException e) {
//            // handle exception
//        } catch (InstantiationException e) {
//            // handle exception
//        } catch (IllegalAccessException e) {
//            // handle exception
//        }
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(View_Doc_Schedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(View_Doc_Schedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(View_Doc_Schedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(View_Doc_Schedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                (view_schedule = new ViewDocSchedule(0)).setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> jlist_doc_pro;
    private javax.swing.JPanel jpnl_1;
    private javax.swing.JPanel jpnl_2;
    private javax.swing.JPanel jpnl_3;
    private javax.swing.JPanel jpnl_4;
    private javax.swing.JPanel jpnl_5;
    private javax.swing.JPanel jpnl_6;
    private javax.swing.JPanel jpnl_7;
    private javax.swing.JLabel lbl_1_date;
    private javax.swing.JLabel lbl_1_s_1;
    private javax.swing.JLabel lbl_1_s_2;
    private javax.swing.JLabel lbl_1_s_3;
    private javax.swing.JLabel lbl_2_date;
    private javax.swing.JLabel lbl_2_s_1;
    private javax.swing.JLabel lbl_2_s_2;
    private javax.swing.JLabel lbl_2_s_3;
    private javax.swing.JLabel lbl_3_date;
    private javax.swing.JLabel lbl_3_s_1;
    private javax.swing.JLabel lbl_3_s_2;
    private javax.swing.JLabel lbl_3_s_3;
    private javax.swing.JLabel lbl_4_date;
    private javax.swing.JLabel lbl_4_s_1;
    private javax.swing.JLabel lbl_4_s_2;
    private javax.swing.JLabel lbl_4_s_3;
    private javax.swing.JLabel lbl_5_date;
    private javax.swing.JLabel lbl_5_s_1;
    private javax.swing.JLabel lbl_5_s_2;
    private javax.swing.JLabel lbl_5_s_3;
    private javax.swing.JLabel lbl_6_date;
    private javax.swing.JLabel lbl_6_s_1;
    private javax.swing.JLabel lbl_6_s_2;
    private javax.swing.JLabel lbl_6_s_3;
    private javax.swing.JLabel lbl_7_date;
    private javax.swing.JLabel lbl_7_s_1;
    private javax.swing.JLabel lbl_7_s_2;
    private javax.swing.JLabel lbl_7_s_3;
    // End of variables declaration//GEN-END:variables
}
