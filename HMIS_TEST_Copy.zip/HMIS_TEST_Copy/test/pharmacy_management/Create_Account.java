/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy_management;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.DriverManager;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import static pharmacy_management.Home_PM.acknowledgement_Or_Warning;
import static pharmacy_management.Pharmacy_Management.*;
import static pharmacy_management.Home_PM.*;

/**
 *
 * @author pddrgj3q
 */
public class Create_Account extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form Create_Account
     */
//    public Create_Account(String str) {
//        System.out.println("str to be printed  >" +str);
//    }
    public Create_Account(String str) {
        
        initComponents();

        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        btn_home.addActionListener(this);
        btn_done.addActionListener(this);
        lbl_account_panel.setText(str);
        btn_done.setContentAreaFilled(false);
        btn_show1.addActionListener(this);
        btn_show2.addActionListener(this);
        jPasswordField1.setEchoChar('*');
        jPasswordField2.setEchoChar('*' );
          
        
        if (str == "Create Account") {
            jPasswordField2.setVisible(true);

        }
        if (str == "Log In") {
            System.out.println(" if con works !");
            jPasswordField2.setVisible(false);
            btn_show2.setVisible(false);
            jLabel3.setVisible(false);
        }
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();

            }

        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {

                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == btn_done) {
            check_And_Save_Account();
        }
        if (ae.getSource() == btn_home) {
            dispose();
            //System.exit(0);
        }
        if (ae.getSource() == btn_show1) {
            jPasswordField1.setEchoChar((char) 0);

            if (btn_show1.getText().equals("show")){

                jPasswordField1.setEchoChar((char) 0);
                btn_show1.setText("hide");
            } else {
                jPasswordField1.setEchoChar(('*'));
                btn_show1.setText("show");
            }
        }
        if (ae.getSource() == btn_show2) {
            if (btn_show2.getIcon().toString().endsWith("show_pass.png")) {
                 jPasswordField2.setEchoChar((char) 0);
                btn_show2.setIcon(new ImageIcon(getClass().getResource("hide.png")));
            }
            else {
                jPasswordField2.setEchoChar(('*'));
                btn_show2.setIcon(new ImageIcon(getClass().getResource("show_pass.png")));
            }
           
        }

    }

    public void check_And_Save_Account() {

        String account_name, pass, pass2;

        if (lbl_account_panel.getText() == "Create Account") {

            if ((account_name = txt_account_name.getText()).equals("") || (pass = String.valueOf(jPasswordField1.getPassword())).equals("")) {

                status_In_Time("Account Creation With What ?", 1800);
                lbl_missed_field.setSize(180, 30);
            } else if (!pass.equals(String.valueOf(jPasswordField2.getPassword()))) {
                status_In_Time("Password Mismatch", 1800);
            } else {

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Pharmacy_Management.con = DriverManager.getConnection(url + dbName, userName, password);

                    Pharmacy_Management.st = Pharmacy_Management.con.createStatement();
                    Pharmacy_Management.pst = Pharmacy_Management.con.prepareStatement("insert into admins values(?,?)");

                    Pharmacy_Management.pst.setString(1, account_name);
                    Pharmacy_Management.pst.setString(2, pass);

                    Pharmacy_Management.pst.executeUpdate();
                    Pharmacy_Management.con.close();
                    Pharmacy_Management.st.close();

                } catch (Exception ex) {
                    System.out.println("bbb> " + ex.getMessage());
                }
                lbl_missed_field.setHorizontalAlignment(lbl_missed_field.CENTER);

                lbl_missed_field.setText("Got It !");
            }
        }

        if (lbl_account_panel.getText() == "Log In") {
            System.out.println("pokath");

            if ((account_name = txt_account_name.getText()).equals("") || (pass = String.valueOf(jPasswordField1.getPassword())).equals("")) {

                status_In_Time("LogIn With Empty Field ?", 1500);
                lbl_missed_field.setSize(180, 30);
            } else {

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(url + dbName, userName, password);
                    st = con.createStatement();
                    query = "SELECT * FROM admins";

                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        System.out.println(rs.getString("name") + "  ??????" + rs.getString("pass"));
                        if (account_name.equals(rs.getString("name")) && pass.equals(rs.getString("pass"))) {
                            status_In_Time("Logged In ", 950);

                        } else {
                            status_In_Time("Wrong Pass , Try Again ", 1000);
                            jPasswordField1.setText("");
                        }
                    }

                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }

            }
        }
    }

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_missed_field.setText("");

                if (i == 950) {
                    admin_status = true;
                    home_obj.change_In_Account();
                    dispose();
                }

            }
        }).start();
        lbl_missed_field.setText(str);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPasswordField1 = new javax.swing.JPasswordField();
        txt_account_name = new javax.swing.JTextField();
        lbl_account_panel = new javax.swing.JLabel();
        btn_done = new javax.swing.JButton();
        btn_home = new javax.swing.JButton();
        lbl_missed_field = new javax.swing.JLabel();
        jPasswordField2 = new javax.swing.JPasswordField();
        btn_show1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btn_show2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPasswordField1.setBackground(new java.awt.Color(204, 204, 255));
        jPasswordField1.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jPasswordField1.setForeground(new java.awt.Color(0, 0, 0));
        jPasswordField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPasswordField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPasswordField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordField1FocusLost(evt);
            }
        });

        txt_account_name.setBackground(new java.awt.Color(204, 204, 255));
        txt_account_name.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        txt_account_name.setForeground(new java.awt.Color(0, 0, 0));
        txt_account_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_account_name.setText("Name Or Email");
        txt_account_name.setToolTipText("Name Or Email");
        txt_account_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_account_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_account_nameFocusLost(evt);
            }
        });

        lbl_account_panel.setBackground(new java.awt.Color(195, 229, 228));
        lbl_account_panel.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        lbl_account_panel.setForeground(new java.awt.Color(204, 255, 153));

        btn_done.setBackground(new java.awt.Color(204, 204, 255));
        btn_done.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_done.setForeground(new java.awt.Color(0, 0, 0));
        btn_done.setText("Done");
        btn_done.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_doneActionPerformed(evt);
            }
        });

        btn_home.setBackground(new java.awt.Color(0, 51, 51));
        btn_home.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lbl_missed_field.setBackground(new java.awt.Color(204, 204, 255));
        lbl_missed_field.setFont(new java.awt.Font("MingLiU_HKSCS-ExtB", 1, 11)); // NOI18N
        lbl_missed_field.setForeground(new java.awt.Color(0, 0, 0));
        lbl_missed_field.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jPasswordField2.setBackground(new java.awt.Color(204, 204, 255));
        jPasswordField2.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jPasswordField2.setForeground(new java.awt.Color(0, 0, 0));
        jPasswordField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPasswordField2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPasswordField2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordField2FocusLost(evt);
            }
        });

        btn_show1.setBackground(new java.awt.Color(0, 51, 51));
        btn_show1.setForeground(new java.awt.Color(204, 255, 153));
        btn_show1.setText("show");
        btn_show1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_show1.setBorderPainted(false);
        btn_show1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_show1ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacy_management/web-user.jpg"))); // NOI18N

        btn_show2.setBackground(new java.awt.Color(0, 51, 51));
        btn_show2.setForeground(new java.awt.Color(204, 255, 153));
        btn_show2.setText("show");
        btn_show2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_show2.setBorderPainted(false);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 0, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 163, 163));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel2.setText("password:");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel2.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 0, 0, new java.awt.Color(0, 153, 153)));

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 0, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 163, 163));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel3.setText("Confirm Password:");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel3.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 0, 0, new java.awt.Color(0, 153, 153)));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(lbl_missed_field, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(71, 71, 71)
                                    .addComponent(lbl_account_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(22, 22, 22)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel1)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt_account_name, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(btn_show1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btn_show2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGap(30, 30, 30)))
                    .addComponent(btn_home, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(btn_home, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_account_panel)
                .addGap(0, 0, 0)
                .addComponent(lbl_missed_field, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_account_name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_show1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_show2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btn_done, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(79, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(97, 97, 97))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_account_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_account_nameFocusGained
        // TODO add your handling code here:
        if (txt_account_name.getText().equals("Name Or Email")) {
            txt_account_name.setText("");
        }
    }//GEN-LAST:event_txt_account_nameFocusGained

    private void txt_account_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_account_nameFocusLost
        // TODO add your handling code here:

        if (txt_account_name.getText().equals("")) {
            txt_account_name.setText("Name Or Email");
        }
    }//GEN-LAST:event_txt_account_nameFocusLost

    private void jPasswordField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField1FocusGained
        // TODO add your handling code here:
//        System.out.println("focus gained ...");
//         
//        
//        if (String.valueOf(jPasswordField1.getPassword()).equals("password here")) {
//            System.out.println("pass here");
//            jPasswordField1.setText("");
//            jPasswordField1.setEchoChar('*');
//        }
    }//GEN-LAST:event_jPasswordField1FocusGained

    private void jPasswordField2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField2FocusGained
        // TODO add your handling code here:
//        if (String.valueOf(jPasswordField2.getPassword()).equals("confirm password")) {
//            jPasswordField2.setText("");
//             jPasswordField2.setEchoChar('*');
//        }
    }//GEN-LAST:event_jPasswordField2FocusGained

    private void jPasswordField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField1FocusLost
        // TODO add your handling code here:
//        if (String.valueOf(jPasswordField1.getPassword()).equals("")) {
//            jPasswordField1.setText("password here");
//            jPasswordField1.setEchoChar((char)0);
//        }

    }//GEN-LAST:event_jPasswordField1FocusLost

    private void jPasswordField2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField2FocusLost
        // TODO add your handling code here:
//        if (String.valueOf(jPasswordField2.getPassword()).equals("")) {
//            jPasswordField2.setText("confirm password");
//        }
    }//GEN-LAST:event_jPasswordField2FocusLost

    private void btn_show1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_show1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_show1ActionPerformed

    private void btn_doneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_doneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_doneActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Create_Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Create_Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Create_Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Create_Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Create_Account("Log In").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_done;
    private javax.swing.JButton btn_home;
    private javax.swing.JButton btn_show1;
    private javax.swing.JButton btn_show2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JLabel lbl_account_panel;
    private javax.swing.JLabel lbl_missed_field;
    private javax.swing.JTextField txt_account_name;
    // End of variables declaration//GEN-END:variables
}
