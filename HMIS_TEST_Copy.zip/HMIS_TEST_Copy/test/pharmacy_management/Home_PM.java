package pharmacy_management;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import static pharmacy_management.Pharmacy_Management.*;

/**
 *
 * @author pddrgj3q
 */
public class Home_PM extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form Home
     *
     *
     */
//    public Home_PM(boolean i) {
//        btn_remove.setEnabled(true);
//        btn_modify.setEnabled(true);
//    }
    static Home_PM home_obj;
    static JButton btn_minn, btn_exitt, btn_gap;

    public Home_PM() {
        try {

            initComponents();
            setVisible(true);
            setDefaultCloseOperation(1);
            setResizable(false);
            setLocationRelativeTo(null);
            btn_record_sale.addActionListener(this);
            btn_clear.addActionListener(this);
            btn_All_Drugs.addActionListener(this);
            btn_modify.addActionListener(this);
            btn_record_event.addActionListener(this);
            btn_remove.addActionListener(this);
            btn_search.addActionListener(this);
            btn_save.addActionListener(this);
            jspn_expr_date.setEditor(new JSpinner.DateEditor(jspn_expr_date, "dd-MM-yyyy"));
            jspn_expr_date.setDate(new Date());
            jspn_exp_date_at_view.setEditor(new JSpinner.DateEditor(jspn_exp_date_at_view, "dd-MM-yyyy"));
            jspn_exp_date_at_view.setDate(new Date());
            btn_All_Drugs.setBorder(new EmptyBorder(10, 5, 10, 5)); //10 is the radius
            btn_All_Drugs.addActionListener(this);
            jMenu1.addActionListener(this);
            login_menu_item.addActionListener(this);
            exit_menu_Item.addActionListener(this);
            create_acc_menu_item.addActionListener(this);
            setting_menu_item.addActionListener(this);

            btn_remove.setVisible(admin_status);
            btn_modify.setVisible(admin_status);
            btn_sale_records.addActionListener(this);
            btn_exp_before_list.addActionListener(this);
            btn_Modify_Sale.addActionListener(this);
            btn_com_list.addActionListener(this);
            chk_pcs.addActionListener(this);
            chk_sheet.addActionListener(this);
            btn_tbl_to_Tostorage.addActionListener(this);
            jspn_num_sheet.setEnabled(false);
            jspn_num_pcs.setEnabled(false);
            jspn_extra_pcs.setEnabled(false);
            jspn_pcs_per_sheet.setEnabled(false);
            // jspn_num_sheet.setEnabled(false);

            btn_exitt = new JButton(" X ");

            btn_exitt.setBackground(Color.BLACK);
            btn_exitt.setFont(new Font("Segoe UI Black", Font.BOLD, 15));

            btn_exitt.setBorder(new EmptyBorder(1, 1, 1, 1));
            btn_exitt.setForeground(Color.CYAN);

            btn_minn = new JButton(" Min ");
            btn_minn.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
            btn_minn.setBorder(new EmptyBorder(1, 1, 1, 1));
            btn_minn.setBackground(Color.BLACK);
            btn_minn.setForeground(Color.CYAN);
            btn_exitt.addActionListener(this);
            btn_minn.addActionListener(this);

            jMenuBar1.add(btn_minn);
            jMenuBar1.add(btn_exitt);

            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent me) {
                    // Get x,y and store them
                    pX = me.getX();
                    pY = me.getY();
                }
            });
            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent me) {
                    setLocation(getLocation().x + me.getX() - pX,
                            getLocation().y + me.getY() - pY);
                }
            });
            view_Drugs();
        } catch (Exception e) {
            System.out.println(e.getStackTrace()[1].getLineNumber() + "   ???????????");
        }
        // launh_xamp();
        get_Company_Names(0);
    }

    public void launh_xamp() {

        String line;
        String pidInfo = "";

        try {
            Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\" + "tasklist.exe");
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

            while ((line = input.readLine()) != null) {
                pidInfo += line;
            }
            input.close();
            if (!pidInfo.contains("xampp-control.exe")) {

                Runtime runtime = Runtime.getRuntime();
                runtime.exec("xampp-control.exe");
                System.out.println("Executed !!");
            }
        } catch (Exception ex) {
            System.out.println("exception at launching xampp");
        }

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == btn_exitt) {
            System.exit(0);
        }
        if (ae.getSource() == btn_minn) {
            setState(1);
        }

        if (ae.getSource() == chk_sheet) {
            if (chk_sheet.isSelected()) {
                lbl_mrp.setText("MRP/sheet:");
                jspn_extra_pcs.setEnabled(true);
                jspn_pcs_per_sheet.setEnabled(true);
                jspn_num_sheet.setEnabled(true);
                jspn_num_pcs.setEnabled(false);
                chk_pcs.setSelected(false);
            }
            if (!chk_sheet.isSelected()) {
                jspn_extra_pcs.setEnabled(false);
                jspn_pcs_per_sheet.setEnabled(false);
                jspn_num_sheet.setEnabled(false);
            }
        }
        if (ae.getSource() == chk_pcs) {
            if (chk_pcs.isSelected()) {

                lbl_mrp.setText("MRP/pc:");
                jspn_num_pcs.setEnabled(true);
                jspn_extra_pcs.setEnabled(false);
                jspn_pcs_per_sheet.setEnabled(false);
                jspn_num_sheet.setEnabled(false);
                chk_sheet.setSelected(false);
            }
            if (!chk_pcs.isSelected()) {
                jspn_num_pcs.setEnabled(false);
            }
        }
        if (ae.getSource() == btn_search) {

            get_Searching_Job_Done();
        }
        if (ae.getSource() == btn_tbl_to_Tostorage) {

            to_StorageFromTable();
        }
        if (ae.getSource() == btn_exp_before_list) {

            list_By_Exp_Date();
        }
        if (ae.getSource() == btn_Modify_Sale) {
            Modify_Sale();
        }
        if (ae.getSource() == btn_com_list) {
            show_companies();
        }

        if (ae.getSource() == create_acc_menu_item) {

            check_to_MakeAccount();
        }
        if (ae.getSource() == login_menu_item) {
            if (login_menu_item.getText().equals("Admin LogIn")) {
                Create_Account login_obj = new Create_Account("Log In");
                System.out.println("admin log >>> in ");
            }
            if (login_menu_item.getText().equals("Admin LogOut")) {

                String[] buttons = {"Sure", "Cancel"};

                int rc = JOptionPane.showOptionDialog(null, "Sure To Log Out ?", "Confirmation",
                        JOptionPane.WARNING_MESSAGE, 0, null, buttons, buttons[0]);
                if (rc == 0) {
                    System.out.println("log_Out sure  >>>");
                    admin_status = false;
                    change_In_Account();
                }
            }
        }
        if (ae.getSource() == setting_menu_item) {

        }
        if (ae.getSource() == btn_sale_records) {
            Sale_Records obj = new Sale_Records();

        }

        if (ae.getSource() == exit_menu_Item) {
            System.exit(0);
        }
        if (ae.getSource() == btn_save) {
            save_New_Drug();
        }
        if (ae.getSource() == btn_clear) {
            clear_Form();
        }
        if (ae.getSource() == btn_remove) {
            remove_Drug();
        }
        if (ae.getSource() == btn_All_Drugs) {
            view_Drugs();
        }
        if (ae.getSource() == btn_modify) {
            modify_Info();
        }

        if (ae.getSource() == btn_record_sale) {
            Color transparent = new Color(((float) 1.0), ((float) 1.0), ((float) 1.0), ((float) 0.25));
            setBackground(transparent);
            call_For_sale_Record();

        }

    }

    public void to_StorageFromTable() {

        sign = false;

        if (!lbl_tbl_title.getText().equals("All Drugs")) {
            view_Drugs();
            sign = true;
        }
        if (tbl_Result_Exhibition.getSelectedRows().length == 0 && sign == false) {
            acknowledgement_Or_Warning("Select First", 1000);
        }
        if (tbl_Result_Exhibition.getSelectedRows().length == 1) {

            int i = tbl_Result_Exhibition.getSelectedRow();

            drug_name = tbl_Result_Exhibition.getValueAt(i, 0).toString();
            drug_group = tbl_Result_Exhibition.getValueAt(i, 1).toString();
            com_name = tbl_Result_Exhibition.getValueAt(i, 2).toString();
            date_Format = new SimpleDateFormat("dd-MM-yyyy");

            try {
                exp_date = date_Format.parse((String) tbl_Result_Exhibition.getValueAt(i, 4));
            } catch (ParseException pex) {
                acknowledgement_Or_Warning("PEX in modify sale", 1500);

            }
            txt_com_name.setText(com_name);
            txt_com_name.setEditable(false);
            txt_drug_name.setText(drug_name);
            txt_group_name.setText(drug_group);
            jspn_expr_date.setDate(exp_date);

        }

    }

    public void Modify_Sale() {
        sign = false;
        date_Format = new SimpleDateFormat("dd-MM-yyyy");
        if (!lbl_tbl_title.getText().endsWith("Sale Records")) {
            show_All_Sale_Records();
            acknowledgement_Or_Warning("Now Select A sale ", 1000);
        } else if (tbl_Result_Exhibition.getSelectedRow() == -1) {
            acknowledgement_Or_Warning("Select a Sale Record", 2000);
        } else {
            int ind = tbl_Result_Exhibition.getSelectedRow();
            try {
                exp_date = date_Format.parse((String) tbl_Result_Exhibition.getValueAt(ind, 0));
            } catch (ParseException pex) {
                acknowledgement_Or_Warning("PEX in modify sale", 1500);

            }

            drug_name = tbl_Result_Exhibition.getValueAt(ind, 1).toString();
            drug_group = tbl_Result_Exhibition.getValueAt(ind, 2).toString();
            bill = Integer.parseInt(tbl_Result_Exhibition.getValueAt(ind, 4).toString());
            quantity = tbl_Result_Exhibition.getValueAt(ind, 3).toString();
            quantity = quantity.substring(0, quantity.length() - 3);
            quantity = quantity.replace(" ", "");
            System.out.println("q:?" + quantity + "?");
            sign = true;
            Sale sale_form_obj = new Sale();

        }

    }

    public void modify_Info() {
        sign = false;
        System.out.println("Reached");
        if (tbl_Result_Exhibition.getSelectedRow() == -1) {

            acknowledgement_Or_Warning("Select a row (Info To Be Modified)", 1500);
            sign = true;
        }
        if (lbl_tbl_title.getText() != "All Drugs" && lbl_tbl_title.getText() != "Search Result") {
            view_Drugs();
            sign = true;
        }
        if (sign == false) {

            try {
                int i = tbl_Result_Exhibition.getSelectedRow();
                // id = Integer.parseInt(tbl_Result_Exhibition.getValueAt(i, 0).toString());

                drug_name = tbl_Result_Exhibition.getValueAt(i, 1).toString();

                drug_group = tbl_Result_Exhibition.getValueAt(i, 2).toString();
                com_name = tbl_Result_Exhibition.getValueAt(i, 3).toString();
                System.out.println("<<<<<<<<<<<<< " + drug_name);
                date_Format = new SimpleDateFormat("dd-MM-yyyy");
                exp_date = date_Format.parse((String) tbl_Result_Exhibition.getValueAt(i, 4));

                id = Integer.parseInt((String) tbl_Result_Exhibition.getValueAt(i, 0));

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, userName, password);

                st = con.createStatement();
                query = "SELECT * FROM drug_stock WHERE drug_id = " + id + " ";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    quantity = rs.getString("quantity");
                    mrp_per_sheet = Float.parseFloat(rs.getString("mrp"));
                }
                System.out.println("QQQQQQQQQQQQQQQQQQQQQ  ? " + quantity);

                num_sheet = Integer.parseInt(quantity.split("/")[0]);
                num_pcs = Integer.parseInt(quantity.split("/")[1]);

            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            Modify_Info mi = new Modify_Info();

        }

    }

    public void get_Sale_RecordsOnDate(String date) {

        System.out.println(date);

        ResultSet rs_temp;
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<String[]> arr = new ArrayList<String[]>();
        coloumn[0] = "Date";
        coloumn[1] = "Drug Name";
        coloumn[2] = "Group name";
        coloumn[3] = "Quantity";
        coloumn[4] = "Bill";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM sale_records";
            int j = -1;
            rs = st.executeQuery(query);
            while (rs.next()) {
                j++;

                data[0] = rs.getString("date");
                System.out.println(j + "  " + data[0]);
                if (date.equals(data[0])) {

                    data[1] = rs.getString("drug_id");
                    data[3] = rs.getString("quantity");
                    data[4] = rs.getString("bill");

                    query = "SELECT * FROM drug_stock WHERE drug_id = " + Integer.parseInt(data[1]) + "";
                    st = con.createStatement();
                    rs_temp = st.executeQuery(query);
                    System.out.println("bbb" + date + "   " + data[0] + " id: " + data[1]);
                    while (rs_temp.next()) {
                        data[1] = rs_temp.getString("drug_name");
                        data[2] = rs_temp.getString("drug_group");

                    }
                    arr.add(data);

                    dm.addRow(arr.get(0));
                }

            }
        } catch (Exception ex) {
            System.out.println("line: " + ex.getStackTrace()[1].getLineNumber());
            acknowledgement_Or_Warning("Horrror Found!", 3000);
        }
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(82);

        lbl_tbl_title.setText("Sales In Given Time");

    }

    public void get_Sale_RecordsInTime(Date date1, Date date2) {

        ResultSet rs_temp;
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<String[]> arr = new ArrayList<String[]>();
        coloumn[0] = "Date";
        coloumn[1] = "Drug Name";
        coloumn[2] = "Group name";
        coloumn[3] = "Quantity";
        coloumn[4] = "Bill";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM sale_records";
            int j = 0;
            rs = st.executeQuery(query);
            while (rs.next()) {
                j++;

                data[0] = rs.getString("date");

                if (date_Format.parse(data[0]).after(date1) && date2.after(date_Format.parse(data[0]))) {
                    System.out.println("1$   " + date1 + " <<  1 , 2  >> " + date2 + " Valid " + data[0] + "  " + j);
                    data[1] = rs.getString("drug_id");
                    data[3] = rs.getString("quantity");
                    data[4] = rs.getString("bill");
                    query = "SELECT * FROM drug_stock WHERE drug_id = " + Integer.parseInt(data[1]) + "";
                    st = con.createStatement();
                    rs_temp = st.executeQuery(query);
                    while (rs_temp.next()) {
                        data[1] = rs_temp.getString("drug_name");
                        data[2] = rs_temp.getString("drug_group");

                    }
                    arr.add(data);
                    dm.addRow(arr.get(0));
                }

            }
        } catch (Exception ex) {
            System.out.println(ex);
            acknowledgement_Or_Warning("Horrror Found!", 3000);
        }
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(82);

        lbl_tbl_title.setText("Sales In Given Time");

    }

    public void show_All_Sale_Records() {

        ResultSet rs_temp;
        String[] coloumn = new String[5];
        String[] data = new String[5];
        ArrayList<String[]> arr = new ArrayList<String[]>();
        coloumn[0] = "Date";
        coloumn[1] = "Drug Name";
        coloumn[2] = "Group name";
        coloumn[3] = "Quantity";
        coloumn[4] = "Bill";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM sale_records";

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("date");
                data[1] = rs.getString("drug_id");
                data[3] = rs.getString("quantity");
                data[4] = rs.getString("bill");
                query = "SELECT * FROM drug_stock WHERE drug_id = " + Integer.parseInt(data[1]) + "";
                st = con.createStatement();
                rs_temp = st.executeQuery(query);
                while (rs_temp.next()) {
                    data[1] = rs_temp.getString("drug_name");
                    data[2] = rs_temp.getString("drug_group");

                }
                arr.add(data);
                dm.addRow(arr.get(0));

            }
        } catch (Exception ex) {
            System.out.println(ex);

            acknowledgement_Or_Warning("Horrror Found!", 3000);
        }
        //  tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(190);
        //  tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
        // tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(90);

        lbl_tbl_title.setText("Sale Records");

    }

    public void list_By_Exp_Date() {

        int comparison;
        date_Format = new SimpleDateFormat("dd-MM-yyyy");
        String temp_date;
        Date d = jspn_exp_date_at_view.getDate();
        String date = date_Format.format(d);
        System.out.println("date >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + date);

        //    String exp_date = new SimpleDateFormat("dd-MM-yyyy").parse(jspn_exp_date_at_view.getValue().toString()).toString();
        String[] coloumn = new String[5];
        String[] data = new String[7];
        ArrayList<String[]> arr = new ArrayList<String[]>();

        coloumn[0] = "Drug Name";
        coloumn[1] = "Group name";
        coloumn[2] = "ComPany Namy";
        coloumn[3] = "Available";
        coloumn[4] = "MRP";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM drug_stock";

            rs = st.executeQuery(query);

            while (rs.next()) {

                data[0] = rs.getString("drug_name");
                data[1] = rs.getString("drug_group");
                data[2] = rs.getString("company_name");
                data[3] = rs.getString("quantity");
                temp_date = rs.getString("exp_date");
                data[4] = rs.getString("mrp");
                comparison = date.compareTo(data[4]);

                if (d.after(date_Format.parse(temp_date))) {
                    System.out.println(date + " is greater   >>> " + date);
                    arr.add(data);
                    dm.addRow(arr.get(0));
                }

            }
            con.close();
            st.close();
        } catch (Exception ex) {
            System.out.println(ex.getStackTrace()[1].getLineNumber());
            System.out.println(ex);

            acknowledgement_Or_Warning("Horrror Found! At " + ex.getStackTrace()[1].getLineNumber(), 2000);
        }

        //  tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(190);
        //  tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
        // tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(160);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(160);

        table_Title = "Drug Will Be Expired Before " + date;
        lbl_tbl_title.setText(table_Title);

    }

    public void save_New_Drug() {

    }

    public void set_Com_Name(String name) {

        txt_com_name.setText(name);
    }

    public void show_companies() {

        CompanyList obj = new CompanyList();

    }

    public void change_In_Account() {

        btn_modify.setVisible(admin_status);
        btn_remove.setVisible(admin_status);
        if (admin_status == true) {
            login_menu_item.setText("Admin LogOut");
        }
        if (admin_status == false) {
            login_menu_item.setText("Admin LogIn");
        }

    }

    public void check_to_MakeAccount() {

        System.out.println("got the metnod ");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            boolean tata;
            query = "SELECT * FROM admins";

            rs = st.executeQuery(query);
            int account_counter = 0;
            while (rs.next()) {

                account_counter += 1;
            }

            if (account_counter == 0) {
                Create_Account create_Acc_obj = new Create_Account("Create Account");

            } else if (account_counter > 0) {
                String[] buttons = {"LogIn", "Cancel"};

                int rc = JOptionPane.showOptionDialog(null, "Admin Account Already Exist !", "Confirmation",
                        JOptionPane.WARNING_MESSAGE, 0, null, buttons, buttons[0]);
                if (rc == 0) {
                    System.out.println("login  >>>");
                    Create_Account log_In = new Create_Account("Log In");

                }
                if (rc == 1) {
                    System.out.println("got to be cancalled");
                }
//                query = "SELECT * FROM settings";
//                rs = st.executeQuery(query);
//                boolean multiple_Account_status = false;
//                int num;
//                while (rs.next()) {
//
//                    if (Integer.parseInt(rs.getString("multiple_admin_status")) == 1) {
//                        multiple_Account_status = false;
//                        break;
//                    } else {
//                        multiple_Account_status = true;
//                        break;
//                    }
//                }
//                if (multiple_Account_status == true) {
//                    Create_Account create_Acc_obj = new Create_Account();
//                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            acknowledgement_Or_Warning("Horrror Found!", 2000);
        }

    }

    public void call_For_sale_Record() {

        int temp;
        sign = false;

        int len = tbl_Result_Exhibition.getSelectedRows().length;
        sold_drugs = new String[len][5];
        if (lbl_tbl_title.getText() == "Sale Records") {
            view_Drugs();
            sign = true;
        }
        if (sign == false && len == 0) {
            acknowledgement_Or_Warning("Select Drug/Drugs", 2000);
            sign = true;
        }

        if (sign == false) {

            indexes = new ArrayList<Integer>();
            for (int i = 0; i < len; i++) {
                indexes.add(i, tbl_Result_Exhibition.getSelectedRows()[i]);
                temp = indexes.get(i);
                drug_id = Integer.parseInt(tbl_Result_Exhibition.getValueAt(temp, 0).toString());
                drug_name = tbl_Result_Exhibition.getValueAt(temp, 1).toString();
                drug_group = tbl_Result_Exhibition.getValueAt(temp, 2).toString();
                com_name = tbl_Result_Exhibition.getValueAt(temp, 3).toString();
                quantity = tbl_Result_Exhibition.getValueAt(temp, 5).toString();

                sold_drugs[i][0] = String.valueOf(drug_id);
                sold_drugs[i][1] = drug_name;
                sold_drugs[i][2] = drug_group;
                sold_drugs[i][3] = com_name;
                sold_drugs[i][4] = quantity;

                System.out.println("??  >>  >> " + sold_drugs[i][3]);

            }
            Sale sale_form_obj = new Sale();
            System.out.println("after the end ");

        }

    }

    public void clear_table() {
        tbl_Result_Exhibition.clearSelection();
    }

    public void clear_Form() {

    }

    public void remove_Drug() {

        if (!lbl_tbl_title.getText().equals("All Drugs")) {
            acknowledgement_Or_Warning("Select a row From Drug Stock", 2000);
            view_Drugs();
        } else if (tbl_Result_Exhibition.getSelectedRow() == -1) {

            acknowledgement_Or_Warning("Select Drug", 2000);
        } else {

            int result = JOptionPane.showOptionDialog(this, "Are you sure you want to...?", "Removal Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Yes", "No"}, JOptionPane.NO_OPTION);
            if (result == JOptionPane.YES_OPTION) {
                int i = tbl_Result_Exhibition.getSelectedRow();

                int id = Integer.parseInt(tbl_Result_Exhibition.getValueAt(i, 0).toString());

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(url + dbName, userName, password);
                    // st = con.createStatement();
                    System.out.println("Yes Go On");

                    // query = "DELETE FROM drug_stock WHERE drug_id = '" + id + "' ";
                    //  pst = con.prepareStatement(query);
                    //  st.executeQuery(query);
                    //  System.out.println("Deleted");
                    query = "DELETE FROM drug_stock WHERE drug_id = ? ";
                    pst = null;

                    pst = con.prepareStatement(query);
                    pst.setString(1, String.valueOf(id));
                    pst.executeUpdate();

                    ((DefaultTableModel) tbl_Result_Exhibition.getModel()).removeRow(i);

                } catch (Exception ex) {

                }

            }
        }
    }

    public void get_Searching_Job_Done() {

        arr = new ArrayList<String[]>();
        String[] data = new String[7];
        String content = txt_search_content.getText();
        if (content.equals("")) {
            acknowledgement_Or_Warning("Search By What ?", 1500);
        }
        String search_by = cmb_search_By.getSelectedItem().toString();
        lbl_tbl_title.setText("Search Result");
        System.out.println(search_by);
        if (search_by.equals("Drug Name")) {

            String[] coloumn = new String[7];

            arr.clear();

            coloumn[0] = "ID";
            coloumn[1] = "Drug Name";
            coloumn[2] = "Group name";
            coloumn[3] = "ComPany Namy";
            coloumn[4] = "Expire Date";
            coloumn[5] = "Available";
            coloumn[6] = "MRP";

            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, userName, password);
                st = con.createStatement();

                query = "SELECT * FROM drug_stock WHERE drug_name = '" + content + "'";

                rs = st.executeQuery(query);
                while (rs.next()) {

                    data[0] = rs.getString("drug_id");
                    data[1] = rs.getString("drug_name");
                    data[2] = rs.getString("drug_group");
                    data[3] = rs.getString("company_name");
                    data[4] = rs.getString("exp_date");
                    data[5] = rs.getString("quantity");
                    data[6] = rs.getString("mrp");
                    arr.add(data);
                    dm.addRow(arr.get(0));

                }
            } catch (Exception ex) {
                System.out.println(ex.getStackTrace()[1].getLineNumber());
                System.out.println(ex);
                JOptionPane.showMessageDialog(null, ex);
                acknowledgement_Or_Warning("Horrror Found! At " + ex.getStackTrace()[1].getLineNumber(), 2000);
            }
            //  tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(190);
            //  tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
            // tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(150);
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(80);

        }
        System.out.println(search_by + "    2");

        if (search_by.equals("Company Name")) {

            String[] coloumn = new String[7];

            coloumn[0] = "ID";
            coloumn[1] = "Drug Name";
            coloumn[2] = "Group name";
            coloumn[3] = "ComPany Namy";
            coloumn[4] = "Expire Date";
            coloumn[5] = "Available";
            coloumn[6] = "MRP";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, userName, password);
                st = con.createStatement();

                query = "SELECT * FROM drug_stock WHERE company_name = '" + content + "'";

                rs = st.executeQuery(query);
                while (rs.next()) {

                    data[0] = rs.getString("drug_id");
                    data[1] = rs.getString("drug_name");
                    data[2] = rs.getString("drug_group");
                    data[3] = rs.getString("company_name");
                    data[4] = rs.getString("exp_date");
                    data[5] = rs.getString("quantity");
                    data[6] = rs.getString("mrp");
                    arr.add(data);
                    dm.addRow(arr.get(0));

                }
            } catch (Exception ex) {
                System.out.println(ex.getStackTrace()[1].getLineNumber());
                System.out.println(ex);
                JOptionPane.showMessageDialog(null, ex);
                acknowledgement_Or_Warning("Horrror Found! At " + ex.getStackTrace()[1].getLineNumber(), 2000);
            }
        }

        if (search_by.equals("Group Name")) {

            System.out.println(search_by + "    3");

            String[] coloumn = new String[7];

            coloumn[0] = "ID";
            coloumn[1] = "Drug Name";
            coloumn[2] = "Group name";
            coloumn[3] = "ComPany Namy";
            coloumn[4] = "Expire Date";
            coloumn[5] = "Available";
            coloumn[6] = "MRP";

            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, userName, password);
                st = con.createStatement();

                query = "SELECT * FROM drug_stock WHERE drug_group = '" + content + "'";

                rs = st.executeQuery(query);
                while (rs.next()) {

                    data[0] = rs.getString("drug_id");
                    data[1] = rs.getString("drug_name");
                    data[2] = rs.getString("drug_group");
                    data[3] = rs.getString("company_name");
                    data[4] = rs.getString("exp_date");
                    data[5] = rs.getString("quantity");
                    data[6] = rs.getString("mrp");
                    arr.add(data);
                    dm.addRow(arr.get(0));
                    lbl_tbl_title.setText("Search result");
                }
            } catch (Exception ex) {
                System.out.println(ex.getStackTrace()[1].getLineNumber());
                System.out.println(ex);
                JOptionPane.showMessageDialog(null, ex);
                acknowledgement_Or_Warning("Horrror Found! At " + ex.getStackTrace()[1].getLineNumber(), 2000);
            }
        }

        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMinWidth(88);
        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMaxWidth(88);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMinWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(145);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(145);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(80);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(80);

    }

    public void view_Drugs() {

    }

    public void get_Company_Names(int i) {

        Com_Names = new ArrayList<String>();
        String name;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM companies";

            rs = st.executeQuery(query);
            while (rs.next()) {

                name = rs.getString("name");
                name.toLowerCase();
                Com_Names.add(name);

            }
        } catch (Exception ex) {
            System.out.println("at upside"+dbName);
            acknowledgement_Or_Warning("get_Company_Names", 4000);
        }
        if (i == 1) {
            System.out.println("C:>> " + com_name);
            try {

                if (Com_Names.size() == 0 || !Com_Names.contains(com_name)) {
                    pst = con.prepareStatement("insert into companies values(?)");
                    pst.setString(1, com_name);
                    pst.executeUpdate();
                    Com_Names.add(com_name);
                    System.out.println("New Company Name got inserted ");
                    get_Company_Names(0);
                }
            } catch (Exception ex) {
                System.out.println(ex + ex.getStackTrace()[1].toString());
                acknowledgement_Or_Warning("Horrro  tube >> ", 5000);
            }
        }
    }

    static void acknowledgement_Or_Warning(String warning_Msg, int time) {
        jOptionPane = new JOptionPane(warning_Msg, JOptionPane.INFORMATION_MESSAGE);
        final JDialog dialog = jOptionPane.createDialog("pokath!");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                dialog.setVisible(false);

            }
        }).start();
        dialog.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        birthdayEvaluator1 = new com.toedter.calendar.demo.BirthdayEvaluator();
        birthdayEvaluator2 = new com.toedter.calendar.demo.BirthdayEvaluator();
        jCalendarDemo1 = new com.toedter.calendar.demo.JCalendarDemo();
        jMenu4 = new javax.swing.JMenu();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jspn_num_sheet = new com.toedter.components.JSpinField();
        jPanel5 = new javax.swing.JPanel();
        btn_save = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        jspn_pcs_per_sheet = new com.toedter.components.JSpinField();
        txt_drug_name = new javax.swing.JTextField();
        txt_group_name = new javax.swing.JTextField();
        txt_com_name = new javax.swing.JTextField();
        btn_com_list = new javax.swing.JButton();
        btn_tbl_to_Tostorage = new javax.swing.JButton();
        jspn_extra_pcs = new com.toedter.components.JSpinField();
        chk_sheet = new javax.swing.JCheckBox();
        jPanel8 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jspn_expr_date = new com.toedter.calendar.JSpinnerDateEditor();
        txt_dep_id = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lbl_mrp = new javax.swing.JLabel();
        txt_mrp_per_sheet = new javax.swing.JTextField();
        jspn_num_pcs = new com.toedter.components.JSpinField();
        chk_pcs = new javax.swing.JCheckBox();
        btn_com_list3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btn_All_Drugs = new javax.swing.JButton();
        btn_remove = new javax.swing.JButton();
        jspn_exp_date_at_view = new com.toedter.calendar.JSpinnerDateEditor();
        jLabel2 = new javax.swing.JLabel();
        btn_exp_before_list = new javax.swing.JButton();
        btn_modify = new javax.swing.JButton();
        btn_record_sale = new javax.swing.JButton();
        btn_record_event = new javax.swing.JButton();
        btn_Modify_Sale = new javax.swing.JButton();
        btn_sale_records = new javax.swing.JButton();
        btn_dep_list = new javax.swing.JButton();
        btn_new_dep = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        cmb_search_By = new javax.swing.JComboBox<>();
        btn_search = new javax.swing.JButton();
        txt_search_content = new javax.swing.JTextField();
        lbl_tbl_title = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        filler5 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        filler4 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        create_acc_menu_item = new javax.swing.JMenuItem();
        login_menu_item = new javax.swing.JMenuItem();
        setting_menu_item = new javax.swing.JMenuItem();
        exit_menu_Item = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        about_menu_item = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();

        javax.swing.GroupLayout jCalendarDemo1Layout = new javax.swing.GroupLayout(jCalendarDemo1.getContentPane());
        jCalendarDemo1.getContentPane().setLayout(jCalendarDemo1Layout);
        jCalendarDemo1Layout.setHorizontalGroup(
            jCalendarDemo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jCalendarDemo1Layout.setVerticalGroup(
            jCalendarDemo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jMenu4.setText("jMenu4");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(15, 38, 38));

        jPanel3.setBackground(new java.awt.Color(15, 38, 38));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "To Drug Stock", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("MingLiU_HKSCS-ExtB", 0, 14), new java.awt.Color(255, 255, 153))); // NOI18N
        jPanel3.setMaximumSize(new java.awt.Dimension(360, 513));
        jPanel3.setMinimumSize(new java.awt.Dimension(360, 513));

        jspn_num_sheet.setBackground(new java.awt.Color(15, 38, 38));
        jspn_num_sheet.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Num of Sheet:", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 10), new java.awt.Color(204, 255, 153))); // NOI18N

        jPanel5.setBackground(new java.awt.Color(18, 7, 7));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_save.setBackground(new java.awt.Color(2, 20, 20));
        btn_save.setFont(new java.awt.Font("Tunga", 1, 17)); // NOI18N
        btn_save.setForeground(new java.awt.Color(204, 255, 153));
        btn_save.setText("Save");
        btn_save.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_save.setContentAreaFilled(false);
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(2, 20, 20));
        btn_clear.setFont(new java.awt.Font("Tunga", 1, 17)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(204, 255, 153));
        btn_clear.setText("Clear");
        btn_clear.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear.setContentAreaFilled(false);
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jspn_pcs_per_sheet.setBackground(new java.awt.Color(15, 38, 38));
        jspn_pcs_per_sheet.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "pcs / Sheet", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 10), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_drug_name.setBackground(new java.awt.Color(15, 38, 38));
        txt_drug_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_drug_name.setForeground(new java.awt.Color(255, 153, 51));
        txt_drug_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Drug Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_group_name.setBackground(new java.awt.Color(15, 38, 38));
        txt_group_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_group_name.setForeground(new java.awt.Color(255, 153, 51));
        txt_group_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Drug Group", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_com_name.setBackground(new java.awt.Color(15, 38, 38));
        txt_com_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_com_name.setForeground(new java.awt.Color(255, 153, 51));
        txt_com_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Company Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        btn_com_list.setBackground(new java.awt.Color(28, 48, 48));
        btn_com_list.setForeground(new java.awt.Color(204, 255, 153));
        btn_com_list.setText("..");
        btn_com_list.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_tbl_to_Tostorage.setBackground(new java.awt.Color(2, 20, 20));
        btn_tbl_to_Tostorage.setFont(new java.awt.Font("Tunga", 1, 17)); // NOI18N
        btn_tbl_to_Tostorage.setForeground(new java.awt.Color(204, 255, 153));
        btn_tbl_to_Tostorage.setText("Get From Table");
        btn_tbl_to_Tostorage.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_tbl_to_Tostorage.setContentAreaFilled(false);
        btn_tbl_to_Tostorage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tbl_to_TostorageActionPerformed(evt);
            }
        });

        jspn_extra_pcs.setBackground(new java.awt.Color(15, 38, 38));
        jspn_extra_pcs.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Extra pcs", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 10), new java.awt.Color(204, 255, 153))); // NOI18N

        chk_sheet.setBackground(new java.awt.Color(15, 38, 38));
        chk_sheet.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_sheet.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        chk_sheet.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jPanel8.setBackground(new java.awt.Color(15, 38, 38));
        jPanel8.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(2, 83, 83)));

        jLabel6.setBackground(new java.awt.Color(15, 38, 38));
        jLabel6.setFont(new java.awt.Font("Meiryo", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 255, 153));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText(" Exp. Date :");

        jspn_expr_date.setBackground(new java.awt.Color(15, 38, 38));
        jspn_expr_date.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_expr_date.setForeground(new java.awt.Color(255, 204, 102));
        jspn_expr_date.setModel(new javax.swing.SpinnerDateModel());
        jspn_expr_date.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txt_dep_id.setBackground(new java.awt.Color(15, 38, 38));
        txt_dep_id.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_dep_id.setForeground(new java.awt.Color(255, 153, 51));
        txt_dep_id.setAutoscrolls(false);
        txt_dep_id.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 102, 102)), "Dep. ID :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Meiryo", 0, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(txt_dep_id, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(0, 0, 0)
                .addComponent(jspn_expr_date, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jspn_expr_date, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(txt_dep_id, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel7.setBackground(new java.awt.Color(15, 38, 38));

        lbl_mrp.setBackground(new java.awt.Color(15, 38, 38));
        lbl_mrp.setFont(new java.awt.Font("Meiryo", 0, 11)); // NOI18N
        lbl_mrp.setForeground(new java.awt.Color(204, 255, 153));
        lbl_mrp.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_mrp.setText("MRP: ");

        txt_mrp_per_sheet.setBackground(new java.awt.Color(15, 38, 38));
        txt_mrp_per_sheet.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_mrp_per_sheet.setForeground(new java.awt.Color(204, 255, 153));
        txt_mrp_per_sheet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 102, 102)));
        txt_mrp_per_sheet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_mrp_per_sheetActionPerformed(evt);
            }
        });

        jspn_num_pcs.setBackground(new java.awt.Color(15, 38, 38));
        jspn_num_pcs.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Piece:", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 10), new java.awt.Color(204, 255, 153))); // NOI18N

        chk_pcs.setBackground(new java.awt.Color(15, 38, 38));
        chk_pcs.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_pcs.setForeground(new java.awt.Color(204, 255, 153));
        chk_pcs.setBorder(null);
        chk_pcs.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_num_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lbl_mrp, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_mrp_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jspn_num_pcs, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chk_pcs, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_mrp_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_mrp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        btn_com_list3.setBackground(new java.awt.Color(28, 48, 48));
        btn_com_list3.setForeground(new java.awt.Color(204, 255, 153));
        btn_com_list3.setText("..");
        btn_com_list3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_tbl_to_Tostorage, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(chk_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(jspn_num_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(jspn_pcs_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(jspn_extra_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_group_name, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_com_name, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_com_list3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_com_list, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(16, Short.MAX_VALUE))))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(btn_tbl_to_Tostorage, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_com_list3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_group_name))
                .addGap(6, 6, 6)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_com_list, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_com_name))
                .addGap(41, 41, 41)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(chk_sheet, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jspn_num_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_pcs_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_extra_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6))
        );

        jPanel4.setBackground(new java.awt.Color(15, 38, 38));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        btn_All_Drugs.setBackground(new java.awt.Color(0, 14, 14));
        btn_All_Drugs.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_All_Drugs.setForeground(new java.awt.Color(255, 255, 153));
        btn_All_Drugs.setText("View Stock");
        btn_All_Drugs.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_All_Drugs.setContentAreaFilled(false);
        btn_All_Drugs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_All_DrugsActionPerformed(evt);
            }
        });

        btn_remove.setBackground(new java.awt.Color(0, 14, 14));
        btn_remove.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_remove.setForeground(new java.awt.Color(255, 255, 153));
        btn_remove.setText("Remove Drug");
        btn_remove.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_remove.setContentAreaFilled(false);

        jspn_exp_date_at_view.setBackground(new java.awt.Color(0, 51, 51));
        jspn_exp_date_at_view.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_exp_date_at_view.setForeground(new java.awt.Color(204, 255, 153));
        jspn_exp_date_at_view.setModel(new javax.swing.SpinnerDateModel());
        jspn_exp_date_at_view.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N

        jLabel2.setBackground(new java.awt.Color(0, 51, 51));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 255, 153));
        jLabel2.setText(" Expired Before:");

        btn_exp_before_list.setBackground(new java.awt.Color(0, 51, 51));
        btn_exp_before_list.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        btn_exp_before_list.setForeground(new java.awt.Color(204, 102, 0));
        btn_exp_before_list.setText(">>");
        btn_exp_before_list.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_exp_before_list.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exp_before_listActionPerformed(evt);
            }
        });

        btn_modify.setBackground(new java.awt.Color(0, 14, 14));
        btn_modify.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_modify.setForeground(new java.awt.Color(255, 255, 153));
        btn_modify.setText("Modify Drug Info");
        btn_modify.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_modify.setContentAreaFilled(false);

        btn_record_sale.setBackground(new java.awt.Color(0, 14, 14));
        btn_record_sale.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_record_sale.setForeground(new java.awt.Color(255, 255, 153));
        btn_record_sale.setText("Record Sale");
        btn_record_sale.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_record_sale.setContentAreaFilled(false);
        btn_record_sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_record_saleActionPerformed(evt);
            }
        });

        btn_record_event.setBackground(new java.awt.Color(0, 14, 14));
        btn_record_event.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_record_event.setForeground(new java.awt.Color(255, 255, 153));
        btn_record_event.setText("Record Event");
        btn_record_event.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_record_event.setContentAreaFilled(false);

        btn_Modify_Sale.setBackground(new java.awt.Color(0, 14, 14));
        btn_Modify_Sale.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_Modify_Sale.setForeground(new java.awt.Color(255, 255, 153));
        btn_Modify_Sale.setText("Modify Sale ");
        btn_Modify_Sale.setContentAreaFilled(false);
        btn_Modify_Sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Modify_SaleActionPerformed(evt);
            }
        });

        btn_sale_records.setBackground(new java.awt.Color(0, 14, 14));
        btn_sale_records.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_sale_records.setForeground(new java.awt.Color(255, 255, 153));
        btn_sale_records.setText("Sale Records");
        btn_sale_records.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_sale_records.setContentAreaFilled(false);
        btn_sale_records.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sale_recordsActionPerformed(evt);
            }
        });

        btn_dep_list.setBackground(new java.awt.Color(0, 14, 14));
        btn_dep_list.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_dep_list.setForeground(new java.awt.Color(255, 255, 153));
        btn_dep_list.setText("Depositor List");
        btn_dep_list.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_dep_list.setContentAreaFilled(false);
        btn_dep_list.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dep_listActionPerformed(evt);
            }
        });

        btn_new_dep.setBackground(new java.awt.Color(0, 14, 14));
        btn_new_dep.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_new_dep.setForeground(new java.awt.Color(255, 255, 153));
        btn_new_dep.setText("New Depositor");
        btn_new_dep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_dep.setContentAreaFilled(false);
        btn_new_dep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_depActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_modify, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                        .addComponent(jspn_exp_date_at_view, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(btn_exp_before_list, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btn_remove, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_record_event, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_Modify_Sale, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_record_sale, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_dep_list, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_All_Drugs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_new_dep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(btn_sale_records, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btn_All_Drugs, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(btn_dep_list, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(btn_record_sale, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(btn_sale_records, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(btn_remove, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(btn_modify, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jspn_exp_date_at_view, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_exp_before_list, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addComponent(btn_record_event, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(btn_Modify_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        tbl_Result_Exhibition.setBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(255, 255, 153));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setCellSelectionEnabled(true);
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 51, 51));
        tbl_Result_Exhibition.setMaximumSize(new java.awt.Dimension(390, 4840));
        tbl_Result_Exhibition.setMinimumSize(new java.awt.Dimension(390, 840));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setPreferredSize(new java.awt.Dimension(390, 840));
        tbl_Result_Exhibition.setRowHeight(25);
        tbl_Result_Exhibition.setRowMargin(2);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(204, 255, 153));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(153, 51, 0));
        jScrollPane1.setViewportView(tbl_Result_Exhibition);

        cmb_search_By.setBackground(new java.awt.Color(0, 51, 51));
        cmb_search_By.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        cmb_search_By.setForeground(new java.awt.Color(204, 255, 153));
        cmb_search_By.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Drug Name", "Group Name", "Company Name" }));
        cmb_search_By.setOpaque(false);

        btn_search.setBackground(new java.awt.Color(0, 51, 51));
        btn_search.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/to add.jpg"))); // NOI18N
        btn_search.setContentAreaFilled(false);

        txt_search_content.setBackground(new java.awt.Color(15, 38, 38));
        txt_search_content.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_search_content.setForeground(new java.awt.Color(255, 204, 102));
        txt_search_content.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txt_search_content.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_contentActionPerformed(evt);
            }
        });

        lbl_tbl_title.setBackground(new java.awt.Color(0, 0, 0));
        lbl_tbl_title.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lbl_tbl_title.setForeground(new java.awt.Color(255, 255, 153));
        lbl_tbl_title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_tbl_title.setText("All Drugs");

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 51, 51));
        jSeparator1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel5.setBackground(new java.awt.Color(0, 51, 51));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 255, 153));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText(" Search By");

        jPanel6.setBackground(new java.awt.Color(0, 102, 102));
        jPanel6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel6.setMaximumSize(new java.awt.Dimension(360, 115));
        jPanel6.setMinimumSize(new java.awt.Dimension(360, 115));
        jPanel6.setPreferredSize(new java.awt.Dimension(360, 115));

        jLabel1.setBackground(new java.awt.Color(51, 0, 51));
        jLabel1.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Total Sale Today : 1285/=   ");

        jLabel3.setBackground(new java.awt.Color(51, 0, 51));
        jLabel3.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Total Stock : 3,55000/=");

        jLabel4.setBackground(new java.awt.Color(51, 0, 51));
        jLabel4.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("jLabel1");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_tbl_title, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 217, Short.MAX_VALUE)
                        .addComponent(filler5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(85, 85, 85)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(filler5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(lbl_tbl_title, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setBackground(new java.awt.Color(0, 0, 0));
        jMenuBar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 2, true));
        jMenuBar1.setForeground(new java.awt.Color(204, 255, 153));
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jMenu1.setBackground(new java.awt.Color(0, 0, 0));
        jMenu1.setForeground(new java.awt.Color(204, 255, 153));
        jMenu1.setText("File");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMenu1.setPreferredSize(new java.awt.Dimension(38, 19));

        create_acc_menu_item.setBackground(new java.awt.Color(100, 156, 116));
        create_acc_menu_item.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        create_acc_menu_item.setText("Create Admin Account");
        create_acc_menu_item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_acc_menu_itemActionPerformed(evt);
            }
        });
        jMenu1.add(create_acc_menu_item);

        login_menu_item.setBackground(new java.awt.Color(100, 156, 116));
        login_menu_item.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        login_menu_item.setText("Admin LogIn");
        jMenu1.add(login_menu_item);

        setting_menu_item.setBackground(new java.awt.Color(100, 156, 116));
        setting_menu_item.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        setting_menu_item.setText("Settings");
        jMenu1.add(setting_menu_item);

        exit_menu_Item.setBackground(new java.awt.Color(100, 156, 116));
        exit_menu_Item.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        exit_menu_Item.setText("Exit");
        jMenu1.add(exit_menu_Item);

        jMenuBar1.add(jMenu1);

        jMenu2.setBackground(new java.awt.Color(0, 0, 0));
        jMenu2.setForeground(new java.awt.Color(204, 255, 153));
        jMenu2.setText("Edit");
        jMenu2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMenu2.setPreferredSize(new java.awt.Dimension(38, 19));

        jMenuItem2.setBackground(new java.awt.Color(76, 151, 104));
        jMenuItem2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jMenuItem2.setText("Help     ");
        jMenu2.add(jMenuItem2);

        about_menu_item.setBackground(new java.awt.Color(76, 151, 104));
        about_menu_item.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        about_menu_item.setText("About      ");
        jMenu2.add(about_menu_item);

        jMenuBar1.add(jMenu2);

        jMenu3.setBackground(new java.awt.Color(255, 204, 102));
        jMenu3.setForeground(new java.awt.Color(0, 51, 51));
        jMenu3.setText("      ABC Pharmacy  Management System");
        jMenu3.setEnabled(false);
        jMenu3.setFont(new java.awt.Font("MingLiU_HKSCS-ExtB", 1, 14)); // NOI18N
        jMenu3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jMenu3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jMenu3.setPreferredSize(new java.awt.Dimension(1165, 19));
        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_search_contentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_contentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_contentActionPerformed

    private void btn_Modify_SaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Modify_SaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_Modify_SaleActionPerformed

    private void txt_mrp_per_sheetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_mrp_per_sheetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_mrp_per_sheetActionPerformed

    private void btn_exp_before_listActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exp_before_listActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_exp_before_listActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:

        int dep_id = 0;
        String date;
        float mrp = 0;
        date_Format = new SimpleDateFormat("dd-MM-yyyy");
        sign = false;
        //|| ((jSpin_num_sheet.getValue() == 0) && (jSpin_pcs_per_sheet.getValue() == 0)) || (txt_mrp_per_sheet.getText().equals(""))
        if (!chk_pcs.isSelected() && !chk_sheet.isSelected()) {
            acknowledgement_Or_Warning("Set Quantity", 2000);
            sign = true;
        }
        if (chk_pcs.isSelected()) {

            quantity = String.valueOf(jspn_num_pcs.getValue()) + " pcs";
            if (quantity.equals("0")) {
                sign = true;
                acknowledgement_Or_Warning("Required Info Missing", 2000);
            }
        }
        if (chk_sheet.isSelected()) {
            if ((jspn_num_sheet.getValue() == 0 && jspn_extra_pcs.getValue() == 0) || (jspn_num_sheet.getValue() != 0 && jspn_pcs_per_sheet.getValue() == 0)) {
                acknowledgement_Or_Warning("Required Info Missing", 2000);
                sign = true;
            }
            quantity = jspn_num_sheet.getValue() * jspn_pcs_per_sheet.getValue() + jspn_extra_pcs.getValue() + "/" + jspn_pcs_per_sheet.getValue();
        }
        System.out.println("quantity  >>>>? " + quantity);
        if (((drug_name = txt_drug_name.getText()).isEmpty() || (drug_group = txt_group_name.getText()).isEmpty()
                || (com_name = txt_com_name.getText()).isEmpty() || (txt_mrp_per_sheet.getText()).isEmpty()) && sign == false) {
            acknowledgement_Or_Warning("Required Info Missing", 2000);
            sign = true;
        } else if (date_Format.format(exp_date = jspn_expr_date.getDate()).equals(date_Format.format(new Date())) && sign == false) {
            acknowledgement_Or_Warning("Expire_Date can't Be Today", 2000);
            sign = true;
        }
        if (sign == false) {
            try {
                mrp = Float.parseFloat(txt_mrp_per_sheet.getText());
            } catch (Exception ex) {
                acknowledgement_Or_Warning("Invalid mrp value", 2000);
                sign = true;
            }
        }
        if (!txt_dep_id.getText().isEmpty()) {
            try {
                dep_id = Integer.parseInt(txt_dep_id.getText());
            } catch (Exception ex) {
                acknowledgement_Or_Warning("wrong id", 1300);
                System.out.println("exp >>");
            }
        }

        if (sign == false) {

            get_Company_Names(1);

//            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            date = date_Format.format(jspn_expr_date.getDate());

            cal = Calendar.getInstance();
//            dateFormat.format(cal.getTime());
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Pharmacy_Management.con = DriverManager.getConnection(url + dbName, userName, password);

                Pharmacy_Management.st = Pharmacy_Management.con.createStatement();
                Pharmacy_Management.pst = Pharmacy_Management.con.prepareStatement("insert into drug_stock values(?,?,?,?,?,?,?,?)");
                System.out.println(cal.getTime());
                Pharmacy_Management.pst.setInt(1, 0);
                Pharmacy_Management.pst.setString(2, drug_name);
                Pharmacy_Management.pst.setString(3, drug_group);
                Pharmacy_Management.pst.setString(4, com_name);
                Pharmacy_Management.pst.setString(5, date);
                Pharmacy_Management.pst.setString(6, quantity);
                Pharmacy_Management.pst.setFloat(7, mrp);
                Pharmacy_Management.pst.setInt(8, dep_id);
                Pharmacy_Management.pst.executeUpdate();
                Pharmacy_Management.con.close();
                Pharmacy_Management.st.close();
                acknowledgement_Or_Warning(" Saved  ", 2000);
                clear_Form();
                
            } catch (Exception ex) {
                System.out.println("bbb> " + ex.getMessage());
            }

        }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_dep_listActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dep_listActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[4];
        String[] data = new String[4];
        arr = new ArrayList<String[]>();

        coloumn[0] = "ID";
        coloumn[1] = "Name";
        coloumn[2] = "Contact";
        coloumn[3] = "Location";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM depositors";

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("id");
                data[1] = rs.getString("name");
                data[2] = rs.getString("contact");
                data[3] = rs.getString("location");

                arr.add(data);
                dm.addRow(arr.get(0));

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            acknowledgement_Or_Warning("Horrror Found!", 2000);
        }
//
//        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMinWidth(88);
//        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMaxWidth(88);
//        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
//        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
//        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
//        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
//        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMinWidth(150);
//        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
//        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(145);
//        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(145);
//        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(80);
//        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(80);

        table_Title = "Depositors";
        lbl_tbl_title.setText(table_Title);


    }//GEN-LAST:event_btn_dep_listActionPerformed

    private void btn_new_depActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_depActionPerformed
        // TODO add your handling code here:
        Depositor_Form obj = new Depositor_Form();


    }//GEN-LAST:event_btn_new_depActionPerformed

    private void btn_All_DrugsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_All_DrugsActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[7];
        String[] data = new String[7];
        arr = new ArrayList<String[]>();

        coloumn[0] = "ID";
        coloumn[1] = "Drug Name";
        coloumn[2] = "Group name";
        coloumn[3] = "ComPany Namy";
        coloumn[4] = "Expire Date";
        coloumn[5] = "Available";
        coloumn[6] = "MRP";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, userName, password);
            st = con.createStatement();

            query = "SELECT * FROM drug_stock";

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("drug_id");
                data[1] = rs.getString("drug_name");
                data[2] = rs.getString("drug_group");
                data[3] = rs.getString("company_name");
                data[4] = rs.getString("exp_date");
                data[5] = rs.getString("quantity");
                data[6] = rs.getString("mrp");
                arr.add(data);
                dm.addRow(arr.get(0));

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            acknowledgement_Or_Warning("Horrror Found!", 2000);
        }

        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMinWidth(88);
        tbl_Result_Exhibition.getColumnModel().getColumn(3).setMaxWidth(88);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(50);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMinWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(1).setMaxWidth(150);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(145);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(145);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(80);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(80);

        table_Title = "All Drugs";
        lbl_tbl_title.setText(table_Title);


    }//GEN-LAST:event_btn_All_DrugsActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        // TODO add your handling code here:

        txt_com_name.setText("");
        txt_group_name.setText("");
        txt_drug_name.setText("");
        jspn_num_sheet.setValue(0);
        jspn_pcs_per_sheet.setValue(0);
        jspn_num_pcs.setValue(0);
        jspn_extra_pcs.setValue(0);
        date_Format = new SimpleDateFormat("dd-MM-yyyy");
        try {
            jspn_expr_date.setDate(date_Format.parse(new SimpleDateFormat("dd-MM-yyyy").format(new Date())));
        } catch (ParseException ex) {
            System.out.println("Parse Exception in clear_form   method!");
        }
        txt_mrp_per_sheet.setText("");
        chk_pcs.setSelected(false);
        chk_sheet.setSelected(false);
        jspn_num_pcs.setEnabled(false);
        jspn_extra_pcs.setEnabled(false);
        jspn_pcs_per_sheet.setEnabled(false);
        jspn_num_sheet.setEnabled(false);
        txt_dep_id.setText("");

    }//GEN-LAST:event_btn_clearActionPerformed

    private void create_acc_menu_itemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_acc_menu_itemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_acc_menu_itemActionPerformed

    private void btn_sale_recordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sale_recordsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_sale_recordsActionPerformed

    private void btn_record_saleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_record_saleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_record_saleActionPerformed

    private void btn_tbl_to_TostorageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tbl_to_TostorageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_tbl_to_TostorageActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        //     Pharmacy_Management pm = new Pharmacy_Management();
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (Exception ex) {
//            System.out.println("Pokath Hoyechilo abar holo 1");
//            sign = true;
//        }
        //</editor-fold>
        //</editor-fold>
        // UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        //  UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        /* Create and display the form */
        try {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    (home_obj = new Home_PM()).setVisible(true);

                }
            });
        } catch (Exception ex) {
            System.out.println("Pokath ,the exp sign  2 ");

        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem about_menu_item;
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator1;
    private com.toedter.calendar.demo.BirthdayEvaluator birthdayEvaluator2;
    private javax.swing.JButton btn_All_Drugs;
    private javax.swing.JButton btn_Modify_Sale;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_com_list;
    private javax.swing.JButton btn_com_list3;
    private javax.swing.JButton btn_dep_list;
    private javax.swing.JButton btn_exp_before_list;
    private javax.swing.JButton btn_modify;
    private javax.swing.JButton btn_new_dep;
    private javax.swing.JButton btn_record_event;
    private javax.swing.JButton btn_record_sale;
    private javax.swing.JButton btn_remove;
    private javax.swing.JButton btn_sale_records;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_tbl_to_Tostorage;
    private javax.swing.JCheckBox chk_pcs;
    private javax.swing.JCheckBox chk_sheet;
    private javax.swing.JComboBox<String> cmb_search_By;
    private javax.swing.JMenuItem create_acc_menu_item;
    private javax.swing.JMenuItem exit_menu_Item;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler3;
    private javax.swing.Box.Filler filler4;
    private javax.swing.Box.Filler filler5;
    private com.toedter.calendar.demo.JCalendarDemo jCalendarDemo1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private com.toedter.calendar.JSpinnerDateEditor jspn_exp_date_at_view;
    private com.toedter.calendar.JSpinnerDateEditor jspn_expr_date;
    private com.toedter.components.JSpinField jspn_extra_pcs;
    private com.toedter.components.JSpinField jspn_num_pcs;
    private com.toedter.components.JSpinField jspn_num_sheet;
    private com.toedter.components.JSpinField jspn_pcs_per_sheet;
    private javax.swing.JLabel lbl_mrp;
    private javax.swing.JLabel lbl_tbl_title;
    private javax.swing.JMenuItem login_menu_item;
    private javax.swing.JMenuItem setting_menu_item;
    private javax.swing.JTable tbl_Result_Exhibition;
    private javax.swing.JTextField txt_com_name;
    private javax.swing.JTextField txt_dep_id;
    private javax.swing.JTextField txt_drug_name;
    private javax.swing.JTextField txt_group_name;
    private javax.swing.JTextField txt_mrp_per_sheet;
    private javax.swing.JTextField txt_search_content;
    // End of variables declaration//GEN-END:variables
}
