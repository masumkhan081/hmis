/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy_management;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.DriverManager;
import java.text.ParseException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import static pharmacy_management.Home_PM.*;
import static pharmacy_management.Pharmacy_Management.*;

/**
 *
 * @author pddrgj3q
 */
public class Modify_Info extends javax.swing.JFrame implements ActionListener {

    int pX, pY;

    /**
     * Creates new form Modify_Info
     */
    public Modify_Info() {
        initComponents();
        setAlwaysOnTop(true);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(1);
        jspn_expr_date.setEditor(new JSpinner.DateEditor(jspn_expr_date, "dd-MM-yyyy"));
        btn_save.addActionListener(this);

        txt_com_name.setText(com_name);
        txt_drug_name.setText(drug_name);
        txt_group_name.setText(drug_group);
        jspn_expr_date.setEditor(new JSpinner.DateEditor(jspn_expr_date, "dd-MM-yyyy"));
        jspn_expr_date.setDate(exp_date);
        jSpin_num_sheet.setValue(num_sheet);
        jSpin_pcs_per_sheet.setValue(num_pcs);
        txt_mrp_per_sheet.setText(String.valueOf(mrp_per_sheet));
        btn_exit.addActionListener(this);
        System.out.println(quantity);
        if (quantity.contains("pcs")) {

            jSpin_num_sheet.setValue(Integer.parseInt(quantity.substring(0, quantity.length() - 4)));
        }
        if (quantity.contains("/")) {

            jSpin_num_sheet.setValue(Integer.parseInt(quantity.split("/")[0]));
            jSpin_pcs_per_sheet.setValue(Integer.parseInt(quantity.split("/")[1]));
        }
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();

            }

        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {

                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == btn_save) {

            save_Modified();
        }

        if (ae.getSource() == btn_exit) {
            dispose();
        }
    }

    public void save_Modified() {

        String updated_exp_date = "", Quantity = "", updated_mrp;
        int result = JOptionPane.showOptionDialog(this, "Sure With Your Modification ?", "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Yes", "No"}, JOptionPane.NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {

            drug_name = txt_drug_name.getText();
            drug_group = txt_group_name.getText();
            com_name = txt_com_name.getText();
            updated_exp_date = date_Format.format(exp_date = jspn_expr_date.getDate());
            if (jSpin_pcs_per_sheet.getValue() == 0) {
                Quantity = jSpin_num_sheet.getValue() + " pcs";
            }
            if (jSpin_pcs_per_sheet.getValue() != 0) {
                Quantity = jSpin_num_sheet.getValue() + "/" + jSpin_pcs_per_sheet.getValue();
            }
            updated_mrp = txt_mrp_per_sheet.getText();
            try {
                id = id;
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, userName, password);

                st = con.createStatement();
                query = "UPDATE drug_stock SET"
                        + " drug_id = ? ,"
                        + " drug_name =? ,"
                        + " drug_group = ? ,"
                        + " company_name = ? ,"
                        + " exp_date = ? ,"
                        + " quantity = ? ,"
                        + " mrp = ? "
                        + " WHERE drug_id = " + id + " ";
                pst = con.prepareStatement(query);
                pst.setInt(1, id);
                pst.setString(2, drug_name);
                pst.setString(3, drug_group);
                pst.setString(4, com_name);
                pst.setString(5, updated_exp_date);
                pst.setString(6, Quantity);
                pst.setFloat(7, Float.parseFloat(updated_mrp));

                pst.executeUpdate();
                dispose();
                home_obj.view_Drugs();
                //  rs = st.executeQuery(query);

            } catch (Exception ex) {
                System.out.println(ex.getMessage());

            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jspn_expr_date = new com.toedter.calendar.JSpinnerDateEditor();
        jSpin_pcs_per_sheet = new com.toedter.components.JSpinField();
        jSpin_num_sheet = new com.toedter.components.JSpinField();
        jPanel5 = new javax.swing.JPanel();
        btn_save = new javax.swing.JButton();
        txt_drug_name = new javax.swing.JTextField();
        txt_group_name = new javax.swing.JTextField();
        txt_com_name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_mrp_per_sheet = new javax.swing.JTextField();
        lbl_num_pcs = new javax.swing.JLabel();
        lbl_pcs_per_s = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(7, 25, 45));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        btn_exit.setBackground(new java.awt.Color(0, 0, 0));
        btn_exit.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(204, 51, 0));
        btn_exit.setText("X");
        btn_exit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel1.setBackground(new java.awt.Color(0, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 255, 153));
        jLabel1.setText(" Exp. Date :");

        jspn_expr_date.setBackground(new java.awt.Color(0, 0, 0));
        jspn_expr_date.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_expr_date.setForeground(new java.awt.Color(255, 204, 102));
        jspn_expr_date.setModel(new javax.swing.SpinnerDateModel());
        jspn_expr_date.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jSpin_pcs_per_sheet.setBackground(new java.awt.Color(11, 28, 46));
        jSpin_pcs_per_sheet.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jSpin_num_sheet.setBackground(new java.awt.Color(11, 28, 46));
        jSpin_num_sheet.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel5.setBackground(new java.awt.Color(2, 28, 28));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_save.setBackground(new java.awt.Color(11, 28, 46));
        btn_save.setFont(new java.awt.Font("Tunga", 1, 17)); // NOI18N
        btn_save.setForeground(new java.awt.Color(255, 153, 51));
        btn_save.setText("Save");
        btn_save.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        txt_drug_name.setBackground(new java.awt.Color(11, 28, 46));
        txt_drug_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_drug_name.setForeground(new java.awt.Color(204, 102, 0));
        txt_drug_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(0, 51, 51), new java.awt.Color(0, 51, 51)), "Drug Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_group_name.setBackground(new java.awt.Color(11, 28, 46));
        txt_group_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_group_name.setForeground(new java.awt.Color(204, 102, 0));
        txt_group_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(0, 51, 51), new java.awt.Color(0, 51, 51)), "Group Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_com_name.setBackground(new java.awt.Color(11, 28, 46));
        txt_com_name.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_com_name.setForeground(new java.awt.Color(204, 102, 0));
        txt_com_name.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 51, 51), new java.awt.Color(0, 51, 51)), "Company Name :", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        jLabel2.setBackground(new java.awt.Color(0, 41, 41));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 102, 0));
        jLabel2.setText("Quantity & Price :");

        txt_mrp_per_sheet.setBackground(new java.awt.Color(11, 28, 46));
        txt_mrp_per_sheet.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_mrp_per_sheet.setForeground(new java.awt.Color(204, 102, 0));
        txt_mrp_per_sheet.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "MRP / Sheet", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        lbl_num_pcs.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        lbl_num_pcs.setForeground(new java.awt.Color(255, 204, 102));
        lbl_num_pcs.setText("total pcs:");

        lbl_pcs_per_s.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        lbl_pcs_per_s.setForeground(new java.awt.Color(255, 204, 102));
        lbl_pcs_per_s.setText("pcs/sheet");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txt_com_name, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txt_group_name, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jspn_expr_date, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lbl_num_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSpin_num_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jSpin_pcs_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_mrp_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lbl_pcs_per_s, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_group_name, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(txt_com_name, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jspn_expr_date, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_num_pcs)
                    .addComponent(lbl_pcs_per_s))
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jSpin_num_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSpin_pcs_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txt_mrp_per_sheet, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Modify_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Modify_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Modify_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Modify_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Modify_Info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private com.toedter.components.JSpinField jSpin_num_sheet;
    private com.toedter.components.JSpinField jSpin_pcs_per_sheet;
    private com.toedter.calendar.JSpinnerDateEditor jspn_expr_date;
    private javax.swing.JLabel lbl_num_pcs;
    private javax.swing.JLabel lbl_pcs_per_s;
    private javax.swing.JTextField txt_com_name;
    private javax.swing.JTextField txt_drug_name;
    private javax.swing.JTextField txt_group_name;
    private javax.swing.JTextField txt_mrp_per_sheet;
    // End of variables declaration//GEN-END:variables
}
