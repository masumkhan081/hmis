package pharmacy_management;

import java.sql.*;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.*;
import java.awt.*;
import static pharmacy_management.Home_PM.*;

/**
 *
 * @author pddrgj3q
 */
public class Pharmacy_Management {

    /**
     * @param args the command line arguments
     */
    static String table_Title;
    static DatabaseMetaData md;
    static DateFormat dateFormat;
    static JOptionPane jOptionPane;
    static Connection con = null;
    static Statement st = null;
    static ResultSet rs;
    static String query;
    static PreparedStatement pst = null;
    static String driverName = "com.mysql.jdbc.Driver";
    static String url = "jdbc:mysql://localhost:3306/";
    static String dbName = "pharmacy";
    static String userName = "root";
    static String password = "";

    static boolean sign;
    static Home_PM obj;
    static String sold_drugs[][];
    static String drug_name, drug_group, com_name, quantity;
    static int drug_id;
    static java.util.Date exp_date;
    static DateFormat date_Format;
    static int num_sheet, num_pcs, id, bill;
    static float mrp_per_sheet;
    static Calendar cal;
    static int pX, pY;
    static ArrayList<String> Com_Names;
    static ArrayList<String[]> arr;
    static ArrayList<Integer> indexes;

    static boolean admin_status = false;

    public Pharmacy_Management() {

    }

    public static void main(String[] args) {
//
//        try {
//            con = DriverManager.getConnection(url + dbName, userName, password);
//            st = con.createStatement();
//
//            query = "CREATE TABLE drug_stock ("
//                    + "drug_id int NOT NULL ,"
//                    + "drug_name VARCHAR(50), "
//                    + "drug_group VARCHAR(30),"
//                    + "company_name VARCHAR(20),"
//                    + "exp_date VARCHAR(15),"
//                    + "quantity VARCHAR(15),"
//                    + "mrp FLOAT(7,2),"
//                    + "dep_id int(11),"
//                    + "PRIMARY KEY (drug_id))";
//            st = con.createStatement();
//            st.executeUpdate(query);
//
//        } catch (SQLException sqe) {
//            System.out.println(sqe);
//        }

        db_Connection();
//        try {
//            //   Home_PM  home_obj = new Home_PM();
//        } catch (Exception ex) {
//            System.out.println(ex);
//            System.out.println(ex.getMessage());
//            System.out.println(ex);
//
//        }
    }

    static void db_Connection() {

        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(url, userName, password);

            if (con == null) {
                System.out.println("###  Connection Came Out With Null");
            }
            rs = con.getMetaData().getCatalogs();
            sign = false;
            while (rs.next()) {
                if (dbName.equals(rs.getString(1))) {
                    sign = true;
                    System.out.println("the database " + dbName + " exists");
                    break;
                }
                //   I HAVE TO APART DB CONNECTION AND SAVING CODE IN DIFFERENT PLACE       *********************************************
                //   AND EVERY TIME IT CAN NOT BE CHECKED WHETHER TABLE EXIST OR NOT      *********************************************
                //   THERE SHOULD BE TABLE EXISTENCE SIGN     ***********************************************

            }
            if (sign == false) {

                query = "CREATE DATABASE " + dbName;
                st = con.createStatement();
                st.executeUpdate(query);
                System.out.println("newly created");
                st.close();

                con = DriverManager.getConnection(url + dbName, userName, password);

                query = "CREATE TABLE drug_stock ("
                        + "drug_id int NOT NULL AUTO_INCREMENT,"
                        + "drug_name VARCHAR(50), "
                        + "drug_group VARCHAR(30),"
                        + "company_name VARCHAR(20),"
                        + "exp_date VARCHAR(15),"
                        + "quantity VARCHAR(15),"
                        + "mrp FLOAT(7,2),"
                        + "dep_id int(11),"
                        + "PRIMARY KEY (drug_id))";
                st = con.createStatement();
                st.executeUpdate(query);
                query = "CREATE TABLE admins("
                        + "name VARCHAR(30),"
                        + "pass VARCHAR(10))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE Companies("
                        + "com_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(30),"
                        + "location VARCHAR(100) ,"
                        + "contact VARCHAR(55),"
                        + "details VARCHAR(155))";

                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE settings("
                        + "multiple_admin_status int(5))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE sale_Records("
                        + "sale_id int NOT NULL AUTO_INCREMENT,"
                        + "cus_name VARCHAR(15),"
                        + "drug_id int(11),"
                        + "quantity VARCHAR(15),"
                        + "date VARCHAR(15),"
                        + "bill int(11),"
                        + "PRIMARY KEY (sale_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE depositors("
                        + "dep_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(55),"
                        + "contact VARCHAR(55),"
                        + "location VARCHAR(55),"
                        + "com_name VARCHAR(55),"
                        + "PRIMARY KEY (id))";
              
                st.executeUpdate(query);

                query = "CREATE TABLE storage_add_record("
                        + "evt_id int NOT NULL AUTO_INCREMENT,"
                        + "dep_id int(11),"
                        + "amountt int(11),"
                        + "date VARCHAR(55),"
                        + "drugs VARCHAR(55)"
                        + "PRIMARY KEY (evt_id))";
                st = con.createStatement();
                st.executeUpdate(query);

            }
        } catch (Exception ex) {
            System.out.println(ex.getStackTrace()[1].getLineNumber() + "   ???????????");
            System.out.println(ex.getMessage());
        }
    }

}
