/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy_management;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import static pharmacy_management.Pharmacy_Management.*;
import static pharmacy_management.Home_PM.*;

/**
 *
 * @author pddrgj3q
 */
public class Sale extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form Sale
     */
    int drug_count;

    public Sale() {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        btn_exit.addActionListener(this);
        lbl_today.setText(new SimpleDateFormat("dd.MM.yyyy").format(new Date()));
        //   lbl_drug_com.setText("Company: " );
        //   lbl_drug_group.setText("Group: " + drug_group);
        //  lbl_drug_name.setText("Drug Name: ");

        btn_Done.addActionListener(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();

            }

        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {

                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });

        if (sign == false) {
            jspn_exp_date_at_view.setEnabled(false);
            drug_count = 0;
            lbl_sold_drug_count.setText("1/" + String.valueOf(sold_drugs.length));
            make_sequential_Appearence();

        }
    }

    public void actionPerformed(ActionEvent ae) {

        String bill = "", cus_name = "";
        boolean sign = false;
        int value = 0;

        String updated_Quantity = "";

        if (ae.getSource() == btn_Done) {
            sign = false;
            System.out.println("done btn pressed !");

            String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
            System.out.println(">> >> >> " + quantity);
            if ((bill = txt_bill.getText()).equals("")) {
                sign = true;
                warn("set purchase bill !", 1500);

            }
            if ((value = jspn_num_pcs.getValue()) == 0 && sign == false) {
                sign = true;
                warn("Set Quantity", 1000);
            }
            int av_pcs = -1;
            if (quantity.contains("pcs")) {
                av_pcs = Integer.parseInt(quantity.substring(0, quantity.length() - 4));

            }
            if (quantity.contains("/")) {
                av_pcs = Integer.parseInt(quantity.split("/")[0]);
            }
            System.out.println("AVAI ????      " + av_pcs);

            if (av_pcs < value && sign == false) {
                warn("Out Of Storage !", 1500);
                sign = true;
            }
            if (sign == false) {
                try {

                    Integer.parseInt(bill);
                } catch (NumberFormatException nfe) {
                    sign = true;
                    warn("Invalid Bill Amount!", 2000);
                }
            }
            if (sign == false) {
                try {

                    if(quantity.contains("pcs")){
                        updated_Quantity  = av_pcs-value+" pcs";
                    }
                    if(quantity.contains("/")){
                        updated_Quantity  = av_pcs-value+"/"+quantity.split("/")[1];
                    }
                    
                    System.out.println("updated Quantity :  " + updated_Quantity +" value: "+value+" q?? "+quantity);
                    Class.forName(driverName);
                    con = DriverManager.getConnection(url + dbName, userName, password);
                    st = con.createStatement();
                    pst = con.prepareStatement("insert into sale_records values(?,?,?,?,?,?)");
                    drug_id = Integer.parseInt(sold_drugs[drug_count][0]);
                    pst.setInt(1, 0);
                    pst.setString(2, cus_name);
                    pst.setInt(3, drug_id);
                    pst.setString(4, String.valueOf(value));
                    pst.setString(5, date);
                    pst.setInt(6, Integer.parseInt(bill));

                    pst.executeUpdate();
                    System.out.println("*****************************************************************************************");
                    jspn_num_pcs.setValue(0);
                    txt_bill.setText("");
                    
                    st = con.createStatement();
                    query = "UPDATE drug_stock SET"
                            + " quantity= ? "
                            + " WHERE drug_id = " + drug_id + " ";

                    pst = con.prepareStatement(query);
                    pst.setString(1, updated_Quantity);
                    pst.executeUpdate();
                    home_obj.view_Drugs();

                } catch (Exception e) {
                    System.out.println("exp at sale record portion");
                    System.out.println(e);
                }
                drug_count++;
                lbl_sold_drug_count.setText(String.valueOf(drug_count + 1) + "/" + String.valueOf(sold_drugs.length));

            }
            if (drug_count == sold_drugs.length) {
                System.out.println("now the end >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                home_obj.clear_table();
                dispose();
            }
            if (drug_count < sold_drugs.length) {
                make_sequential_Appearence();
            }
        }
        if (ae.getSource() == btn_exit) {
            warn("All Saved", 1000);
            dispose();
        }
    }

    public void warn(String msg, int time) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                txt_info_miss.setText("");

            }
        }).start();
        txt_info_miss.setText(msg);

    }

    public void make_sequential_Appearence() {

        System.out.println(sold_drugs.length);

        try {
            txt_drug_name.setText("Drug Name: " + sold_drugs[drug_count][1]);
            txt_drug_group.setText("Drug Group: " + sold_drugs[drug_count][2]);
            txt_drug_com.setText("Com Name: " + sold_drugs[drug_count][3]);
            quantity = sold_drugs[drug_count][4];
            if (quantity.contains("pcs")) {
                lbl_avai.setText("Available total: " + quantity);
            }
            if (quantity.contains("/")) {
                lbl_avai.setText("Available total: " + quantity.split("/")[0] + "pcs ." + " (with " + quantity.split("/")[1] + " pcs per sheet)");
            }

        } catch (ArrayIndexOutOfBoundsException aioobe) {
            System.out.println(drug_count);
            acknowledgement_Or_Warning("No More Was Listed", 3000);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lbl_today = new javax.swing.JLabel();
        btn_exit = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txt_customer_name = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        txt_bill = new javax.swing.JTextField();
        jspn_num_pcs = new com.toedter.components.JSpinField();
        jspn_exp_date_at_view = new com.toedter.calendar.JSpinnerDateEditor();
        lbl_sold_drug_count = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txt_info_miss = new javax.swing.JTextField();
        txt_drug_name = new javax.swing.JTextField();
        txt_drug_group = new javax.swing.JTextField();
        txt_drug_com = new javax.swing.JTextField();
        lbl_avai = new javax.swing.JLabel();
        btn_Done = new javax.swing.JButton();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(102, 51, 0));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(1, 16, 32));
        jPanel1.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createMatteBorder(3, 4, 1, 1, new java.awt.Color(1, 15, 29)), javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED)));
        jPanel1.setForeground(new java.awt.Color(255, 255, 153));

        lbl_today.setBackground(new java.awt.Color(0, 51, 51));
        lbl_today.setFont(new java.awt.Font("Yu Mincho Light", 1, 14)); // NOI18N
        lbl_today.setForeground(new java.awt.Color(204, 255, 153));

        btn_exit.setBackground(new java.awt.Color(0, 0, 0));
        btn_exit.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(204, 51, 0));
        btn_exit.setText("X");
        btn_exit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_exit.setRolloverEnabled(false);

        jPanel2.setBackground(new java.awt.Color(1, 16, 32));
        jPanel2.setForeground(new java.awt.Color(255, 255, 153));

        txt_customer_name.setBackground(new java.awt.Color(38, 56, 56));
        txt_customer_name.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        txt_customer_name.setForeground(new java.awt.Color(255, 204, 102));
        txt_customer_name.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Customer Name:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(216, 176, 119))); // NOI18N
        txt_customer_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_customer_nameActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(2, 15, 28));

        txt_bill.setBackground(new java.awt.Color(38, 56, 56));
        txt_bill.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 17)); // NOI18N
        txt_bill.setForeground(new java.awt.Color(255, 204, 102));
        txt_bill.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "total:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(220, 176, 88))); // NOI18N

        jspn_num_pcs.setBackground(new java.awt.Color(38, 56, 56));
        jspn_num_pcs.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(0, 51, 51), new java.awt.Color(0, 51, 51)), " PCS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(222, 177, 85))); // NOI18N
        jspn_num_pcs.setForeground(new java.awt.Color(255, 204, 102));
        jspn_num_pcs.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jspn_num_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_bill, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jspn_num_pcs, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_bill, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2))
        );

        jspn_exp_date_at_view.setBackground(new java.awt.Color(38, 56, 56));
        jspn_exp_date_at_view.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "date of sale", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), new java.awt.Color(255, 204, 102))); // NOI18N
        jspn_exp_date_at_view.setForeground(new java.awt.Color(255, 204, 102));
        jspn_exp_date_at_view.setModel(new javax.swing.SpinnerDateModel());
        jspn_exp_date_at_view.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jspn_exp_date_at_view, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txt_customer_name)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txt_customer_name, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jspn_exp_date_at_view, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        lbl_sold_drug_count.setBackground(new java.awt.Color(7, 0, 0));
        lbl_sold_drug_count.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_sold_drug_count.setForeground(new java.awt.Color(204, 255, 153));

        jPanel3.setBackground(new java.awt.Color(1, 16, 32));

        txt_info_miss.setBackground(new java.awt.Color(1, 16, 32));
        txt_info_miss.setFont(new java.awt.Font("Meiryo", 1, 13)); // NOI18N
        txt_info_miss.setForeground(new java.awt.Color(255, 204, 102));
        txt_info_miss.setBorder(null);

        txt_drug_name.setBackground(new java.awt.Color(38, 56, 56));
        txt_drug_name.setFont(new java.awt.Font("Meiryo", 1, 13)); // NOI18N
        txt_drug_name.setForeground(new java.awt.Color(255, 204, 102));
        txt_drug_name.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txt_drug_group.setBackground(new java.awt.Color(38, 56, 56));
        txt_drug_group.setFont(new java.awt.Font("Meiryo", 1, 13)); // NOI18N
        txt_drug_group.setForeground(new java.awt.Color(255, 204, 102));
        txt_drug_group.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txt_drug_group.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_drug_groupActionPerformed(evt);
            }
        });

        txt_drug_com.setBackground(new java.awt.Color(38, 56, 56));
        txt_drug_com.setFont(new java.awt.Font("Meiryo", 1, 13)); // NOI18N
        txt_drug_com.setForeground(new java.awt.Color(255, 204, 102));
        txt_drug_com.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lbl_avai.setBackground(new java.awt.Color(38, 56, 56));
        lbl_avai.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_avai.setForeground(new java.awt.Color(255, 204, 102));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txt_drug_name)
                    .addComponent(txt_drug_group)
                    .addComponent(lbl_avai, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(txt_info_miss, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txt_drug_com, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(txt_info_miss, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_drug_name, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_drug_group, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_drug_com, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_avai, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        btn_Done.setBackground(new java.awt.Color(38, 56, 56));
        btn_Done.setFont(new java.awt.Font("Showcard Gothic", 1, 14)); // NOI18N
        btn_Done.setForeground(new java.awt.Color(255, 204, 102));
        btn_Done.setText("Done");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_today, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lbl_sold_drug_count, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)))
                        .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(btn_Done)))
                .addGap(0, 0, 0))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_today, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 33, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lbl_sold_drug_count, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_Done, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_customer_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_customer_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_customer_nameActionPerformed

    private void txt_drug_groupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_drug_groupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_drug_groupActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //   UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        // UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sale().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Done;
    private javax.swing.JButton btn_exit;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private com.toedter.calendar.JSpinnerDateEditor jspn_exp_date_at_view;
    private com.toedter.components.JSpinField jspn_num_pcs;
    private javax.swing.JLabel lbl_avai;
    private javax.swing.JLabel lbl_sold_drug_count;
    private javax.swing.JLabel lbl_today;
    private javax.swing.JTextField txt_bill;
    private javax.swing.JTextField txt_customer_name;
    private javax.swing.JTextField txt_drug_com;
    private javax.swing.JTextField txt_drug_group;
    private javax.swing.JTextField txt_drug_name;
    private javax.swing.JTextField txt_info_miss;
    // End of variables declaration//GEN-END:variables

}
