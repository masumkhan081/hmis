package pharmacy_management;

import java.io.*;
import java.util.ArrayList;

public class test {

    public static void main(String[] argv) throws Exception {

        ArrayList<String> arr = new ArrayList();
        System.out.println(arr.size());

//    String[] buttons = { "LogIn", "Cancel" };
//
//    int rc = JOptionPane.showOptionDialog(null, "Admin Account Already Exist !", "Confirmation",
//        JOptionPane.WARNING_MESSAGE, 0, null, buttons, buttons[0]);
//
//    System.out.println(rc);
        String line;
        String pidInfo = "";

        Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\" + "tasklist.exe");

        BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

        while ((line = input.readLine()) != null) {
            pidInfo += line;
        }

        input.close();

        if (!pidInfo.contains("xampp-control.exe")) {
           Runtime runtime = Runtime.getRuntime();
           runtime.exec("D:\\Xampp\\xampp-control.exe");
            System.out.println("Executed !!");
        }

    }
}
