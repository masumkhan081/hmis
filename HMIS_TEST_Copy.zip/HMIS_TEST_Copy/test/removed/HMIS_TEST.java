/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package removed;

import Pathology.TestTaking;
import spoiled.Doc_Form;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author pddrgj3q
 */
public class HMIS_TEST {

    
 
   
    static DatabaseMetaData md;
    static DateFormat dateFormat;
  
    static Doctor_Module doc_module;
    static TestTaking test_taking;
    static Account account;
   
    static New_Patient new_pat;
  
  

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("0  .");

        db_Connection();
        //  get_dept_Names();
        //       DC_Module obj = new DC_Module();

    }

    static void db_Connection() {

        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(url, db_userName, db_password);

            if (con == null) {
                System.out.println("###  Connection Came Out With Null");
            }
            rs = con.getMetaData().getCatalogs();
            sign = false;
            while (rs.next()) {
                if (dbName.equals(rs.getString(1))) {
                    sign = true;
                    System.out.println("the database " + dbName + " exists");
                    break;
                }
                //   I HAVE TO APART DB CONNECTION AND SAVING CODE IN DIFFERENT PLACE       *********************************************
                //   AND EVERY TIME IT CAN NOT BE CHECKED WHETHER TABLE EXIST OR NOT      *********************************************
                //   THERE SHOULD BE TABLE EXISTENCE SIGN     ***********************************************

            }
            if (sign == false) {

                query = "CREATE DATABASE " + dbName;
                st = con.createStatement();
                st.executeUpdate(query);
                System.out.println("newly created");
                st.close();

                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();
                query = "CREATE TABLE accounts ("
                        + "email VARCHAR(100) NOT NULL ,"
                        + "pass VARCHAR(55), "
                        + "status VARCHAR(65) ,"
                        + "type VARCHAR(45),"
                        + "PRIMARY KEY (email))";

                st.executeUpdate(query);

                query = "CREATE DATABASE  pokath";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE appointments ("
                        + "event_id int NOT NULL ,"
                        + "doc_id int NULL, "
                        + "prescription BLOB ,"
                        + "bill int,"
                        + "PRIMARY KEY (event_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE app_to_be ("
                        + "event_id int NOT NULL AUTO_INCREMENT,"
                        + "serial int ,"
                        + "pat_id int NULL, "
                        + "doc_id int NULL, "
                        + "date VARCHAR(15),"
                        + "bill int ,"
                        + "PRIMARY KEY (event_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE events ("
                        + "event_id int NOT NULL AUTO_INCREMENT,"
                        + "pat_id int NULL, "
                        + "type VARCHAR(15),"
                        + "date VARCHAR(15),"
                        + "PRIMARY KEY (event_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE in_pat_cases ("
                        + "event_id int NOT NULL ,"
                        + "ward_cabin VARCHAR(15),"
                        + "prescription BLOB ,"
                        + "services VARCHAR(15),"
                        + "tests VARCHAR(15),"
                        + "PRIMARY KEY (event_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE doctors ("
                        + "doc_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50) NULL, "
                        + "email VARCHAR(30) NULL,"
                        + "contact VARCHAR(20) NULL,"
                        + "nid VARCHAR(20) NULL,"
                        + "per_add VARCHAR(45) NULL,"
                        + "cur_add VARCHAR(45) NULL,"
                        + "dept VARCHAR(55) ,"
                        + "desg VARCHAR(15),"
                        + "dob VARCHAR(15) NULL,"
                        + "doj VARCHAR(15) NULL,"
                        + "type VARCHAR(15) NULL,"
                        + "image MEDIUMBLOB NULL,"
                        + "chamber_no VARCHAR(15) NULL,"
                        + "doc_schedule VARCHAR(350) NULL,"
                        + "PRIMARY KEY (doc_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE Services ("
                        + "service_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(80), "
                        + "type VARCHAR(45) NULL,"
                        + "description VARCHAR(200), "
                        + "bill VARCHAR(50), "
                        + "PRIMARY KEY (service_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE Nurses ("
                        + "nurse_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50), "
                        + "email VARCHAR(30),"
                        + "contact VARCHAR(20),"
                        + "per_add VARCHAR(15),"
                        + "cur_add VARCHAR(15),"
                        + "nid VARCHAR(20),"
                        + "gender VARCHAR(15),"
                        + "dob VARCHAR(15),"
                        + "doj VARCHAR(15),"
                        + "image MEDIUMBLOB,"
                        + "PRIMARY KEY (nurse_id))";

                st.executeUpdate(query);

                query = "CREATE TABLE system_executives ("
                        + "member_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50), "
                        + "email VARCHAR(30),"
                        + "nid VARCHAR(20),"
                        + "age VARCHAR(15),"
                        + "per_add VARCHAR(15),"
                        + "cur_add VARCHAR(15),"
                        + "contact VARCHAR(20),"
                        + "desg VARCHAR(15),"
                        + "image MEDIUMBLOB,"
                        + "PRIMARY KEY (member_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE beds ("
                        + "bed_id int NOT NULL AUTO_INCREMENT,"
                        + "floor INT(11),"
                        + "room_num VARCHAR(30),"
                        + "type VARCHAR(30),"
                        + "receptivity INT(10),"
                        + "description VARCHAR(250),"
                        + "status VARCHAR(100) NULL,"
                        + "charge VARCHAR(30),"
                        + "PRIMARY KEY (bed_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE departments ("
                        + "dept_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(55),"
                        + "initiation VARCHAR(15) NULL,"
                        + "PRIMARY KEY (dept_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE med_tests ("
                        + "id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(15),"
                        + "type VARCHAR(15),"
                        + "num INT(12),"
                        + "structure VARCHAR(220),"
                        + "bill INT(12),"
                        + "PRIMARY KEY (id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE patients ("
                        + "pat_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(50) , "
                        + "email VARCHAR(30) NULL,"
                        + "contact VARCHAR(20) ,"
                        + "nid VARCHAR(20) NULL,"
                        + "address VARCHAR(45) NULL,"
                        + "family VARCHAR(55) ,"
                        + "gender VARCHAR(15),"
                        + "PRIMARY KEY (pat_id))";
                st = con.createStatement();
                st.executeUpdate(query);

                query = "CREATE TABLE last_patient ("
                        + "doc_id int NOT NULL ,"
                        + "time VARCHAR(65),"
                        + "PRIMARY KEY (doc_id))";
                st = con.createStatement();
                st.executeUpdate(query);
                //     set_Sample_Data();

                query = "CREATE TABLE med_test_patient ("
                        + "register_id int NOT NULL AUTO_INCREMENT,"
                        + "name VARCHAR(350),"
                        + "address VARCHAR(70),"
                        + "contact VARCHAR(45),"
                        + "email VARCHAR(40),"
                        + "gender VARCHAR(40),"
                        + "dob VARCHAR(40),"
                        + "PRIMARY KEY (register_id))";
                st.executeUpdate(query);

            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage() + "  \n" + ex.getStackTrace()[1]);
        }
    }

    static void acknowledgement_Or_Warning(String warning_Msg, int time) {
        jOptionPane = new JOptionPane(warning_Msg, JOptionPane.INFORMATION_MESSAGE);
        final JDialog dialog = jOptionPane.createDialog("pokath!");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                dialog.setVisible(false);

            }
        }).start();
        dialog.setVisible(true);
    }

    static void set_Sample_Data() {
        String str = "Doctor";
        String str2 = "DOC-";
        for (int i = 0; i < 5; i++) {

            if (i == 3) {
                str = "Receptionist";
                str2 = "REC-";
            }
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + dbName, db_userName, db_password);
                st = con.createStatement();

                pst = con.prepareStatement("insert into accounts values(?,?,?,?)");

                pst.setString(1, "email" + i);
                pst.setString(2, str2 + i + "-");
                pst.setString(3, "Never Logged In");
                pst.setString(4, str);
                pst.executeUpdate();
                pst = con.prepareStatement("insert into doctors values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

                pst.setInt(1, 0);
                pst.setString(2, "name" + i);
                pst.setString(3, "email" + i);
                pst.setString(4, "contact" + i);
                pst.setString(5, "nid" + i);
                pst.setString(6, "per_add" + i);
                pst.setString(7, "cur_add" + i);
                pst.setString(8, "dept" + i);
                pst.setString(9, "desg" + i);
                pst.setString(10, "dob" + i);
                pst.setString(11, "doj " + i);
                pst.setString(12, "type" + i);
                if (fin == null) {
                    pst.setBinaryStream(13, is);
                }
                if (fin != null) {
                    pst.setBinaryStream(13, (InputStream) fin, (int) imgFile.length());
                }
                pst.setString(14, "");
                pst.setString(15, "");

                pst.executeUpdate();

                pst = con.prepareStatement("insert into system_executives values(?,?,?,?,?,?,?,?,?,?)");
                pst.setInt(1, 0);
                pst.setString(2, "name" + i);
                pst.setString(3, "email" + i);
                pst.setString(4, "nid" + i);
                pst.setString(5, "age" + i);
                pst.setString(6, "add1" + i);
                pst.setString(7, "add2" + i);
                pst.setString(8, "contact" + i);
                pst.setString(9, "desg" + i);
                pst.setBinaryStream(10, is);
                pst.executeUpdate();
                pst = con.prepareStatement("insert into beds values(?,?,?,?,?,?,?,?)");

                pst.setInt(1, 0);
                pst.setInt(2, i);
                pst.setString(3, "lab-" + i);
                pst.setString(4, "type" + i);
                pst.setInt(5, i + 1);
                pst.setString(6, "description" + 1);
                pst.setInt(7, 0);
                pst.setString(8, "charge");

                pst.executeUpdate();

                pst = HMIS_TEST.con.prepareStatement("insert into departments values(?,?,?)");

                pst.setInt(1, 0);
                pst.setString(2, "dept_name" + i);
                pst.setString(3, "dept_intiation" + i);

                pst.executeUpdate();

            } catch (Exception ex) {
                query = "DELETE hmis";
                try {
                    pst.executeUpdate();
                } catch (Exception ex2) {
                    System.out.println("ex 2 ");
                }
                System.out.println("in set_sample_data " + ex);
            }

        }

    }
}
