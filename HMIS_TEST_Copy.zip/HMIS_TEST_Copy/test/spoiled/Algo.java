/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spoiled;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author pddrgj3q
 */
public class Algo {

    public static void main(String args[]) {

        int xy[][] = new int[4][4];
        ArrayList<Integer> x = new ArrayList();
        ArrayList<Integer> y = new ArrayList();
        Scanner scn = new Scanner(System.in);
        
        System.out.println(new Date());
        
//        int rad = scn.nextInt();
//        x.add(0);
//        y.add(rad);
//        int pk = 1 - rad;
//        while (y.get(y.size() - 1) > x.get(y.size() - 1)) {
//            if (pk >= 0) {
//
//                y.add(y.get(y.size() - 1) - 1);
//                x.add(x.get(x.size() - 1) + 1);
//
//            } else {
//
//                y.add(y.get(y.size() - 1));
//                x.add(x.get(x.size() - 1) + 1);
//
//            }
//            System.out.println("x: " + x.get(x.size() - 1) + "   y: " + y.get(y.size() - 1));
//
//            pk = pk + 2 * x.get(x.size() - 1) + (y.get(y.size() - 1) * y.get(y.size() - 1) - y.get(y.size() - 2) * y.get(y.size() - 2)) - (y.get(y.size() - 1) - y.get(y.size() - 2)) + 1;
//            System.out.println(pk);
//        }

    }

}
