/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spoiled;

import removed.HMIS_TEST;
import static removed.HMIS_TEST.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.DriverManager;
import java.util.ArrayList;

/**
 *
 * @author Masum Khan
 */
public class Demo_Insertion {

    static ArrayList<String[]> my_arr;
    static String str[];
    static int new_id;

    public static void main(String[] args) {

        //  insert_dept();
        insert_docs();
    }

    static void insert_dept() {
        my_arr = new ArrayList<>();
        str = new String[4];

        try {

            new_id = 1;
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = HMIS_TEST.con.createStatement();
            query = "SELECT dept_id  FROM departments ORDER BY dept_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);
            while (rs.next()) {
                new_id = rs.getInt(1) + 1;
            }

            str[0] = String.valueOf(new_id);
            str[1] = String.valueOf("Neurology");
            str[2] = String.valueOf("Pokath ! why on this earth need a description !");
            str[3] = "12/10/21";
            my_arr.add(str);

            new_id++;
            str = new String[5];
            str[0] = String.valueOf(new_id);
            str[1] = String.valueOf("Medicine");
            str[2] = String.valueOf("Neurology ! why on this earth need a description !");
            str[3] = "12/10/21";
            my_arr.add(str);

            new_id++;
            str = new String[5];
            str[0] = String.valueOf(new_id);
            str[1] = String.valueOf("Whateverology");
            str[2] = String.valueOf("Whateverology ! why on this earth need a description !");
            str[3] = "12/10/21";
            my_arr.add(str);

            pst = HMIS_TEST.con.prepareStatement("insert into departments values(?,?,?,?)");
            System.out.println();

            for (int i = 0; i < my_arr.size(); i++) {
                pst.setInt(1, Integer.parseInt(my_arr.get(i)[0]));
                pst.setString(2, my_arr.get(i)[1]);
                pst.setString(3, my_arr.get(i)[2]);
                pst.setString(4, my_arr.get(i)[3]);
                pst.executeUpdate();
            }
            con.close();
            st.close();
            System.out.println("Sample depts insertd");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    static void insert_docs() {

        my_arr = new ArrayList<>();
        str = new String[14];
        String img_path = "D:\\CSE_150103020010\\HMIS\\HMIS_TEST_Copy\\src\\ICON\\doc.jpg";

        imgFile = new File(img_path);

        try {
            fin = new FileInputStream(imgFile);
        } catch (Exception fnfe) {
            System.out.println("exp > setImage  method() <<");
        }
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = HMIS_TEST.con.createStatement();
            new_id = 1;

            query = "SELECT doc_id  FROM doctors ORDER BY doc_id  DESC LIMIT 1;";
            rs = st.executeQuery(query);

            while (rs.next()) {
                new_id = rs.getInt(1) + 1;
            }

            str[0] = String.valueOf(new_id);
            str[1] = "Mr. abdul Hakim";

            str[2] = "abdulhakim081@gmail.com";
            str[3] = "01880-573029";
            str[4] = "1234502870";
            str[5] = "road-4 , meoa village , upozilla, district  ";
            str[6] = "uposahor road 4 block 2";
            str[7] = "Neurology";
            str[8] = "general surgeon";
            str[9] = "12/10/1975";
            str[10] = "12/10/18";
            str[11] = "Out-Door doc";
            str[12] = "210";
            str[13] = "!sat12:37 to 17:37 & 12:37 to 19:37!tue16:37 to 18:37!wed05:37 to 09:37 & 05:37 to 12:37";
            my_arr.add(0, str);
            System.out.println(str[0] + "   new id: " + new_id + "    " + my_arr.get(0)[1]);
            new_id++;
            str = new String[14];
            str[0] = String.valueOf(new_id);
            str[1] = "Mr. Jphn doe";
            str[2] = "john_doe@gmail.com";
            str[3] = "+888-30978055";
            str[4] = "1234501111";
            str[5] = "road-4 , meoa village , upozilla, district Sylhet ";
            str[6] = "Shahporan road 4 block 2";
            str[7] = "Medicine";
            str[8] = "general surgeon";
            str[9] = "12/10/1975";
            str[10] = "12/10/18";
            str[11] = "In-Door doc";
            str[12] = "210";
            str[13] = "!sun12:37 to 17:37 & 12:37 to 19:37!mon16:37 to 18:37!thu05:37 to 09:37 & 05:37 to 12:37";
            my_arr.add(1, str);
            System.out.println(str[0] + "   new id: " + new_id + "    " + my_arr.get(1)[1]);
            new_id++;
            str = new String[14];
            str[0] = String.valueOf(new_id);
            str[1] = "Mr. Son of biscuit";
            str[2] = "son_ofbiscuit@gmail.com";
            str[3] = "+888-0387501";
            str[4] = "3806581";
            str[5] = "dirty , ass village , upozilla name, district name ";
            str[6] = "Shahporan road 4 block 2";
            str[7] = "Medicine";
            str[8] = "general surgeon";
            str[9] = "12/10/1975";
            str[10] = "12/10/18";
            str[11] = "Out-Door doc";
            str[12] = "515";
            str[13] = "!mon12:37 to 17:37 & 12:37 to 19:37";
            my_arr.add(2, str);
            System.out.println(str[0] + "   new id: " + new_id + "    " + my_arr.get(2)[1]);

            new_id++;
            str = new String[14];
            str[0] = String.valueOf(new_id);
            str[1] = "Dr. Masud Sheikh";
            str[2] = "john_doe@gmail.com";
            str[3] = "+888-30978055";
            str[4] = "1234501111";
            str[5] = "road-4 , meoa village , upozilla, district Sylhet ";
            str[6] = "Shahporan road 4 block 2";
            str[7] = "Medicine";
            str[8] = "general surgeon";
            str[9] = "12/10/1975";
            str[10] = "12/10/18";
            str[11] = "In-Door doc";
            str[12] = "210";
            str[13] = "!sun12:37 to 17:37 & 12:37 to 19:37!mon16:37 to 18:37!thu05:37 to 09:37 & 05:37 to 12:37";
            my_arr.add(3, str);
            new_id++;
            str = new String[14];
            str[0] = String.valueOf(new_id);
            str[1] = "Mr. Kaplan ";
            str[2] = "john_doe@gmail.com";
            str[3] = "+888-30978055";
            str[4] = "1234501111";
            str[5] = "road-4 , meoa village , upozilla, district Sylhet ";
            str[6] = "Shahporan road 4 block 2";
            str[7] = "Whateverology";
            str[8] = "general surgeon";
            str[9] = "12/10/1975";
            str[10] = "12/10/18";
            str[11] = "Out-Door doc";
            str[12] = "210";
            str[13] = "!sun12:37 to 17:37 & 12:37 to 19:37!mon16:37 to 18:37!thu05:37 to 09:37 & 05:37 to 12:37";
            my_arr.add(4, str);

            st = HMIS_TEST.con.createStatement();

            System.out.println("running ! " + my_arr.size());

            for (int i = 0; i < my_arr.size(); i++) {
                System.out.println(i + " > " + my_arr.get(i)[1]);
            }

            for (int i = 0; i < my_arr.size(); i++) {

                pass = "DOC-" + Integer.parseInt(my_arr.get(i)[0]) + "-" + 11111;
                pst = con.prepareStatement("insert into accounts values(?,?,?,?,?,?)");

                pst.setString(1, my_arr.get(i)[2]);
                pst.setString(2, "x");
                pst.setString(3, pass);
                pst.setString(4, "Never Logged In");
                pst.setString(5, "");
                pst.setString(6, "Doctor");
                pst.executeUpdate();

                pst = HMIS_TEST.con.prepareStatement("insert into doctors values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                System.out.println("dup:  " + i + ">>>>>" + Integer.parseInt(my_arr.get(i)[0]));
                pst.setInt(1, Integer.parseInt(my_arr.get(i)[0]));
                pst.setString(2, my_arr.get(i)[1]);
                pst.setString(3, my_arr.get(i)[2]);
                pst.setString(4, my_arr.get(i)[3]);
                pst.setString(5, my_arr.get(i)[4]);
                pst.setString(6, my_arr.get(i)[5]);
                pst.setString(7, my_arr.get(i)[6]);
                pst.setString(8, my_arr.get(i)[7]);
                pst.setString(9, my_arr.get(i)[8]);
                pst.setString(10, my_arr.get(i)[9]);
                pst.setString(11, my_arr.get(i)[10]);
                pst.setString(12, my_arr.get(i)[11]);
                pst.setBinaryStream(13, (InputStream) fin, (int) imgFile.length());
                pst.setString(14, my_arr.get(i)[12]);
                pst.setString(15, my_arr.get(i)[13]);

                pst.executeUpdate();
            }
            con.close();
            st.close();
            System.out.println("Sample depts insertd");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
