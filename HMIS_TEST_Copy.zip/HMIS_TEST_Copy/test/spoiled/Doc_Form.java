/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spoiled;

import removed.Admin;
import Admin.FileChooser;
import removed.Suggestion_List;
import static removed.HMIS_TEST.*;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.*;
import java.io.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.*;

/**
 *
 * @author pddrgj3q
 */
public class Doc_Form extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form Doc_Form
     */
    static int pX, pY, dick;
    static String name, email, nid, contact, per_add, cur_add, age, dept, desg, chamber, dob, doj, start, end, schedule, type;
    static Date date;
    static SpinnerDateModel sm;
    static JSpinner.DateEditor de;
    ArrayList list;
    boolean module_right = false;

    public Doc_Form(int dick) {

        initComponents();

        btn_Clear_per.addActionListener(this);

        btn_Save_per.addActionListener(this);

        btn_image.addActionListener(this);

        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        txt_Dept.setEditable(false);
        date_Format = new SimpleDateFormat();
        System.out.println(date_Format.format(new Date()));
//        for (int i = 0; i < 7; i++) {
//            Container con = (Container) jpnl_7_days.getComponent(i);
//            for (int j = 2; j < 8; j++) {
//                con.getComponent(j).setEnabled(false);
//            }
//        }
        get_dept_Names();
        if (dick == 1 || dick == 2) {
            System.out.println("got dick value" + dick);
            this.dick = dick;
            set_Profile();
        }

    }

    public void set_Profile() {

        arr = new ArrayList<String[]>();
        String gen;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbName, db_userName, db_password);
            st = con.createStatement();

            query = "SELECT * FROM doctors WHERE doc_id = '" + doc_ID + "'";

            rs = st.executeQuery(query);
            while (rs.next()) {

                txt_C_Add.setText(rs.getString("cur_add"));
                txt_P_Add.setText(rs.getString("per_add"));
                txt_contact.setText(rs.getString("contact"));
                txt_Email.setText(rs.getString("email"));
                txt_NID.setText(rs.getString("nid"));
                txt_FullName.setText(rs.getString("name"));
                date_Format = new SimpleDateFormat("dd/MM/yyyy");
                gen = rs.getString("dob");
                date = date_Format.parse(gen);
                date_birth.setDate(date);
                gen = rs.getString("doj");
                date = date_Format.parse(gen);
                date_join.setDate(date);
                schedule = rs.getString("doc_schedule");
                for (int i = 0; i < schedule.split("!").length; i++) {

                    if (schedule.split("!")[i].startsWith("sat")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("sun")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("mon")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("tue")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("wed")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("thu")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                    if (schedule.split("!")[i].startsWith("fri")) {
                        System.out.println(schedule.split("!")[i]);
                    }
                }

//                InputStream is = rs.getBinaryStream("photo");
//// Decode the inputstream as BufferedImage
//                BufferedImage bufImg = null;              //      ONGOING 
//                bufImg = ImageIO.read(is);
//                Image image = bufImg;
//                ImageIcon icon = new ImageIcon(bufImg);
//                lbl_pic.setIcon(icon);
//                Blob aBlob = rs.getBlob("image");
//                System.out.println("not reached         22  ");
//                InputStream is = aBlob.getBinaryStream(0, aBlob.length());
//                BufferedImage imag = ImageIO.read(is);
//                Image image = imag;
//                ImageIcon icon = new ImageIcon(image);
//                lbl_pic.setIcon(icon);
//                System.out.println("not reached 33   ");
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }
        if (dick == 1) {
            System.out.println("got it !");
            chk_editable.setSelected(false);
            make_editable(false);
        }
        if (dick == 2) {
            chk_editable.setSelected(true);
            make_editable(true);
        }

    }

    public void set_dept_Name(String dept_name) {

        dept = dept_name;
        doc.txt_Dept.setText(dept);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == jspn_sat_1) {
            txt_sat.setText(jspn_sat_1.getValue().toString());
        }

        if (ae.getSource() == btn_Clear_per) {

        }

    }

    public void set_Image(String path) {
        imgFile = new File(path);

        try {
            fin = new FileInputStream(imgFile);
        } catch (Exception fnfe) {
            System.out.println("exp > setImage  method() <<");
        }
        ImageIcon Myimage = new ImageIcon(path);
        Image img = Myimage.getImage();
        Image newImage = img.getScaledInstance(lbl_pic.getWidth(), lbl_pic.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        lbl_pic.setIcon(image);

    }

    public void get_Schedule() {
        schedule = "";
        String str;
        if (chk_sat.isSelected() || chk_sun.isSelected() || chk_mon.isSelected() || chk_tue.isSelected() || chk_wed.isSelected() || chk_thu.isSelected() || chk_fri.isSelected()) {
            str = txt_sat.getText();

            if (chk_sat.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!sat" + str;
            }
            str = txt_sun.getText();
            if (chk_sun.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!sun" + str;
            }
            str = txt_mon.getText();
            if (chk_mon.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!mon" + str;
            }
            str = txt_tue.getText();
            if (chk_tue.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!tue" + str;
            }
            str = txt_wed.getText();
            if (chk_wed.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!wed" + str;
            }
            str = txt_thu.getText();
            if (chk_thu.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!thu" + str;
            }
            str = txt_fri.getText();
            if (chk_fri.isSelected() && str.length() != 0) {
                if (str.endsWith("& ")) {
                    str = str.substring(0, str.length() - 2);
                }
                schedule += "!fri" + str;
            }

        }
        System.out.println(schedule);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTimeChooserDemo1 = new lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_FullName = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_P_Add = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txt_C_Add = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_NID = new javax.swing.JTextField();
        txt_Dept = new javax.swing.JTextField();
        list_dept = new javax.swing.JButton();
        list_desg = new javax.swing.JButton();
        txt_desg = new javax.swing.JTextField();
        cmb_doc_type = new javax.swing.JComboBox<>();
        btn_image = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        date_birth = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        date_join = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        txt_contact = new javax.swing.JTextField();
        txt_chamber = new javax.swing.JTextField();
        jpnl_schedule = new javax.swing.JPanel();
        jpnl_7_days = new javax.swing.JPanel();
        jPanel_sat = new javax.swing.JPanel();
        txt_sat = new javax.swing.JTextField();
        btn_add_sat2 = new javax.swing.JButton();
        chk_sat = new javax.swing.JCheckBox();
        jspn_sat_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jspn_sat_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel17 = new javax.swing.JLabel();
        btn_clear_sat = new javax.swing.JButton();
        btn_sat_ok2 = new javax.swing.JButton();
        jPanel_sun = new javax.swing.JPanel();
        txt_sun = new javax.swing.JTextField();
        btn_add_sun = new javax.swing.JButton();
        chk_sun = new javax.swing.JCheckBox();
        jspn_sun_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel8 = new javax.swing.JLabel();
        jspn_sun_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_sun = new javax.swing.JButton();
        btn_sun_ok = new javax.swing.JButton();
        jPanel_mon = new javax.swing.JPanel();
        txt_mon = new javax.swing.JTextField();
        btn_add_mon = new javax.swing.JButton();
        chk_mon = new javax.swing.JCheckBox();
        jspn_mon_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel10 = new javax.swing.JLabel();
        jspn_mon_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_mon = new javax.swing.JButton();
        btn_mon_ok = new javax.swing.JButton();
        jPanel_tue = new javax.swing.JPanel();
        txt_tue = new javax.swing.JTextField();
        btn_add_tue = new javax.swing.JButton();
        chk_tue = new javax.swing.JCheckBox();
        jspn_tue_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel11 = new javax.swing.JLabel();
        jspn_tue_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_tue = new javax.swing.JButton();
        btn_tue_ok = new javax.swing.JButton();
        jPanel_wed = new javax.swing.JPanel();
        txt_wed = new javax.swing.JTextField();
        btn_add_wed = new javax.swing.JButton();
        chk_wed = new javax.swing.JCheckBox();
        jspn_wed_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel12 = new javax.swing.JLabel();
        jspn_wed_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_wed = new javax.swing.JButton();
        btn_wed_ok = new javax.swing.JButton();
        jPanel_thu = new javax.swing.JPanel();
        txt_thu = new javax.swing.JTextField();
        btn_add_thu = new javax.swing.JButton();
        chk_thu = new javax.swing.JCheckBox();
        jspn_thu_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel13 = new javax.swing.JLabel();
        jspn_thu_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_thu = new javax.swing.JButton();
        btn_thu_ok = new javax.swing.JButton();
        jPanel_fri = new javax.swing.JPanel();
        txt_fri = new javax.swing.JTextField();
        btn_add_fri = new javax.swing.JButton();
        chk_fri = new javax.swing.JCheckBox();
        jspn_fri_1 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        jLabel15 = new javax.swing.JLabel();
        jspn_fri_2 = new javax.swing.JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR_OF_DAY));
        btn_clear_fri = new javax.swing.JButton();
        btn_fri_ok = new javax.swing.JButton();
        lbl_sch_title = new javax.swing.JLabel();
        lbl_invalid_sch = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        txt_doc_id = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btn_get_doc = new javax.swing.JButton();
        chk_editable = new javax.swing.JCheckBox();
        chk_schedule = new javax.swing.JCheckBox();
        lbl_pic = new javax.swing.JLabel();
        btn_Save_per = new javax.swing.JButton();
        btn_Clear_per = new javax.swing.JButton();
        lbl_msg = new javax.swing.JLabel();
        chk_module_right = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Doctor Info", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(153, 51, 0))); // NOI18N
        jPanel1.setMaximumSize(new java.awt.Dimension(1301, 646));
        jPanel1.setMinimumSize(new java.awt.Dimension(1301, 640));
        jPanel1.setPreferredSize(new java.awt.Dimension(1301, 646));

        jLabel2.setBackground(new java.awt.Color(204, 255, 204));
        jLabel2.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel2.setText("Full Name:");
        jLabel2.setToolTipText("");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        txt_FullName.setBackground(new java.awt.Color(0, 10, 10));
        txt_FullName.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_FullName.setForeground(new java.awt.Color(204, 255, 153));
        txt_FullName.setToolTipText("");
        txt_FullName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_FullName.setMaximumSize(new java.awt.Dimension(2147483647, 28));
        txt_FullName.setMinimumSize(new java.awt.Dimension(0, 28));
        txt_FullName.setPreferredSize(new java.awt.Dimension(0, 28));
        txt_FullName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_FullNameActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(204, 255, 204));
        jLabel5.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel5.setText("Email:");
        jLabel5.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        txt_Email.setBackground(new java.awt.Color(0, 10, 10));
        txt_Email.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_Email.setForeground(new java.awt.Color(204, 255, 153));
        txt_Email.setToolTipText("");
        txt_Email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_Email.setMaximumSize(new java.awt.Dimension(284, 28));
        txt_Email.setMinimumSize(new java.awt.Dimension(284, 28));
        txt_Email.setPreferredSize(new java.awt.Dimension(284, 28));
        txt_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_EmailActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(204, 255, 204));
        jLabel3.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel3.setText("Address: (Parmanent)");

        txt_P_Add.setBackground(new java.awt.Color(0, 10, 10));
        txt_P_Add.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_P_Add.setForeground(new java.awt.Color(204, 255, 153));
        txt_P_Add.setToolTipText("");
        txt_P_Add.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_P_Add.setMaximumSize(new java.awt.Dimension(2147483647, 28));
        txt_P_Add.setMinimumSize(new java.awt.Dimension(0, 28));
        txt_P_Add.setPreferredSize(new java.awt.Dimension(0, 28));

        jLabel14.setBackground(new java.awt.Color(204, 255, 204));
        jLabel14.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel14.setText("Address:(Current) ");

        txt_C_Add.setBackground(new java.awt.Color(0, 10, 10));
        txt_C_Add.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_C_Add.setForeground(new java.awt.Color(204, 255, 153));
        txt_C_Add.setToolTipText("");
        txt_C_Add.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_C_Add.setMaximumSize(new java.awt.Dimension(2147483647, 28));
        txt_C_Add.setMinimumSize(new java.awt.Dimension(0, 28));
        txt_C_Add.setPreferredSize(new java.awt.Dimension(0, 28));

        jLabel9.setBackground(new java.awt.Color(204, 255, 204));
        jLabel9.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel9.setText("NID:");
        jLabel9.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        txt_NID.setBackground(new java.awt.Color(0, 10, 10));
        txt_NID.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_NID.setForeground(new java.awt.Color(204, 255, 153));
        txt_NID.setToolTipText("");
        txt_NID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_NID.setMaximumSize(new java.awt.Dimension(284, 28));
        txt_NID.setMinimumSize(new java.awt.Dimension(284, 28));
        txt_NID.setPreferredSize(new java.awt.Dimension(284, 28));
        txt_NID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_NIDActionPerformed(evt);
            }
        });

        txt_Dept.setBackground(new java.awt.Color(0, 10, 10));
        txt_Dept.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_Dept.setForeground(new java.awt.Color(204, 255, 153));
        txt_Dept.setToolTipText("");
        txt_Dept.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txt_Dept.setMaximumSize(new java.awt.Dimension(284, 28));
        txt_Dept.setMinimumSize(new java.awt.Dimension(284, 28));
        txt_Dept.setPreferredSize(new java.awt.Dimension(284, 28));
        txt_Dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DeptActionPerformed(evt);
            }
        });

        list_dept.setFont(new java.awt.Font("Algerian", 0, 11)); // NOI18N
        list_dept.setText("list");
        list_dept.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        list_dept.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        list_dept.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        list_dept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list_deptActionPerformed(evt);
            }
        });

        list_desg.setFont(new java.awt.Font("Algerian", 0, 11)); // NOI18N
        list_desg.setText("list");
        list_desg.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        list_desg.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        list_desg.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        list_desg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list_desgActionPerformed(evt);
            }
        });

        txt_desg.setBackground(new java.awt.Color(0, 10, 10));
        txt_desg.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_desg.setForeground(new java.awt.Color(204, 255, 153));
        txt_desg.setToolTipText("");
        txt_desg.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txt_desg.setMaximumSize(new java.awt.Dimension(284, 28));
        txt_desg.setMinimumSize(new java.awt.Dimension(284, 28));
        txt_desg.setPreferredSize(new java.awt.Dimension(284, 28));
        txt_desg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_desgActionPerformed(evt);
            }
        });

        cmb_doc_type.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cmb_doc_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "In-Door Doc", "Out-door doc" }));
        cmb_doc_type.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        cmb_doc_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_doc_typeActionPerformed(evt);
            }
        });

        btn_image.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_image.setText("Doctor Image");
        btn_image.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        btn_image.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_imageActionPerformed(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(204, 255, 204));
        jLabel16.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel16.setText("Department");

        jLabel18.setBackground(new java.awt.Color(204, 255, 204));
        jLabel18.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 14)); // NOI18N
        jLabel18.setText("Designation");

        date_birth.setBackground(new java.awt.Color(0, 12, 12));
        date_birth.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        date_birth.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        date_birth.setMaximumSize(new java.awt.Dimension(146, 30));
        date_birth.setMinimumSize(new java.awt.Dimension(146, 30));
        date_birth.setPreferredSize(new java.awt.Dimension(146, 30));

        jLabel4.setText("Birth Date");

        date_join.setBackground(new java.awt.Color(0, 12, 12));
        date_join.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        date_join.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        date_join.setMaximumSize(new java.awt.Dimension(150, 30));
        date_join.setMinimumSize(new java.awt.Dimension(150, 30));
        date_join.setPreferredSize(new java.awt.Dimension(150, 30));

        jLabel6.setText("Joining Date");

        txt_contact.setBackground(new java.awt.Color(0, 10, 10));
        txt_contact.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_contact.setForeground(new java.awt.Color(204, 255, 153));
        txt_contact.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 51, 51)), "Contact:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        txt_chamber.setBackground(new java.awt.Color(0, 10, 10));
        txt_chamber.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_chamber.setForeground(new java.awt.Color(204, 255, 153));
        txt_chamber.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_chamber.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(0, 0, 0)), "Chamber room", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(204, 255, 153))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_FullName, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_C_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_doc_type, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_P_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txt_Dept, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(list_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_NID, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btn_image, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(txt_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(list_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date_birth, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date_join, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txt_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_chamber, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_FullName, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_NID, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_P_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_C_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_Dept, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(list_dept, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(list_desg, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmb_doc_type, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_image, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(date_birth, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date_join, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_chamber, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jpnl_schedule.setMaximumSize(new java.awt.Dimension(632, 475));
        jpnl_schedule.setMinimumSize(new java.awt.Dimension(632, 475));
        jpnl_schedule.setPreferredSize(new java.awt.Dimension(632, 475));

        jpnl_7_days.setMaximumSize(new java.awt.Dimension(596, 370));
        jpnl_7_days.setMinimumSize(new java.awt.Dimension(596, 370));

        jPanel_sat.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_sat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_sat.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_sat.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_sat.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_sat.setEditable(false);
        txt_sat.setBackground(new java.awt.Color(0, 10, 10));
        txt_sat.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_sat.setForeground(new java.awt.Color(204, 255, 153));
        txt_sat.setBorder(null);
        txt_sat.setHighlighter(null);
        txt_sat.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_sat.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_sat.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_sat2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_sat2.setText("+");
        btn_add_sat2.setActionCommand("&");
        btn_add_sat2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_sat2.setEnabled(false);
        btn_add_sat2.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_sat2.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_sat2.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_sat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_satActionPerformed(evt);
            }
        });

        chk_sat.setBackground(new java.awt.Color(204, 255, 204));
        chk_sat.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_sat.setText("Saturday");
        chk_sat.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_sat.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_sat.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_sat.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_sat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_satActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_sat_1, "HH:mm");
        jspn_sat_1.setEditor(de);
        jspn_sat_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_sat_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_sat_1.setEnabled(false);
        jspn_sat_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_sat_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_sat_1.setPreferredSize(new java.awt.Dimension(94, 35));

        de = new JSpinner.DateEditor(jspn_sat_2, "HH:mm");
        jspn_sat_2.setEditor(de);
        jspn_sat_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_sat_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_sat_2.setEnabled(false);
        jspn_sat_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_sat_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_sat_2.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 204, 102));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel17.setText("To");
        jLabel17.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel17.setMinimumSize(new java.awt.Dimension(16, 35));

        btn_clear_sat.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_sat.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_sat.setText("X");
        btn_clear_sat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_sat.setEnabled(false);
        btn_clear_sat.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_sat.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_sat.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_sat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_satActionPerformed(evt);
            }
        });

        btn_sat_ok2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_sat_ok2.setForeground(new java.awt.Color(0, 102, 51));
        btn_sat_ok2.setText("Ok");
        btn_sat_ok2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_sat_ok2.setEnabled(false);
        btn_sat_ok2.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_sat_ok2.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_sat_ok2.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_sat_ok2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sat_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_satLayout = new javax.swing.GroupLayout(jPanel_sat);
        jPanel_sat.setLayout(jPanel_satLayout);
        jPanel_satLayout.setHorizontalGroup(
            jPanel_satLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_satLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_sat_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_sat_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_sat_ok2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_sat2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_satLayout.setVerticalGroup(
            jPanel_satLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_satLayout.createSequentialGroup()
                .addGroup(jPanel_satLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jspn_sat_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel_satLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_satLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jspn_sat_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_add_sat2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_clear_sat, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_sat_ok2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_sun.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_sun.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_sun.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_sun.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_sun.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_sun.setEditable(false);
        txt_sun.setBackground(new java.awt.Color(0, 10, 10));
        txt_sun.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_sun.setForeground(new java.awt.Color(204, 255, 153));
        txt_sun.setBorder(null);
        txt_sun.setHighlighter(null);
        txt_sun.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_sun.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_sun.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_sun.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_sun.setText("+");
        btn_add_sun.setActionCommand("&");
        btn_add_sun.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_sun.setEnabled(false);
        btn_add_sun.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_sun.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_sun.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_sun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_sunActionPerformed(evt);
            }
        });

        chk_sun.setBackground(new java.awt.Color(204, 255, 204));
        chk_sun.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_sun.setText("Sunday");
        chk_sun.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_sun.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_sun.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_sun.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_sun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_sunActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_sun_1, "HH:mm");
        jspn_sun_1.setEditor(de);
        jspn_sun_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_sun_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_sun_1.setEnabled(false);
        jspn_sun_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_sun_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_sun_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 204, 102));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setText("To");
        jLabel8.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel8.setMinimumSize(new java.awt.Dimension(16, 35));

        de = new JSpinner.DateEditor(jspn_sun_2, "HH:mm");
        jspn_sun_2.setEditor(de);
        jspn_sun_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_sun_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_sun_2.setEnabled(false);
        jspn_sun_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_sun_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_sun_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_sun.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_sun.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_sun.setText("X");
        btn_clear_sun.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_sun.setEnabled(false);
        btn_clear_sun.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_sun.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_sun.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_sun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_sunActionPerformed(evt);
            }
        });

        btn_sun_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_sun_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_sun_ok.setText("Ok");
        btn_sun_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_sun_ok.setEnabled(false);
        btn_sun_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_sun_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_sun_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_sun_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sun_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_sunLayout = new javax.swing.GroupLayout(jPanel_sun);
        jPanel_sun.setLayout(jPanel_sunLayout);
        jPanel_sunLayout.setHorizontalGroup(
            jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_sunLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_sun_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_sun_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_sun_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_sunLayout.setVerticalGroup(
            jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_sunLayout.createSequentialGroup()
                .addGroup(jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_sunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_sun_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_sun, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_sun_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_sun_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_mon.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_mon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_mon.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_mon.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_mon.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_mon.setEditable(false);
        txt_mon.setBackground(new java.awt.Color(0, 10, 10));
        txt_mon.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_mon.setForeground(new java.awt.Color(204, 255, 153));
        txt_mon.setBorder(null);
        txt_mon.setHighlighter(null);
        txt_mon.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_mon.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_mon.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_mon.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_mon.setText("+");
        btn_add_mon.setActionCommand("&");
        btn_add_mon.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_mon.setEnabled(false);
        btn_add_mon.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_mon.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_mon.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_mon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_monActionPerformed(evt);
            }
        });

        chk_mon.setBackground(new java.awt.Color(204, 255, 204));
        chk_mon.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_mon.setText("Monday");
        chk_mon.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_mon.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_mon.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_mon.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_mon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_monActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_mon_1, "HH:mm");
        jspn_mon_1.setEditor(de);
        jspn_mon_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_mon_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_mon_1.setEnabled(false);
        jspn_mon_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_mon_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_mon_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 204, 102));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("To");
        jLabel10.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel10.setMinimumSize(new java.awt.Dimension(16, 35));

        jspn_mon_2.setEditor(new JSpinner.DateEditor(jspn_mon_2, "HH:mm"));
        jspn_mon_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_mon_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_mon_2.setEnabled(false);
        jspn_mon_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_mon_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_mon_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_mon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_mon.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_mon.setText("X");
        btn_clear_mon.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_mon.setEnabled(false);
        btn_clear_mon.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_mon.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_mon.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_mon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_monActionPerformed(evt);
            }
        });

        btn_mon_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_mon_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_mon_ok.setText("Ok");
        btn_mon_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_mon_ok.setEnabled(false);
        btn_mon_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_mon_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_mon_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_mon_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mon_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_monLayout = new javax.swing.GroupLayout(jPanel_mon);
        jPanel_mon.setLayout(jPanel_monLayout);
        jPanel_monLayout.setHorizontalGroup(
            jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_monLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_mon_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_mon_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_mon_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_monLayout.setVerticalGroup(
            jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_monLayout.createSequentialGroup()
                .addGroup(jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_monLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_mon_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_mon, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_mon_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_mon_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_tue.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_tue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_tue.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_tue.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_tue.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_tue.setEditable(false);
        txt_tue.setBackground(new java.awt.Color(0, 10, 10));
        txt_tue.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_tue.setForeground(new java.awt.Color(204, 255, 153));
        txt_tue.setBorder(null);
        txt_tue.setHighlighter(null);
        txt_tue.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_tue.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_tue.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_tue.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_tue.setText("+");
        btn_add_tue.setActionCommand("&");
        btn_add_tue.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_tue.setEnabled(false);
        btn_add_tue.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_tue.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_tue.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_tue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_tueActionPerformed(evt);
            }
        });

        chk_tue.setBackground(new java.awt.Color(204, 255, 204));
        chk_tue.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_tue.setText("Tuesday");
        chk_tue.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_tue.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_tue.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_tue.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_tue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_tueActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_tue_1, "HH:mm");
        jspn_tue_1.setEditor(de);
        jspn_tue_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_tue_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_tue_1.setEnabled(false);
        jspn_tue_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_tue_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_tue_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 204, 102));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel11.setText("To");
        jLabel11.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel11.setMinimumSize(new java.awt.Dimension(16, 35));

        de = new JSpinner.DateEditor(jspn_tue_2, "HH:mm");
        jspn_tue_2.setEditor(de);
        jspn_tue_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_tue_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_tue_2.setEnabled(false);
        jspn_tue_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_tue_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_tue_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_tue.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_tue.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_tue.setText("X");
        btn_clear_tue.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_tue.setEnabled(false);
        btn_clear_tue.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_tue.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_tue.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_tue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_tueActionPerformed(evt);
            }
        });

        btn_tue_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_tue_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_tue_ok.setText("Ok");
        btn_tue_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_tue_ok.setEnabled(false);
        btn_tue_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_tue_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_tue_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_tue_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tue_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_tueLayout = new javax.swing.GroupLayout(jPanel_tue);
        jPanel_tue.setLayout(jPanel_tueLayout);
        jPanel_tueLayout.setHorizontalGroup(
            jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_tueLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_tue_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_tue_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_tue_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_tueLayout.setVerticalGroup(
            jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_tueLayout.createSequentialGroup()
                .addGroup(jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_tueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_tue_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_tue, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_tue_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_tue_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_wed.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_wed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_wed.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_wed.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_wed.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_wed.setEditable(false);
        txt_wed.setBackground(new java.awt.Color(0, 10, 10));
        txt_wed.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_wed.setForeground(new java.awt.Color(204, 255, 153));
        txt_wed.setBorder(null);
        txt_wed.setHighlighter(null);
        txt_wed.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_wed.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_wed.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_wed.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_wed.setText("+");
        btn_add_wed.setActionCommand("&");
        btn_add_wed.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_wed.setEnabled(false);
        btn_add_wed.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_wed.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_wed.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_wed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_wedActionPerformed(evt);
            }
        });

        chk_wed.setBackground(new java.awt.Color(204, 255, 204));
        chk_wed.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_wed.setText("Wednesday");
        chk_wed.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_wed.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_wed.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_wed.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_wed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_wedActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_wed_1, "HH:mm");
        jspn_wed_1.setEditor(de);
        jspn_wed_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_wed_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_wed_1.setEnabled(false);
        jspn_wed_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_wed_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_wed_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 204, 102));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel12.setText("To");
        jLabel12.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel12.setMinimumSize(new java.awt.Dimension(16, 35));

        JSpinner.DateEditor de = new JSpinner.DateEditor(jspn_wed_2, "HH:mm");
        jspn_wed_2.setEditor(de);
        jspn_wed_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_wed_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_wed_2.setEnabled(false);
        jspn_wed_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_wed_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_wed_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_wed.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_wed.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_wed.setText("X");
        btn_clear_wed.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_wed.setEnabled(false);
        btn_clear_wed.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_wed.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_wed.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_wed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_wedActionPerformed(evt);
            }
        });

        btn_wed_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_wed_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_wed_ok.setText("Ok");
        btn_wed_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_wed_ok.setEnabled(false);
        btn_wed_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_wed_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_wed_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_wed_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_wed_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_wedLayout = new javax.swing.GroupLayout(jPanel_wed);
        jPanel_wed.setLayout(jPanel_wedLayout);
        jPanel_wedLayout.setHorizontalGroup(
            jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_wedLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_wed_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_wed_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_wed_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_wedLayout.setVerticalGroup(
            jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_wedLayout.createSequentialGroup()
                .addGroup(jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_wedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_wed_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_wed, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_wed_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_wed_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_thu.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_thu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_thu.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_thu.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_thu.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_thu.setEditable(false);
        txt_thu.setBackground(new java.awt.Color(0, 10, 10));
        txt_thu.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_thu.setForeground(new java.awt.Color(204, 255, 153));
        txt_thu.setBorder(null);
        txt_thu.setHighlighter(null);
        txt_thu.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_thu.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_thu.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_thu.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_thu.setText("+");
        btn_add_thu.setActionCommand("&");
        btn_add_thu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_thu.setEnabled(false);
        btn_add_thu.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_thu.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_thu.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_thu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_thuActionPerformed(evt);
            }
        });

        chk_thu.setBackground(new java.awt.Color(204, 255, 204));
        chk_thu.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_thu.setText("Thursday");
        chk_thu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_thu.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_thu.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_thu.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_thu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_thuActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_thu_1, "HH:mm");
        jspn_thu_1.setEditor(de);
        jspn_thu_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_thu_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_thu_1.setEnabled(false);
        jspn_thu_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_thu_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_thu_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 204, 102));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("To");
        jLabel13.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel13.setMinimumSize(new java.awt.Dimension(16, 35));

        de = new JSpinner.DateEditor(jspn_thu_2, "HH:mm");
        jspn_thu_2.setEditor(de);
        jspn_thu_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_thu_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_thu_2.setEnabled(false);
        jspn_thu_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_thu_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_thu_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_thu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_thu.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_thu.setText("X");
        btn_clear_thu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_thu.setEnabled(false);
        btn_clear_thu.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_thu.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_thu.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_thu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_thuActionPerformed(evt);
            }
        });

        btn_thu_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_thu_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_thu_ok.setText("Ok");
        btn_thu_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_thu_ok.setEnabled(false);
        btn_thu_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_thu_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_thu_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_thu_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thu_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_thuLayout = new javax.swing.GroupLayout(jPanel_thu);
        jPanel_thu.setLayout(jPanel_thuLayout);
        jPanel_thuLayout.setHorizontalGroup(
            jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_thuLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(chk_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_thu_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_thu_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_thu_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_thuLayout.setVerticalGroup(
            jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_thuLayout.createSequentialGroup()
                .addGroup(jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_thuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_thu_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_thu, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_thu_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_thu_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel_fri.setBackground(new java.awt.Color(0, 12, 12));
        jPanel_fri.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel_fri.setMaximumSize(new java.awt.Dimension(633, 37));
        jPanel_fri.setMinimumSize(new java.awt.Dimension(633, 37));
        jPanel_fri.setPreferredSize(new java.awt.Dimension(633, 37));

        txt_fri.setEditable(false);
        txt_fri.setBackground(new java.awt.Color(0, 10, 10));
        txt_fri.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        txt_fri.setForeground(new java.awt.Color(204, 255, 153));
        txt_fri.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 153, 153)));
        txt_fri.setHighlighter(null);
        txt_fri.setMaximumSize(new java.awt.Dimension(250, 35));
        txt_fri.setMinimumSize(new java.awt.Dimension(250, 35));
        txt_fri.setPreferredSize(new java.awt.Dimension(250, 35));

        btn_add_fri.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 14)); // NOI18N
        btn_add_fri.setText("+");
        btn_add_fri.setActionCommand("&");
        btn_add_fri.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_add_fri.setEnabled(false);
        btn_add_fri.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_add_fri.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_add_fri.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_add_fri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_friActionPerformed(evt);
            }
        });

        chk_fri.setBackground(new java.awt.Color(204, 255, 204));
        chk_fri.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chk_fri.setText("Friday");
        chk_fri.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        chk_fri.setMaximumSize(new java.awt.Dimension(100, 22));
        chk_fri.setMinimumSize(new java.awt.Dimension(100, 22));
        chk_fri.setPreferredSize(new java.awt.Dimension(100, 22));
        chk_fri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_friActionPerformed(evt);
            }
        });

        de = new JSpinner.DateEditor(jspn_fri_1, "HH:mm");
        jspn_fri_1.setEditor(de);
        jspn_fri_1.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_fri_1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_fri_1.setEnabled(false);
        jspn_fri_1.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_fri_1.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_fri_1.setPreferredSize(new java.awt.Dimension(94, 35));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 204, 102));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("To");
        jLabel15.setMaximumSize(new java.awt.Dimension(16, 35));
        jLabel15.setMinimumSize(new java.awt.Dimension(16, 35));

        de = new JSpinner.DateEditor(jspn_fri_2, "HH:mm");
        jspn_fri_2.setEditor(de);
        jspn_fri_2.setFont(new java.awt.Font("Meiryo", 1, 12)); // NOI18N
        jspn_fri_2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jspn_fri_2.setEnabled(false);
        jspn_fri_2.setMaximumSize(new java.awt.Dimension(94, 35));
        jspn_fri_2.setMinimumSize(new java.awt.Dimension(94, 35));
        jspn_fri_2.setPreferredSize(new java.awt.Dimension(94, 35));

        btn_clear_fri.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_clear_fri.setForeground(new java.awt.Color(204, 102, 0));
        btn_clear_fri.setText("X");
        btn_clear_fri.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_clear_fri.setEnabled(false);
        btn_clear_fri.setMaximumSize(new java.awt.Dimension(24, 36));
        btn_clear_fri.setMinimumSize(new java.awt.Dimension(24, 36));
        btn_clear_fri.setPreferredSize(new java.awt.Dimension(24, 36));
        btn_clear_fri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_friActionPerformed(evt);
            }
        });

        btn_fri_ok.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_fri_ok.setForeground(new java.awt.Color(0, 102, 51));
        btn_fri_ok.setText("Ok");
        btn_fri_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_fri_ok.setEnabled(false);
        btn_fri_ok.setMaximumSize(new java.awt.Dimension(28, 35));
        btn_fri_ok.setMinimumSize(new java.awt.Dimension(28, 35));
        btn_fri_ok.setPreferredSize(new java.awt.Dimension(28, 35));
        btn_fri_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_fri_okActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_friLayout = new javax.swing.GroupLayout(jPanel_fri);
        jPanel_fri.setLayout(jPanel_friLayout);
        jPanel_friLayout.setHorizontalGroup(
            jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_friLayout.createSequentialGroup()
                .addComponent(chk_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_fri_1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jspn_fri_2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_fri_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_clear_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_add_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel_friLayout.setVerticalGroup(
            jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_friLayout.createSequentialGroup()
                .addGroup(jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jspn_fri_2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_add_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_fri_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jspn_fri_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_friLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chk_fri, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jpnl_7_daysLayout = new javax.swing.GroupLayout(jpnl_7_days);
        jpnl_7_days.setLayout(jpnl_7_daysLayout);
        jpnl_7_daysLayout.setHorizontalGroup(
            jpnl_7_daysLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_7_daysLayout.createSequentialGroup()
                .addGroup(jpnl_7_daysLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel_fri, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_thu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_sun, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_tue, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_mon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_wed, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel_sat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );
        jpnl_7_daysLayout.setVerticalGroup(
            jpnl_7_daysLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_7_daysLayout.createSequentialGroup()
                .addComponent(jPanel_sat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel_sun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel_mon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel_tue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel_wed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel_thu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jPanel_fri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        lbl_sch_title.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        lbl_sch_title.setText("  Day                                                                                                            Start                 To       End                 done   clear   add");

        lbl_invalid_sch.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lbl_invalid_sch.setForeground(new java.awt.Color(204, 51, 0));

        javax.swing.GroupLayout jpnl_scheduleLayout = new javax.swing.GroupLayout(jpnl_schedule);
        jpnl_schedule.setLayout(jpnl_scheduleLayout);
        jpnl_scheduleLayout.setHorizontalGroup(
            jpnl_scheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_scheduleLayout.createSequentialGroup()
                .addGroup(jpnl_scheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_scheduleLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(lbl_invalid_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnl_scheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jpnl_7_days, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lbl_sch_title, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnl_scheduleLayout.setVerticalGroup(
            jpnl_scheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_scheduleLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lbl_invalid_sch, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbl_sch_title, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jpnl_7_days, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txt_doc_id.setBackground(new java.awt.Color(0, 12, 12));
        txt_doc_id.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 13)); // NOI18N
        txt_doc_id.setForeground(new java.awt.Color(204, 255, 153));
        txt_doc_id.setBorder(null);

        jLabel1.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 13)); // NOI18N
        jLabel1.setText("Doctor ID:");

        btn_get_doc.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 13)); // NOI18N
        btn_get_doc.setText("Retrieve  Doc");
        btn_get_doc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_get_doc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_get_docActionPerformed(evt);
            }
        });

        chk_editable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_editable.setText("Editable");
        chk_editable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_editableActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_doc_id, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_get_doc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chk_editable, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_doc_id, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_get_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chk_editable))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        chk_schedule.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_schedule.setText("Input Schedule");
        chk_schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_scheduleActionPerformed(evt);
            }
        });

        lbl_pic.setForeground(new java.awt.Color(153, 51, 0));
        lbl_pic.setText(".................................................................");
        lbl_pic.setMaximumSize(new java.awt.Dimension(195, 146));
        lbl_pic.setMinimumSize(new java.awt.Dimension(195, 146));
        lbl_pic.setPreferredSize(new java.awt.Dimension(195, 146));

        btn_Save_per.setBackground(new java.awt.Color(0, 0, 0));
        btn_Save_per.setFont(new java.awt.Font("Microsoft JhengHei", 1, 14)); // NOI18N
        btn_Save_per.setForeground(new java.awt.Color(204, 204, 255));
        btn_Save_per.setText("Save without schedule");
        btn_Save_per.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Save_per.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Save_per.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Save_perActionPerformed(evt);
            }
        });

        btn_Clear_per.setBackground(new java.awt.Color(0, 0, 0));
        btn_Clear_per.setFont(new java.awt.Font("Microsoft JhengHei", 1, 14)); // NOI18N
        btn_Clear_per.setForeground(new java.awt.Color(204, 204, 255));
        btn_Clear_per.setText("<<-- CLEAR");
        btn_Clear_per.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Clear_per.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Clear_perActionPerformed(evt);
            }
        });

        lbl_msg.setFont(new java.awt.Font("Source Code Pro Black", 1, 12)); // NOI18N
        lbl_msg.setForeground(new java.awt.Color(204, 51, 0));

        chk_module_right.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_module_right.setText("Doctor Module Right");
        chk_module_right.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_module_rightActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(90, 90, 90)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(chk_schedule, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(chk_module_right))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_Clear_per)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_msg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_Save_per)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(12, 12, 12)
                        .addComponent(lbl_pic, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jpnl_schedule, javax.swing.GroupLayout.PREFERRED_SIZE, 658, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_Save_per, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Clear_per, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(1, 1, 1)
                        .addComponent(lbl_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chk_schedule, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chk_module_right, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lbl_pic, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnl_schedule, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 644, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_FullNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_FullNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_FullNameActionPerformed

    private void txt_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_EmailActionPerformed

    private void txt_NIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_NIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_NIDActionPerformed

    private void txt_DeptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DeptActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DeptActionPerformed

    private void txt_desgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_desgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_desgActionPerformed

    private void list_desgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list_desgActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_list_desgActionPerformed

    private void cmb_doc_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_doc_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_doc_typeActionPerformed

    private void btn_imageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_imageActionPerformed
        FileChooser obj = new FileChooser(1);


    }//GEN-LAST:event_btn_imageActionPerformed

    private void btn_Clear_perActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Clear_perActionPerformed
        // TODO add your handling code here:
        txt_C_Add.setText("");
        txt_Dept.setText("");
        txt_Email.setText("");
        txt_FullName.setText("");
        txt_NID.setText("");
        txt_P_Add.setText("");
        txt_chamber.setText("");
        txt_contact.setText("");
        txt_desg.setText("");
        fin = null;
        FileChooser.path = null;
        imgFile = null;
    }//GEN-LAST:event_btn_Clear_perActionPerformed

    private void chk_scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_scheduleActionPerformed
        // TODO add your handling code here:
        if (chk_schedule.isSelected()) {
//            jpnl_schedule.setVisible(true);
//            jpnl_7_days.setVisible(true);
//            lbl_sch_title.setVisible(true);
            btn_Save_per.setText("Save with schedule");
        }
        if (!chk_schedule.isSelected()) {
            btn_Save_per.setText("Save without schedule");
//            lbl_sch_title.setVisible(false);

            txt_sat.setText("");
            chk_sat.setSelected(false);
            txt_sun.setText("");
            chk_sun.setSelected(false);
            txt_mon.setText("");
            chk_mon.setSelected(false);
            txt_tue.setText("");
            chk_tue.setSelected(false);
            txt_wed.setText("");
            chk_wed.setSelected(false);
            txt_thu.setText("");
            chk_thu.setSelected(false);
            txt_fri.setText("");
            chk_fri.setSelected(false);
//            jpnl_7_days.setVisible(false);
            for (int i = 0; i < 7; i++) {

                Container con = (Container) jpnl_7_days.getComponent(i);
                for (int j = 2; j < 8; j++) {
                    con.getComponent(j).setEnabled(false);
                }
            }
        }
        //    jpnl_schedule.removeAll();
//        jpnl_schedule.setVisible(false);
//        jpnl_schedule.add(jpnl_7_days);
//        jpnl_schedule.setVisible(true);
    }//GEN-LAST:event_chk_scheduleActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //  System.out.println(jTimeChooser1.getHours()+"  "+jTimeChooser1.getMinutes());

    }//GEN-LAST:event_jButton1ActionPerformed

    private void list_deptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list_deptActionPerformed
        // TODO add your handling code here:
        Suggestion_List suggestion = new Suggestion_List(0);


    }//GEN-LAST:event_list_deptActionPerformed


    private void btn_Save_perActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Save_perActionPerformed
        // TODO add your handling code here:

        schedule = "i have fucking no meaning !";
        if (chk_schedule.isSelected()) {
            get_Schedule();
        }
        sign = false;
        if (chk_schedule.isSelected() && schedule.isEmpty()) {
            sign = true;
            acknowledgement_Or_Warning("Empty Schedule !", 1505);
        }
        
        if (sign == false) {
            try {
                if ((name = txt_FullName.getText()).equals("") || (contact = txt_contact.getText()).equals("")
                        || ((per_add = txt_P_Add.getText()).equals("") && (cur_add = txt_C_Add.getText()).equals("")) || (dept = txt_Dept.getText()).equals("")
                        || (email = txt_Email.getText()).equals("")) {

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1300);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            lbl_msg.setText("");
                        }
                    }).start();
                    lbl_msg.setText("Mendatory Data Missing ! !");
                } else {

                    nid = txt_NID.getText();

                    type = cmb_doc_type.getSelectedItem().toString();

                    chamber = txt_chamber.getText();
                    try {
                        dob = new SimpleDateFormat("dd/MM/yyyy").format(date_birth.getDate());
                        doj = new SimpleDateFormat("dd/MM/yyyy").format(date_join.getDate());
                        fin = new FileInputStream(imgFile);
                    } catch (NullPointerException npe) {

                    }

                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(url + dbName, db_userName, db_password);

                    st = con.createStatement();

                    query = "SELECT * FROM doctors";

                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        doc_ID = rs.getInt("doc_id");
                    }
                    doc_ID += 1;
                    if (module_right == true) {
                        Admin.get_auto_generated_pass();
                        pass = "DOC" + doc_ID + "-" + pass;
                        pst = con.prepareStatement("insert into accounts values(?,?,?,?,?)");

                        pst.setString(1, email);
                        pst.setString(2, pass);
                        pst.setString(3, "Never Logged In");
                        pst.setString(4, "");
                        pst.setString(5, "Doctor");
                        pst.executeUpdate();
                    }
                    pst = con.prepareStatement("insert into doctors values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

                    pst.setInt(1, doc_ID);
                    pst.setString(2, name);
                    pst.setString(3, email);
                    pst.setString(4, contact);
                    pst.setString(5, nid);
                    pst.setString(6, per_add);
                    pst.setString(7, cur_add);
                    pst.setString(8, dept);
                    pst.setString(9, desg);
                    pst.setString(10, dob);
                    pst.setString(11, doj);
                    pst.setString(12, type);
                    if (fin == null) {
                        pst.setBinaryStream(13, is);
                    }
                    if (fin != null) {
                        pst.setBinaryStream(13, (InputStream) fin, (int) imgFile.length());
                    }
                    pst.setString(14, chamber);
                    pst.setString(15, schedule);

                    try {
                        pst.executeUpdate();
                    } catch (NullPointerException npe) {
                        System.out.println("in execution >>>>");
                    }

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(2200);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            lbl_msg.setText("");
//
//                        query = "SELECT * FROM doc_personal";
//
//                        try {
//                            rs = st.executeQuery(query);
//                            while (rs.next()) {
//                                id = rs.getInt("id");
//                                
//                            }
//                        } catch (SQLException sqle) {
//                            System.out.println("sql exception !" + sqle);
//                        }
//                        txt_doc_id.setText(String.valueOf(id));
//                        chk_schedule.setSelected(true);
//                        lbl_sch_title.setVisible(true);
//                        jpnl_schedule.setVisible(true);

                        }
                    }).start();
                    lbl_msg.setText("S a v e d !");
                    btn_Clear_perActionPerformed(evt);
                    chk_schedule.setSelected(false);
                    chk_scheduleActionPerformed(evt);

                }

            } catch (Exception ex) {
                System.out.println(ex + "  " + ex.getMessage());
            }

        }


    }//GEN-LAST:event_btn_Save_perActionPerformed

    private void btn_fri_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_fri_okActionPerformed
        // TODO add your handling code here:

        String str = txt_fri.getText();
        start = jspn_fri_1.getValue().toString().substring(11, 16);
        end = jspn_fri_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        sign = false;
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_fri.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_fri.setText(start + " to " + end);
            } else {
                txt_fri.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }

    }//GEN-LAST:event_btn_fri_okActionPerformed

    private void btn_clear_friActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_friActionPerformed
        // TODO add your handling code here:
        String str = txt_fri.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_fri.setText(str.substring(0, str.length() - 17));
        } else {
            txt_fri.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_friActionPerformed

    private void chk_friActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_friActionPerformed
        // TODO add your handling code here:
        if (chk_fri.isSelected()) {

            for (int i = 2; i < 8; i++) {
                //  System.out.println(jPanel_fri.getComponent(i));
                jPanel_fri.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_fri.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_fri.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_friActionPerformed

    private void btn_thu_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thu_okActionPerformed
        // TODO add your handling code here:

        String str = txt_thu.getText();
        start = jspn_thu_1.getValue().toString().substring(11, 16);
        end = jspn_thu_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        sign = false;
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_thu.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_thu.setText(start + " to " + end);
            } else {
                txt_thu.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }

    }//GEN-LAST:event_btn_thu_okActionPerformed

    private void chk_thuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_thuActionPerformed
        // TODO add your handling code here:
        if (chk_thu.isSelected()) {

            for (int i = 2; i < 8; i++) {

                jPanel_thu.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_thu.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_thu.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_thuActionPerformed

    private void btn_wed_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_wed_okActionPerformed
        // TODO add your handling code here:

        String str = txt_wed.getText();
        start = jspn_wed_1.getValue().toString().substring(11, 16);
        end = jspn_wed_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        sign = false;
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_wed.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_wed.setText(start + " to " + end);
            } else {
                txt_wed.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }

    }//GEN-LAST:event_btn_wed_okActionPerformed

    private void chk_wedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_wedActionPerformed
        // TODO add your handling code here:
        if (chk_wed.isSelected()) {

            for (int i = 2; i < 8; i++) {

                jPanel_wed.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_wed.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_wed.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_wedActionPerformed

    private void btn_tue_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tue_okActionPerformed
        // TODO add your handling code here:

        String str = txt_tue.getText();
        start = jspn_tue_1.getValue().toString().substring(11, 16);
        end = jspn_tue_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        sign = false;
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_tue.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_tue.setText(start + " to " + end);
            } else {
                txt_tue.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }

    }//GEN-LAST:event_btn_tue_okActionPerformed

    private void chk_tueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_tueActionPerformed
        // TODO add your handling code here:
        if (chk_tue.isSelected()) {

            for (int i = 2; i < 8; i++) {

                jPanel_tue.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_tue.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_tue.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_tueActionPerformed

    private void btn_mon_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mon_okActionPerformed
        // TODO add your handling code here:
        sign = false;
        String str = txt_mon.getText();
        start = jspn_mon_1.getValue().toString().substring(11, 16);
        end = jspn_mon_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        if (s == e) {
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_mon.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_mon.setText(start + " to " + end);
            } else {
                txt_mon.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }

    }//GEN-LAST:event_btn_mon_okActionPerformed

    private void chk_monActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_monActionPerformed
        // TODO add your handling code here:
        if (chk_mon.isSelected()) {

            for (int i = 2; i < 8; i++) {

                jPanel_mon.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_mon.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_mon.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_monActionPerformed

    private void btn_add_monActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_monActionPerformed
        // TODO add your handling code here:
        String str = txt_mon.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_mon.setText(str + " & ");
        }
    }//GEN-LAST:event_btn_add_monActionPerformed

    private void btn_sun_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sun_okActionPerformed
        // TODO add your handling code here:
        sign = false;
        String str = txt_sun.getText();
        start = jspn_sun_1.getValue().toString().substring(11, 16);
        end = jspn_sun_2.getValue().toString().substring(11, 16);
        // System.out.println(start+"  "+);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_sun.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_sun.setText(start + " to " + end);
            } else {
                txt_sun.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }
    }//GEN-LAST:event_btn_sun_okActionPerformed

    private void chk_sunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_sunActionPerformed
        // TODO add your handling code here:
        if (chk_sun.isSelected()) {

            for (int i = 2; i < 8; i++) {

                jPanel_sun.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_sun.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_sun.getComponent(i).setEnabled(false);
            }
        }
    }//GEN-LAST:event_chk_sunActionPerformed

    private void btn_sat_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sat_okActionPerformed
        // TODO add your handling code here:
        String str = txt_sat.getText();
        sign = false;
        start = jspn_sat_1.getValue().toString().substring(11, 16);
        end = jspn_sat_2.getValue().toString().substring(11, 16);
        System.out.println(start + "  " + end);
        int s = Integer.parseInt(start.substring(0, 2));
        int e = Integer.parseInt(end.substring(0, 2));
        if (s == e) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (s > e && e != 0) {
            sign = true;
            acknowledgement_Or_Warning("Invalid ! time frame ", 2000);
        }
        if (sign == false) {

            if (str.endsWith("& ")) {
                txt_sat.setText(str + start + " to " + end);
            } else if (str.equals("")) {
                txt_sat.setText(start + " to " + end);
            } else {
                txt_sat.setText(str.substring(0, str.length() - 14) + start + " to " + end);
            }
        }
    }//GEN-LAST:event_btn_sat_okActionPerformed

    private void chk_satActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_satActionPerformed
        // TODO add your handling code here:
        if (chk_sat.isSelected()) {

            for (int i = 2; i < 8; i++) {
                //  System.out.println(jPanel_sat.getComponent(i));
                jPanel_sat.getComponent(i).setEnabled(true);
            }
        }
        if (!chk_sat.isSelected()) {
            for (int i = 2; i < 8; i++) {
                jPanel_sat.getComponent(i).setEnabled(false);
            }
            txt_sat.setText("");
        }
    }//GEN-LAST:event_chk_satActionPerformed

    private void btn_add_satActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_satActionPerformed
        // TODO add your handling code here:
        String str = txt_sat.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_sat.setText(txt_sat.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_satActionPerformed

    private void btn_clear_satActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_satActionPerformed
        // TODO add your handling code here:
        String str = txt_sat.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_sat.setText(str.substring(0, str.length() - 17));
        } else {
            txt_sat.setText(str.substring(0, str.length() - 14));
        }

    }//GEN-LAST:event_btn_clear_satActionPerformed

    private void btn_add_sunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_sunActionPerformed
        // TODO add your handling code here:
        String str = txt_sun.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_sun.setText(txt_sun.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_sunActionPerformed

    private void btn_add_tueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_tueActionPerformed
        // TODO add your handling code here:
        String str = txt_tue.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_tue.setText(txt_tue.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_tueActionPerformed

    private void btn_add_wedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_wedActionPerformed
        // TODO add your handling code here:
        String str = txt_wed.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_wed.setText(txt_wed.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_wedActionPerformed

    private void btn_add_thuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_thuActionPerformed
        // TODO add your handling code here:
        String str = txt_thu.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_thu.setText(txt_thu.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_thuActionPerformed

    private void btn_add_friActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_friActionPerformed
        // TODO add your handling code here:
        String str = txt_fri.getText();
        if (!str.equals("") && !str.endsWith("& ")) {
            txt_fri.setText(txt_fri.getText() + " & ");
        }
    }//GEN-LAST:event_btn_add_friActionPerformed

    private void btn_clear_sunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_sunActionPerformed
        // TODO add your handling code here:
        String str = txt_sun.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_sun.setText(str.substring(0, str.length() - 17));
        } else {
            txt_sun.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_sunActionPerformed

    private void btn_clear_monActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_monActionPerformed
        // TODO add your handling code here:
        String str = txt_mon.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_mon.setText(str.substring(0, str.length() - 17));
        } else {
            txt_mon.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_monActionPerformed

    private void btn_clear_tueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_tueActionPerformed
        // TODO add your handling code here:
        String str = txt_tue.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_tue.setText(str.substring(0, str.length() - 17));
        } else {
            txt_tue.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_tueActionPerformed

    private void btn_clear_wedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_wedActionPerformed
        // TODO add your handling code here:
        String str = txt_wed.getText();
        if (str.isEmpty()) {

        }
        if (str.contains("&")) {
            txt_wed.setText(str.substring(0, str.length() - 17));
        } else {
            txt_wed.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_wedActionPerformed

    private void btn_clear_thuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_thuActionPerformed
        // TODO add your handling code here:
        String str = txt_thu.getText();

        if (str.isEmpty()) {

        } else if (str.contains("&")) {
            txt_thu.setText(str.substring(0, str.length() - 17));
        } else {
            txt_thu.setText(str.substring(0, str.length() - 14));
        }
    }//GEN-LAST:event_btn_clear_thuActionPerformed

    private void btn_get_docActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_get_docActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_btn_get_docActionPerformed

    private void chk_module_rightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_module_rightActionPerformed
        // TODO add your handling code here:

        if (chk_module_right.isSelected()) {
            module_right = true;
        }
        if (!chk_module_right.isSelected()) {
            module_right = false;
        }
    }//GEN-LAST:event_chk_module_rightActionPerformed

    private void chk_editableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_editableActionPerformed
        // TODO add your handling code here:

        boolean bool = chk_editable.isSelected();

        make_editable(bool);


    }//GEN-LAST:event_chk_editableActionPerformed

    public void make_editable(boolean bool) {

        System.out.println("reached bool " + bool);

        txt_C_Add.setEditable(bool);
        txt_Email.setEditable(bool);
        txt_FullName.setEditable(bool);
        txt_NID.setEditable(bool);
        txt_P_Add.setEditable(bool);
        txt_desg.setEditable(bool);
        txt_contact.setEditable(bool);
        btn_image.setEnabled(bool);
        btn_Clear_per.setEnabled(bool);
        btn_Clear_per.setVisible(bool);
        btn_Save_per.setVisible(bool);

        btn_Save_per.setEnabled(bool);

    }

    public void acknowledgement_Or_Warning(String warning_Msg, int time) {
        //  jOptionPane = new JOptionPane(warning_Msg, JOptionPane.INFORMATION_MESSAGE);
        //  final JDialog dialog = jOptionPane.createDialog("pokath!");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (time == 1505) {
                    lbl_msg.setText("");
                }
                lbl_invalid_sch.setText("");

            }
        }).start();
        if (time == 1505) {
            lbl_msg.setText(warning_Msg);
        } else {
            lbl_invalid_sch.setText(warning_Msg);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doc_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doc_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doc_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doc_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        //  UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
        date = new Date();
        sm = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                date = new Date();

                (doc = new Doc_Form(2)).setVisible(true);
                //   (doc = new Doc_Form(0)).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Clear_per;
    private javax.swing.JButton btn_Save_per;
    private javax.swing.JButton btn_add_fri;
    private javax.swing.JButton btn_add_mon;
    private javax.swing.JButton btn_add_sat2;
    private javax.swing.JButton btn_add_sun;
    private javax.swing.JButton btn_add_thu;
    private javax.swing.JButton btn_add_tue;
    private javax.swing.JButton btn_add_wed;
    private javax.swing.JButton btn_clear_fri;
    private javax.swing.JButton btn_clear_mon;
    private javax.swing.JButton btn_clear_sat;
    private javax.swing.JButton btn_clear_sun;
    private javax.swing.JButton btn_clear_thu;
    private javax.swing.JButton btn_clear_tue;
    private javax.swing.JButton btn_clear_wed;
    private javax.swing.JButton btn_fri_ok;
    private javax.swing.JButton btn_get_doc;
    private javax.swing.JButton btn_image;
    private javax.swing.JButton btn_mon_ok;
    private javax.swing.JButton btn_sat_ok2;
    private javax.swing.JButton btn_sun_ok;
    private javax.swing.JButton btn_thu_ok;
    private javax.swing.JButton btn_tue_ok;
    private javax.swing.JButton btn_wed_ok;
    private javax.swing.JCheckBox chk_editable;
    private javax.swing.JCheckBox chk_fri;
    private javax.swing.JCheckBox chk_module_right;
    private javax.swing.JCheckBox chk_mon;
    private javax.swing.JCheckBox chk_sat;
    private javax.swing.JCheckBox chk_schedule;
    private javax.swing.JCheckBox chk_sun;
    private javax.swing.JCheckBox chk_thu;
    private javax.swing.JCheckBox chk_tue;
    private javax.swing.JCheckBox chk_wed;
    private javax.swing.JComboBox<String> cmb_doc_type;
    private com.toedter.calendar.JDateChooser date_birth;
    private com.toedter.calendar.JDateChooser date_join;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel_fri;
    private javax.swing.JPanel jPanel_mon;
    private javax.swing.JPanel jPanel_sat;
    private javax.swing.JPanel jPanel_sun;
    private javax.swing.JPanel jPanel_thu;
    private javax.swing.JPanel jPanel_tue;
    private javax.swing.JPanel jPanel_wed;
    private lu.tudor.santec.jtimechooser.demo.JTimeChooserDemo jTimeChooserDemo1;
    private javax.swing.JPanel jpnl_7_days;
    private javax.swing.JPanel jpnl_schedule;
    private javax.swing.JSpinner jspn_fri_1;
    private javax.swing.JSpinner jspn_fri_2;
    private javax.swing.JSpinner jspn_mon_1;
    private javax.swing.JSpinner jspn_mon_2;
    private javax.swing.JSpinner jspn_sat_1;
    private javax.swing.JSpinner jspn_sat_2;
    private javax.swing.JSpinner jspn_sun_1;
    private javax.swing.JSpinner jspn_sun_2;
    private javax.swing.JSpinner jspn_thu_1;
    private javax.swing.JSpinner jspn_thu_2;
    private javax.swing.JSpinner jspn_tue_1;
    private javax.swing.JSpinner jspn_tue_2;
    private javax.swing.JSpinner jspn_wed_1;
    private javax.swing.JSpinner jspn_wed_2;
    private javax.swing.JLabel lbl_invalid_sch;
    private javax.swing.JLabel lbl_msg;
    private javax.swing.JLabel lbl_pic;
    private javax.swing.JLabel lbl_sch_title;
    private javax.swing.JButton list_dept;
    private javax.swing.JButton list_desg;
    private javax.swing.JTextField txt_C_Add;
    private javax.swing.JTextField txt_Dept;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_FullName;
    private javax.swing.JTextField txt_NID;
    private javax.swing.JTextField txt_P_Add;
    private javax.swing.JTextField txt_chamber;
    private javax.swing.JTextField txt_contact;
    private javax.swing.JTextField txt_desg;
    private javax.swing.JTextField txt_doc_id;
    private javax.swing.JTextField txt_fri;
    private javax.swing.JTextField txt_mon;
    private javax.swing.JTextField txt_sat;
    private javax.swing.JTextField txt_sun;
    private javax.swing.JTextField txt_thu;
    private javax.swing.JTextField txt_tue;
    private javax.swing.JTextField txt_wed;
    // End of variables declaration//GEN-END:variables
}
//
//class omega {
//    
//    
//    

//}
