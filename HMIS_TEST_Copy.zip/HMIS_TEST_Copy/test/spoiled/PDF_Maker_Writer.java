/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmis_test;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Font;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

/**
 *
 * @author pddrgj3q
 */
public class PDF_Maker_Writer {

    public static void main(String[] args) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\iTextHelloWorld.pdf"));

            com.itextpdf.text.Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
            Chunk chunk = new Chunk("Hello World ebfweifiweiuiuvweigivhweg \n\n", font);
            document.open();
            document.add(chunk);
            document.close();
            document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Masum Khan\\Desktop\\iTextHelloWorld.pdf"));
            document.open();
            chunk = new Chunk("Hello World e pokath !", font);
            document.add(chunk);
            document.close();

        } catch (Exception sx) {
            System.out.println(sx);
        }
    }

    public void method() {

        System.out.println(new SimpleDateFormat("dd/MM/YY hh: mm").format(new Date()) + "    > " + LocalDateTime.now());

    }
}
