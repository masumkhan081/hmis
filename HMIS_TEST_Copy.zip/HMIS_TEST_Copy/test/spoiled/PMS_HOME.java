/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pride;

import static Pride.PMS_Launcher.*;
import java.awt.Color;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.sql.DriverManager;
import java.util.ArrayList;
import javafx.stage.WindowEvent;
import javax.swing.JComboBox;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pddrgj3q
 */
public class PMS_HOME extends javax.swing.JFrame {

    /**
     * Creates new form PMS_HOME
     */
    int pX, pY;

    public PMS_HOME() {
        initComponents();

        setVisible(true);
        setDefaultCloseOperation(1);
        //   setResizable(false);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        set_Table_Action();
        set_Initial_State();
        set_Movable();
        // get_Companies_Generic();
    }

    public void set_Table_Action() {

        tbl_Result_Exhibition.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int col = tbl_Result_Exhibition.columnAtPoint(e.getPoint());
                int row = tbl_Result_Exhibition.rowAtPoint(e.getPoint());
                if (lbl_tble_title.getText().equals("Depositors") && (col == 5) && row > -1) {
                    lbl_process_title.setText("Purchase Order For: " + tbl_Result_Exhibition.getValueAt(row, 0).toString() + ", " + tbl_Result_Exhibition.getValueAt(row, 2).toString());
                    com_name = tbl_Result_Exhibition.getValueAt(row, 2).toString();
                    Order_For_Depositor(row);

                }
                if (lbl_tble_title.getText().equals("Companies") && (col == 2) && row > -1) {
                    com_name = tbl_Result_Exhibition.getValueAt(row, 0).toString();
                    lbl_process_title.setText("Purchase Order To: " + com_name);
                    Order_For_Depositor(row);

                }
            }
        }
        );
    }

    public void get_Companies_Generic() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            query = "SELECT DISTINCT company from drug_stock ;";
            rs = st.executeQuery(query);
            System.out.println("get_Companies_Generic()");
            while (rs.next()) {
                cmb_drug_by_com.addItem(rs.getString(1));

            }
            query = "SELECT DISTINCT generic from drug_stock ;";
            rs = st.executeQuery(query);

            while (rs.next()) {
                cmb_drug_by_gen.addItem(rs.getString(1));

            }

        } catch (Exception exp) {
            System.out.println(exp);
        }

    }

    public void Order_For_Depositor(int id_mark) {
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_drug = new New_Drug(1)));
        new_drug.setLocation(0, 0);
        jpnl_grand.setVisible(true);

    }

    public void set_Movable() {

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent me) {
                setLocation(getLocation().x + me.getX() - pX,
                        getLocation().y + me.getY() - pY);
            }
        });
    }

    public void set_Initial_State() {

//        txt_conf_pass.setVisible(false);
//        btn_update.setVisible(false);
//        btn_create_new.setVisible(false);
//        lbl_con_pass.setVisible(false);
//        btn_show_hide1.setVisible(false);
    }

    public void follow_Type(String type) {
        if (type.equals("Admin")) {
            set_For_Admin();
        }
        if (type.equals("Pharmacist")) {
            set_For_Pharmacist();
        }
        if (type.equals("Salesman")) {
            set_For_Salesman();
        }
        if (type.equals("Manager")) {
            set_For_Manager();
        }
        btn_login_out.setText("Log Out");
    }

    public void set_For_Admin() {

//        btn_create_new.setVisible(true);
//        System.out.println("found admin");
    }

    public void set_For_Salesman() {

    }

    public void set_For_Manager() {

    }

    public void set_For_Pharmacist() {

    }

    public void clear_Grand_Pnl() {

        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textField1 = new java.awt.TextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jpnl_sup_grand = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Result_Exhibition = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btn_new_drug = new javax.swing.JButton();
        btn_new_acc = new javax.swing.JButton();
        btn_new_dep = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btn_view_drug = new javax.swing.JButton();
        btn_view_dep = new javax.swing.JButton();
        btn_view_companies = new javax.swing.JButton();
        btn_view_dep2 = new javax.swing.JButton();
        jpnl_grand = new javax.swing.JPanel();
        btn_put_in_sale = new javax.swing.JButton();
        lbl_tble_title = new javax.swing.JLabel();
        lbl_process_title = new javax.swing.JLabel();
        cmb_drug_by_com = new javax.swing.JComboBox<>();
        cmb_drug_by_gen = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jpnl_login = new javax.swing.JPanel();
        btn_login_out = new javax.swing.JButton();
        txt_u_name = new javax.swing.JTextField();
        btn_update = new javax.swing.JButton();
        lbl_warning = new javax.swing.JLabel();
        btn_create_new = new javax.swing.JButton();
        btn_show_hide = new javax.swing.JButton();
        btn_show_hide1 = new javax.swing.JButton();
        txt_pass = new javax.swing.JPasswordField();
        txt_conf_pass = new javax.swing.JPasswordField();
        lbl_pass = new javax.swing.JLabel();
        lbl_con_pass = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        btn_rec_purchase = new javax.swing.JButton();
        cmb_search_By = new javax.swing.JComboBox<>();
        txt_search_content = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        btn_new_dep2 = new javax.swing.JButton();
        lbl_dep_name = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();

        textField1.setText("textField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(232, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(1382, 700));
        jPanel1.setMinimumSize(new java.awt.Dimension(1382, 700));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 1, 0, new java.awt.Color(204, 102, 0)));
        jPanel2.setForeground(new java.awt.Color(255, 204, 102));

        jLabel1.setBackground(new java.awt.Color(232, 255, 255));
        jLabel1.setForeground(new java.awt.Color(255, 255, 153));
        jLabel1.setText("   ABC Pharmacy Managemet System");

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Century", 1, 11)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 102, 0));
        jButton1.setText("exit");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Century", 1, 11)); // NOI18N
        jButton2.setForeground(new java.awt.Color(204, 102, 0));
        jButton2.setText("min");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 153));
        jLabel9.setText("Date : 19.10.18");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jpnl_sup_grand.setBackground(new java.awt.Color(1, 23, 23));
        jpnl_sup_grand.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jpnl_sup_grand.setMaximumSize(new java.awt.Dimension(1380, 540));
        jpnl_sup_grand.setMinimumSize(new java.awt.Dimension(1380, 540));
        jpnl_sup_grand.setPreferredSize(new java.awt.Dimension(1380, 540));

        tbl_Result_Exhibition.setBackground(new java.awt.Color(0, 0, 0));
        tbl_Result_Exhibition.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tbl_Result_Exhibition.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tbl_Result_Exhibition.setForeground(new java.awt.Color(255, 255, 153));
        tbl_Result_Exhibition.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Result_Exhibition.setColumnSelectionAllowed(true);
        tbl_Result_Exhibition.setGridColor(new java.awt.Color(0, 153, 153));
        tbl_Result_Exhibition.setMaximumSize(new java.awt.Dimension(380, 508));
        tbl_Result_Exhibition.setMinimumSize(new java.awt.Dimension(380, 508));
        tbl_Result_Exhibition.setOpaque(false);
        tbl_Result_Exhibition.setPreferredSize(new java.awt.Dimension(380, 508));
        tbl_Result_Exhibition.setRowHeight(23);
        tbl_Result_Exhibition.setSelectionBackground(new java.awt.Color(204, 255, 153));
        tbl_Result_Exhibition.setSelectionForeground(new java.awt.Color(153, 51, 0));
        tbl_Result_Exhibition.setShowVerticalLines(false);
        jScrollPane1.setViewportView(tbl_Result_Exhibition);

        jPanel4.setBackground(new java.awt.Color(20, 28, 28));
        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 3, new java.awt.Color(0, 102, 102)));

        jLabel2.setForeground(new java.awt.Color(204, 255, 204));
        jLabel2.setText("Introduce To System  ");
        jLabel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(204, 102, 0)));

        btn_new_drug.setBackground(new java.awt.Color(0, 10, 10));
        btn_new_drug.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_new_drug.setForeground(new java.awt.Color(102, 102, 255));
        btn_new_drug.setText("New Drug");
        btn_new_drug.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_drug.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_drugActionPerformed(evt);
            }
        });

        btn_new_acc.setBackground(new java.awt.Color(0, 10, 10));
        btn_new_acc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_new_acc.setForeground(new java.awt.Color(102, 102, 255));
        btn_new_acc.setText("New Account");
        btn_new_acc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_accActionPerformed(evt);
            }
        });

        btn_new_dep.setBackground(new java.awt.Color(0, 10, 10));
        btn_new_dep.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_new_dep.setForeground(new java.awt.Color(102, 102, 255));
        btn_new_dep.setText("New Depositor");
        btn_new_dep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_dep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_depActionPerformed(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(204, 255, 204));
        jLabel4.setText("Normal View");
        jLabel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(204, 102, 0)));

        btn_view_drug.setBackground(new java.awt.Color(0, 10, 10));
        btn_view_drug.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_view_drug.setForeground(new java.awt.Color(102, 102, 255));
        btn_view_drug.setText("View Drugs");
        btn_view_drug.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_view_drug.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_drugActionPerformed(evt);
            }
        });

        btn_view_dep.setBackground(new java.awt.Color(0, 10, 10));
        btn_view_dep.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_view_dep.setForeground(new java.awt.Color(102, 102, 255));
        btn_view_dep.setText("Depositors");
        btn_view_dep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_view_dep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_depActionPerformed(evt);
            }
        });

        btn_view_companies.setBackground(new java.awt.Color(0, 10, 10));
        btn_view_companies.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_view_companies.setForeground(new java.awt.Color(102, 102, 255));
        btn_view_companies.setText("Companies");
        btn_view_companies.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_view_companies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_companiesActionPerformed(evt);
            }
        });

        btn_view_dep2.setBackground(new java.awt.Color(0, 10, 10));
        btn_view_dep2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_view_dep2.setForeground(new java.awt.Color(102, 102, 255));
        btn_view_dep2.setText("Orders");
        btn_view_dep2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_view_dep2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_dep2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_new_drug, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btn_new_dep, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                        .addComponent(btn_new_acc, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btn_view_dep2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_view_companies, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_view_dep, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_view_drug, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_drug)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_acc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_new_dep)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_drug)
                .addGap(59, 59, 59)
                .addComponent(btn_view_dep)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_companies)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_view_dep2)
                .addContainerGap(180, Short.MAX_VALUE))
        );

        jpnl_grand.setBackground(new java.awt.Color(153, 153, 255));
        jpnl_grand.setMaximumSize(new java.awt.Dimension(370, 515));
        jpnl_grand.setMinimumSize(new java.awt.Dimension(370, 515));
        jpnl_grand.setPreferredSize(new java.awt.Dimension(370, 515));

        javax.swing.GroupLayout jpnl_grandLayout = new javax.swing.GroupLayout(jpnl_grand);
        jpnl_grand.setLayout(jpnl_grandLayout);
        jpnl_grandLayout.setHorizontalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jpnl_grandLayout.setVerticalGroup(
            jpnl_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 515, Short.MAX_VALUE)
        );

        btn_put_in_sale.setBackground(new java.awt.Color(0, 10, 10));
        btn_put_in_sale.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_put_in_sale.setForeground(new java.awt.Color(102, 102, 255));
        btn_put_in_sale.setText("Put In Sale >>");
        btn_put_in_sale.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_put_in_sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_put_in_saleActionPerformed(evt);
            }
        });

        lbl_tble_title.setFont(new java.awt.Font("Felix Titling", 1, 12)); // NOI18N
        lbl_tble_title.setForeground(new java.awt.Color(204, 204, 255));
        lbl_tble_title.setText("jLabel3");

        lbl_process_title.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_process_title.setForeground(new java.awt.Color(255, 153, 102));
        lbl_process_title.setText("indicator");

        cmb_drug_by_com.setBackground(new java.awt.Color(0, 10, 10));
        cmb_drug_by_com.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cmb_drug_by_com.setForeground(new java.awt.Color(204, 255, 153));
        cmb_drug_by_com.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        cmb_drug_by_com.setFocusable(false);
        cmb_drug_by_com.setLightWeightPopupEnabled(false);
        cmb_drug_by_com.setOpaque(false);
        cmb_drug_by_com.setRequestFocusEnabled(false);
        cmb_drug_by_com.setVerifyInputWhenFocusTarget(false);
        cmb_drug_by_com.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_by_comActionPerformed(evt);
            }
        });

        cmb_drug_by_gen.setBackground(new java.awt.Color(0, 10, 10));
        cmb_drug_by_gen.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cmb_drug_by_gen.setForeground(new java.awt.Color(204, 255, 153));
        cmb_drug_by_gen.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        cmb_drug_by_gen.setFocusable(false);
        cmb_drug_by_gen.setLightWeightPopupEnabled(false);
        cmb_drug_by_gen.setOpaque(false);
        cmb_drug_by_gen.setRequestFocusEnabled(false);
        cmb_drug_by_gen.setVerifyInputWhenFocusTarget(false);
        cmb_drug_by_gen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_drug_by_genActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 153, 102));
        jLabel3.setText("Companies");

        jLabel5.setForeground(new java.awt.Color(255, 153, 102));
        jLabel5.setText("Generics");

        javax.swing.GroupLayout jpnl_sup_grandLayout = new javax.swing.GroupLayout(jpnl_sup_grand);
        jpnl_sup_grand.setLayout(jpnl_sup_grandLayout);
        jpnl_sup_grandLayout.setHorizontalGroup(
            jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 827, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                        .addComponent(lbl_tble_title, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel3)
                        .addGap(3, 3, 3)
                        .addComponent(cmb_drug_by_com, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addGap(3, 3, 3)
                        .addComponent(cmb_drug_by_gen, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_put_in_sale, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnl_grand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_process_title, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnl_sup_grandLayout.setVerticalGroup(
            jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_sup_grandLayout.createSequentialGroup()
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_put_in_sale)
                    .addComponent(lbl_tble_title, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_drug_by_com, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_drug_by_gen, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addGap(0, 0, 0)
                .addGroup(jpnl_sup_grandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnl_sup_grandLayout.createSequentialGroup()
                .addComponent(lbl_process_title)
                .addGap(0, 0, 0)
                .addComponent(jpnl_grand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(24, 32, 32));
        jPanel3.setMaximumSize(new java.awt.Dimension(1352, 152));
        jPanel3.setMinimumSize(new java.awt.Dimension(1352, 152));
        jPanel3.setPreferredSize(new java.awt.Dimension(1352, 152));

        jpnl_login.setBackground(new java.awt.Color(0, 51, 51));
        jpnl_login.setMaximumSize(new java.awt.Dimension(300, 131));
        jpnl_login.setMinimumSize(new java.awt.Dimension(300, 131));

        btn_login_out.setBackground(new java.awt.Color(51, 0, 0));
        btn_login_out.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_login_out.setForeground(new java.awt.Color(255, 255, 153));
        btn_login_out.setText("Log In");
        btn_login_out.setActionCommand("Log  Out");
        btn_login_out.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_login_out.setBorderPainted(false);
        btn_login_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_login_outActionPerformed(evt);
            }
        });

        txt_u_name.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txt_u_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_u_name.setText("user name..");
        txt_u_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_u_nameFocusLost(evt);
            }
        });
        txt_u_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_u_nameActionPerformed(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(51, 0, 0));
        btn_update.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_update.setForeground(new java.awt.Color(255, 255, 153));
        btn_update.setText("Edit");
        btn_update.setActionCommand("Log  Out");
        btn_update.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_update.setBorderPainted(false);
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        btn_create_new.setBackground(new java.awt.Color(51, 0, 0));
        btn_create_new.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_create_new.setForeground(new java.awt.Color(255, 255, 153));
        btn_create_new.setText("Create New");
        btn_create_new.setActionCommand("Log  Out");
        btn_create_new.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_create_new.setBorderPainted(false);
        btn_create_new.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_create_newActionPerformed(evt);
            }
        });

        btn_show_hide.setBackground(new java.awt.Color(15, 38, 38));
        btn_show_hide.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        btn_show_hide.setForeground(new java.awt.Color(153, 153, 255));
        btn_show_hide.setText("Show");
        btn_show_hide.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_show_hide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_show_hideActionPerformed(evt);
            }
        });

        btn_show_hide1.setBackground(new java.awt.Color(15, 38, 38));
        btn_show_hide1.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        btn_show_hide1.setForeground(new java.awt.Color(153, 153, 255));
        btn_show_hide1.setText("Show");
        btn_show_hide1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_show_hide1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_show_hide1ActionPerformed(evt);
            }
        });

        lbl_pass.setForeground(new java.awt.Color(204, 204, 255));
        lbl_pass.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_pass.setText("pass:");

        lbl_con_pass.setForeground(new java.awt.Color(204, 204, 255));
        lbl_con_pass.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_con_pass.setText("confirm:");

        javax.swing.GroupLayout jpnl_loginLayout = new javax.swing.GroupLayout(jpnl_login);
        jpnl_login.setLayout(jpnl_loginLayout);
        jpnl_loginLayout.setHorizontalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_loginLayout.createSequentialGroup()
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnl_loginLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnl_loginLayout.createSequentialGroup()
                                .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_create_new, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53)
                                .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(lbl_warning, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpnl_loginLayout.createSequentialGroup()
                                    .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lbl_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lbl_con_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(0, 0, 0)
                                    .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btn_show_hide, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btn_show_hide1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jpnl_loginLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22))
        );
        jpnl_loginLayout.setVerticalGroup(
            jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnl_loginLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(txt_u_name, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_show_hide)
                    .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_pass))
                .addGap(10, 10, 10)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_show_hide1)
                    .addComponent(lbl_con_pass))
                .addGap(0, 0, 0)
                .addComponent(lbl_warning, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(jpnl_loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_login_out, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_create_new, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel5.setBackground(new java.awt.Color(0, 51, 51));

        btn_rec_purchase.setBackground(new java.awt.Color(0, 10, 10));
        btn_rec_purchase.setFont(new java.awt.Font("Traditional Arabic", 1, 16)); // NOI18N
        btn_rec_purchase.setForeground(new java.awt.Color(102, 102, 255));
        btn_rec_purchase.setText("Details");
        btn_rec_purchase.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_rec_purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_rec_purchaseActionPerformed(evt);
            }
        });

        cmb_search_By.setBackground(new java.awt.Color(0, 51, 51));
        cmb_search_By.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        cmb_search_By.setForeground(new java.awt.Color(204, 255, 153));
        cmb_search_By.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Drug Name", "Generic", "Company Name" }));
        cmb_search_By.setFocusable(false);
        cmb_search_By.setLightWeightPopupEnabled(false);
        cmb_search_By.setOpaque(false);
        cmb_search_By.setRequestFocusEnabled(false);
        cmb_search_By.setVerifyInputWhenFocusTarget(false);

        txt_search_content.setBackground(new java.awt.Color(15, 38, 38));
        txt_search_content.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        txt_search_content.setForeground(new java.awt.Color(255, 204, 102));
        txt_search_content.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txt_search_content.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_search_contentActionPerformed(evt);
            }
        });

        btn_search.setBackground(new java.awt.Color(0, 51, 51));
        btn_search.setForeground(new java.awt.Color(255, 153, 51));
        btn_search.setText("Search");
        btn_search.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        btn_new_dep2.setBackground(new java.awt.Color(0, 10, 10));
        btn_new_dep2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btn_new_dep2.setForeground(new java.awt.Color(102, 102, 255));
        btn_new_dep2.setText("Record Purchase");
        btn_new_dep2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_new_dep2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_new_dep2ActionPerformed(evt);
            }
        });

        lbl_dep_name.setForeground(new java.awt.Color(204, 204, 255));
        lbl_dep_name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_dep_name.setText("Depositor: Mr. omuk hasan , square ltd.");

        jSpinner1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jSpinner1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_dep_name, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btn_new_dep2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(263, 263, 263)
                .addComponent(btn_rec_purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(397, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(cmb_search_By, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lbl_dep_name, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_new_dep2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_rec_purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_search_content, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_search_By, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jpnl_login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnl_login, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1354, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnl_sup_grand, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1354, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jpnl_sup_grand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1358, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        setState(1);
    }//GEN-LAST:event_jButton2ActionPerformed

    public void status_In_Time(String str, int i) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lbl_warning.setText("");

            }
        }).start();
        lbl_warning.setText(str);
    }
    private void btn_login_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_login_outActionPerformed
        // TODO add your handling code here:

        if (btn_login_out.getText().equals("Log In")) {
            u_name = txt_u_name.getText();
            pass = txt_pass.getText();
            System.out.println(u_name + "   " + pass);
            try {

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);

                st = con.createStatement();
                query = "SELECT * FROM accounts ";

                rs = st.executeQuery(query);
                sign = false;
                while (rs.next()) {
                    if (u_name.equals(rs.getString("user_name")) && pass.equals(rs.getString("pass"))) {
                        using_acc_type = rs.getString("type");
                        sign = true;
                        break;
                    }
                }

            } catch (Exception exp) {
                System.out.println(exp);
            }
            if (sign == true) {
                follow_Type(using_acc_type);
            } else {
                status_In_Time("Missmatch !", 1500);
            }
        } else {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_login_outActionPerformed

    private void txt_u_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusGained
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("user name..")) {
            txt_u_name.setText("");
        }
    }//GEN-LAST:event_txt_u_nameFocusGained

    private void txt_u_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_u_nameFocusLost
        // TODO add your handling code here:
        if (txt_u_name.getText().equals("")) {
            txt_u_name.setText("user name..");
        }
    }//GEN-LAST:event_txt_u_nameFocusLost

    private void txt_u_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_u_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_u_nameActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
        String pass2 = "";
        if (btn_update.getText().equals("Edit")) {
            txt_u_name.setVisible(true);
            txt_pass.setVisible(true);
            txt_conf_pass.setVisible(true);

        }
        if (btn_update.getText().equals("Update")) {

//            if ((email = txt_email.getText()).isEmpty() || (pass = txt_pass.getText()).isEmpty() || (pass2 = txt_conf_pass.getText()).isEmpty()) {
//                acknowledgement_Or_Warning("you kidding !", 1500);
//            }
        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_create_newActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_create_newActionPerformed
        // TODO add your handling code here:

        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_acc = new New_Account(0)));
        new_acc.setLocation(10, 5);
        jpnl_grand.setVisible(true);

    }//GEN-LAST:event_btn_create_newActionPerformed

    private void btn_new_depActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_depActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_dep = new New_Depositor(0)));
        new_dep.setLocation(15, 15);
        jpnl_grand.setVisible(true);
        lbl_process_title.setText("");


    }//GEN-LAST:event_btn_new_depActionPerformed

    private void btn_rec_purchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_rec_purchaseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_rec_purchaseActionPerformed

    private void btn_new_drugActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_drugActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_drug = new New_Drug(0)));
        new_drug.setLocation(0, 0);
        jpnl_grand.setVisible(true);
        lbl_process_title.setText("Introducing New Drug To System");

    }//GEN-LAST:event_btn_new_drugActionPerformed

    private void btn_new_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_accActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_acc = new New_Account(0)));
        new_acc.setLocation(10, 5);
        jpnl_grand.setVisible(true);
        jpnl_grand.setBackground(new Color(15, 38, 38));
        lbl_process_title.setText("New User Account To Be Added");
    }//GEN-LAST:event_btn_new_accActionPerformed

    private void txt_search_contentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search_contentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search_contentActionPerformed

    private void btn_put_in_saleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_put_in_saleActionPerformed
        // TODO add your handling code here:
        jpnl_grand.removeAll();
        jpnl_grand.setVisible(false);
        jpnl_grand.add((new_sale = new New_Sale(0)));
        new_sale.setLocation(0, 0);
        jpnl_grand.setVisible(true);


    }//GEN-LAST:event_btn_put_in_saleActionPerformed

    private void btn_view_drugActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_drugActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[7];
        String[] data = new String[7];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "ID";
        coloumn[1] = "Drug Name";
        coloumn[2] = "Group name";
        coloumn[3] = "ComPany";
        //  coloumn[4] = "Expire Date";
        coloumn[4] = "Available";
        coloumn[5] = "MRP";
        coloumn[6] = "exp date";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            //  query = "SELECT distinct company from drug_stock";
            query = "SELECT * FROM drug_stock";
            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("drug_id");
                data[1] = rs.getString("drug_name");
                data[2] = rs.getString("generic");
                data[3] = rs.getString("company");
                //  data[4] = rs.getString("exp_date");
                //data[4] = rs.getString("quant");
                data[5] = rs.getString("mrp");
                System.out.println(data[0]);
                temp_id = Integer.parseInt(data[0]);

                //  temp_query = "SELECT left_amount  FROM stock_detail WHERE drug_id= " + temp_id;
                temp_query = "SELECT COUNT(left_amount) , SUM(left_amount) from stock_detail  where drug_id =" + temp_id;
                System.out.println("ops !");
                //   temp_query = "select * SUM(left_amount) FROM stock_detail WHERE drug_id= " + temp_id + " ";
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    // if(Integer.parseInt(temp_rs.getString(1))>1){
                    data[6] = temp_rs.getString(1) + "  running";
                    //}
                    data[4] = temp_rs.getString(2);
                    System.out.println(rs.getString(1) + "   ?? " + rs.getString(2));
                }
                temp_rs.close();
                arr_show.add(data);
                dm.addRow(arr_show.get(0));

            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Drugs From Stock");
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(85);
    }//GEN-LAST:event_btn_view_drugActionPerformed

    private void btn_view_depActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_depActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[6];
        String[] data = new String[6];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Name";
        coloumn[1] = "Contact";
        coloumn[2] = "Company";
        coloumn[3] = "Last Delivery";
        coloumn[4] = "Due Left";
        coloumn[5] = "Action";

        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            query = "SELECT * FROM depositors";

            rs = st.executeQuery(query);
            while (rs.next()) {

                data[0] = rs.getString("name");
                data[1] = rs.getString("contact");
                data[2] = rs.getString("com_name");
                temp_id = Integer.parseInt(rs.getString("dep_id"));
                ids.add(temp_id);
                temp_query = "SELECT SUM(due) from purchase_event where dep_id =" + temp_id;
                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[4] = temp_rs.getString(1);
                    System.out.println("due: " + data[4]);
                }

                temp_query = "SELECT  date from purchase_event WHERE dep_id = " + temp_id + " order by date desc limit 1 ";

                temp_rs = temp_st.executeQuery(temp_query);
                while (temp_rs.next()) {
                    data[3] = temp_rs.getString(1);
                }
                temp_rs.close();
                data[5] = " @ order delivery ";
                arr_show.add(data);
                dm.addRow(arr_show.get(0));

            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }
        lbl_tble_title.setText("Depositors");
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(140);
        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(140);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(140);
        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(140);
    }//GEN-LAST:event_btn_view_depActionPerformed

    private void btn_new_dep2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_new_dep2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_new_dep2ActionPerformed

    private void btn_show_hideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_show_hideActionPerformed
        // TODO add your handling code here:
        if (btn_show_hide.getText().equals("SHOW")) {
            btn_show_hide.setText("HIDE");
            txt_pass.setEchoChar((char) 0);
        } else {
            btn_show_hide.setText("SHOW");
            txt_pass.setEchoChar(('*'));
        }
    }//GEN-LAST:event_btn_show_hideActionPerformed

    private void btn_show_hide1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_show_hide1ActionPerformed
        // TODO add your handling code here:
        if (btn_show_hide.getText().equals("SHOW")) {
            btn_show_hide.setText("HIDE");
            txt_conf_pass.setEchoChar((char) 0);
        } else {
            btn_show_hide.setText("SHOW");
            txt_conf_pass.setEchoChar(('*'));
        }
    }//GEN-LAST:event_btn_show_hide1ActionPerformed

    private void btn_view_companiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_companiesActionPerformed
        // TODO add your handling code here:

        String[] coloumn = new String[4];
        String[] data = new String[4];
        arr_show = new ArrayList<String[]>();

        coloumn[0] = "Company";
        coloumn[1] = "Drugs On Run";
        coloumn[2] = "Action";
        coloumn[3] = "Action";
        data[2] = "@ order ";
        DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

        tbl_Result_Exhibition.setModel(dm);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
            st = con.createStatement();
            temp_st = con.createStatement();
            //  query = "SELECT distinct company from drug_stock";
            query = "SELECT company ,  count(*)   from drug_stock GROUP BY company";
            rs = st.executeQuery(query);
            while (rs.next()) {
                data[0] = rs.getString(1);
                data[1] = rs.getString(2);
                System.out.println(data[0] + "  " + data[1]);
                arr_show.add(data);
                dm.addRow(arr_show.get(0));
            }
        } catch (Exception ex) {
            System.out.println("view dep :" + ex);
        }

        lbl_tble_title.setText("Companies");
//        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMaxWidth(85);
//        tbl_Result_Exhibition.getColumnModel().getColumn(4).setMinWidth(85);
//        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMaxWidth(140);
//        tbl_Result_Exhibition.getColumnModel().getColumn(5).setMinWidth(140);
//        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMaxWidth(140);
//        tbl_Result_Exhibition.getColumnModel().getColumn(2).setMinWidth(140);

    }//GEN-LAST:event_btn_view_companiesActionPerformed

    private void btn_view_dep2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_dep2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_view_dep2ActionPerformed

    private void cmb_drug_by_comActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_by_comActionPerformed
        // TODO add your handling code here:
        if (cmb_drug_by_com.getSelectedIndex() > -1) {
            String[] coloumn = new String[7];
            String[] data = new String[7];
            arr_show = new ArrayList<String[]>();
            com_name = cmb_drug_by_com.getSelectedItem().toString();

            coloumn[0] = "ID";
            coloumn[1] = "Drug Name";
            coloumn[2] = "Group name";
            coloumn[3] = "ComPany";
            coloumn[4] = "Available";
            coloumn[5] = "MRP";
            coloumn[6] = "exp date";

            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);

            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
                st = con.createStatement();
                temp_st = con.createStatement();
                //  query = "SELECT distinct company from drug_stock";
                query = "SELECT * FROM drug_stock WHERE company = " + com_name + "'";
                rs = st.executeQuery(query);
                while (rs.next()) {

                    data[0] = rs.getString("drug_id");
                    data[1] = rs.getString("drug_name");
                    data[2] = rs.getString("generic");
                    data[3] = rs.getString("company");
                    //  data[4] = rs.getString("exp_date");
                    //data[4] = rs.getString("quant");
                    data[5] = rs.getString("mrp");
                    System.out.println(data[0]);
                    temp_id = Integer.parseInt(data[0]);

                    //  temp_query = "SELECT left_amount  FROM stock_detail WHERE drug_id= " + temp_id;
                    temp_query = "SELECT COUNT(left_amount) , SUM(left_amount) from stock_detail  where drug_id =" + temp_id;
                    System.out.println("ops !");
                    //   temp_query = "select * SUM(left_amount) FROM stock_detail WHERE drug_id= " + temp_id + " ";
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        // if(Integer.parseInt(temp_rs.getString(1))>1){
                        data[6] = temp_rs.getString(1) + "  running";
                        //}
                        data[4] = temp_rs.getString(2);
                        System.out.println(rs.getString(1) + "   ?? " + rs.getString(2));
                    }
                    temp_rs.close();
                    arr_show.add(data);
                    dm.addRow(arr_show.get(0));

                }
            } catch (Exception ex) {
                System.out.println("view dep :" + ex);
            }
            lbl_tble_title.setText("Drugs From Stock");
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(85);
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(85);
        }
    }//GEN-LAST:event_cmb_drug_by_comActionPerformed

    private void cmb_drug_by_genActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_drug_by_genActionPerformed
        // TODO add your handling code here:
        if (cmb_drug_by_com.getSelectedIndex() > -1) {
            String[] coloumn = new String[7];
            String[] data = new String[7];
            arr_show = new ArrayList<String[]>();
            drug_group = cmb_drug_by_gen.getSelectedItem().toString();

            coloumn[0] = "ID";
            coloumn[1] = "Drug Name";
            coloumn[2] = "Group name";
            coloumn[3] = "ComPany";
            coloumn[4] = "Available";
            coloumn[5] = "MRP";
            coloumn[6] = "exp date";
            DefaultTableModel dm = new DefaultTableModel(coloumn, 0);
            tbl_Result_Exhibition.setModel(dm);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url + db_Name, db_UserName, db_Password);
                st = con.createStatement();
                temp_st = con.createStatement();
                query = "SELECT * FROM drug_stock WHERE company = " + drug_group + "'";
                rs = st.executeQuery(query);
                while (rs.next()) {
                    data[0] = rs.getString("drug_id");
                    data[1] = rs.getString("drug_name");
                    data[2] = rs.getString("generic");
                    data[3] = rs.getString("company");

                    data[5] = rs.getString("mrp");
                    System.out.println(data[0]);
                    temp_id = Integer.parseInt(data[0]);

                    temp_query = "SELECT COUNT(left_amount) , SUM(left_amount) from stock_detail  where drug_id =" + temp_id;
                    System.out.println("ops !");
                    temp_rs = temp_st.executeQuery(temp_query);
                    while (temp_rs.next()) {
                        data[6] = temp_rs.getString(1) + "  running";
                        data[4] = temp_rs.getString(2);
                        System.out.println(rs.getString(1) + "   ?? " + rs.getString(2));
                    }
                    temp_rs.close();
                    arr_show.add(data);
                    dm.addRow(arr_show.get(0));

                }
            } catch (Exception ex) {
                System.out.println("view dep :" + ex);
            }
            lbl_tble_title.setText("Drugs From Stock");
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMaxWidth(85);
            tbl_Result_Exhibition.getColumnModel().getColumn(0).setMinWidth(85);
        }

    }//GEN-LAST:event_cmb_drug_by_genActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        //  try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
        //   UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        // UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel");
//        } catch (ClassNotFoundException ex) {
//            System.out.println(ex);
//        } catch (InstantiationException ex) {
//            System.out.println(ex);
//        } catch (IllegalAccessException ex) {
//            System.out.println(ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            System.out.println(ex);
//        }
        //</editor-fold>


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PMS_HOME().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_create_new;
    public javax.swing.JButton btn_login_out;
    public javax.swing.JButton btn_new_acc;
    public javax.swing.JButton btn_new_dep;
    public javax.swing.JButton btn_new_dep2;
    public javax.swing.JButton btn_new_drug;
    public javax.swing.JButton btn_put_in_sale;
    public javax.swing.JButton btn_rec_purchase;
    public javax.swing.JButton btn_search;
    public javax.swing.JButton btn_show_hide;
    public javax.swing.JButton btn_show_hide1;
    public javax.swing.JButton btn_update;
    public javax.swing.JButton btn_view_companies;
    public javax.swing.JButton btn_view_dep;
    public javax.swing.JButton btn_view_dep2;
    public javax.swing.JButton btn_view_drug;
    public javax.swing.JComboBox<String> cmb_drug_by_com;
    public javax.swing.JComboBox<String> cmb_drug_by_gen;
    public javax.swing.JComboBox<String> cmb_search_By;
    public javax.swing.JButton jButton1;
    public javax.swing.JButton jButton2;
    public javax.swing.JLabel jLabel1;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel4;
    public javax.swing.JLabel jLabel5;
    public javax.swing.JLabel jLabel9;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel4;
    public javax.swing.JPanel jPanel5;
    public javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JSpinner jSpinner1;
    public javax.swing.JPanel jpnl_grand;
    public javax.swing.JPanel jpnl_login;
    public javax.swing.JPanel jpnl_sup_grand;
    public javax.swing.JLabel lbl_con_pass;
    public javax.swing.JLabel lbl_dep_name;
    public javax.swing.JLabel lbl_pass;
    public javax.swing.JLabel lbl_process_title;
    public javax.swing.JLabel lbl_tble_title;
    public javax.swing.JLabel lbl_warning;
    public javax.swing.JTable tbl_Result_Exhibition;
    public java.awt.TextField textField1;
    public javax.swing.JPasswordField txt_conf_pass;
    public javax.swing.JPasswordField txt_pass;
    public javax.swing.JTextField txt_search_content;
    public javax.swing.JTextField txt_u_name;
    // End of variables declaration//GEN-END:variables
}
